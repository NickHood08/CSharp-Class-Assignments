﻿namespace HW4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstProducts = new ListBox();
            label1 = new Label();
            label2 = new Label();
            txtNewProduct = new TextBox();
            btnNewProduct = new Button();
            label3 = new Label();
            lstSubassembliesInProduct = new ListBox();
            btnAddSubassemblyToProduct = new Button();
            btnRemoveSubassemblyFromProduct = new Button();
            lstAllSubassemblies = new ListBox();
            btnNewSubassembly = new Button();
            txtNewSubassembly = new TextBox();
            label4 = new Label();
            lstAllBasicMaterials = new ListBox();
            btnNewBasicMaterial = new Button();
            txtNewBasicMaterial = new TextBox();
            label5 = new Label();
            lstBasicMaterialsInSelectedSubassembly = new ListBox();
            btnAddBasicMaterialToSubassembly = new Button();
            btnRemoveBasicMaterialFromSubassembly = new Button();
            SuspendLayout();
            // 
            // lstProducts
            // 
            lstProducts.FormattingEnabled = true;
            lstProducts.ItemHeight = 15;
            lstProducts.Location = new Point(12, 36);
            lstProducts.Name = "lstProducts";
            lstProducts.Size = new Size(765, 94);
            lstProducts.TabIndex = 0;
            lstProducts.SelectedIndexChanged += lstProducts_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 18);
            label1.Name = "label1";
            label1.Size = new Size(57, 15);
            label1.TabIndex = 1;
            label1.Text = "Products:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(467, 162);
            label2.Name = "label2";
            label2.Size = new Size(137, 15);
            label2.TabIndex = 2;
            label2.Text = "List of all Subassemblies:";
            // 
            // txtNewProduct
            // 
            txtNewProduct.Location = new Point(550, 136);
            txtNewProduct.Name = "txtNewProduct";
            txtNewProduct.Size = new Size(227, 23);
            txtNewProduct.TabIndex = 3;
            // 
            // btnNewProduct
            // 
            btnNewProduct.Location = new Point(439, 136);
            btnNewProduct.Name = "btnNewProduct";
            btnNewProduct.Size = new Size(105, 23);
            btnNewProduct.TabIndex = 4;
            btnNewProduct.Text = "New Product";
            btnNewProduct.UseVisualStyleBackColor = true;
            btnNewProduct.Click += btnNewProduct_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 162);
            label3.Name = "label3";
            label3.Size = new Size(145, 15);
            label3.TabIndex = 5;
            label3.Text = "Subassemblies in Product:";
            // 
            // lstSubassembliesInProduct
            // 
            lstSubassembliesInProduct.FormattingEnabled = true;
            lstSubassembliesInProduct.ItemHeight = 15;
            lstSubassembliesInProduct.Location = new Point(12, 180);
            lstSubassembliesInProduct.Name = "lstSubassembliesInProduct";
            lstSubassembliesInProduct.Size = new Size(298, 109);
            lstSubassembliesInProduct.TabIndex = 6;
            // 
            // btnAddSubassemblyToProduct
            // 
            btnAddSubassemblyToProduct.Location = new Point(328, 189);
            btnAddSubassemblyToProduct.Name = "btnAddSubassemblyToProduct";
            btnAddSubassemblyToProduct.Size = new Size(116, 35);
            btnAddSubassemblyToProduct.TabIndex = 7;
            btnAddSubassemblyToProduct.Text = "<-";
            btnAddSubassemblyToProduct.UseVisualStyleBackColor = true;
            btnAddSubassemblyToProduct.Click += btnAddSubassemblyToProduct_Click;
            // 
            // btnRemoveSubassemblyFromProduct
            // 
            btnRemoveSubassemblyFromProduct.Location = new Point(328, 245);
            btnRemoveSubassemblyFromProduct.Name = "btnRemoveSubassemblyFromProduct";
            btnRemoveSubassemblyFromProduct.Size = new Size(116, 35);
            btnRemoveSubassemblyFromProduct.TabIndex = 8;
            btnRemoveSubassemblyFromProduct.Text = "->";
            btnRemoveSubassemblyFromProduct.UseVisualStyleBackColor = true;
            btnRemoveSubassemblyFromProduct.Click += btnRemoveSubassemblyFromProduct_Click;
            // 
            // lstAllSubassemblies
            // 
            lstAllSubassemblies.FormattingEnabled = true;
            lstAllSubassemblies.ItemHeight = 15;
            lstAllSubassemblies.Location = new Point(467, 180);
            lstAllSubassemblies.Name = "lstAllSubassemblies";
            lstAllSubassemblies.Size = new Size(310, 109);
            lstAllSubassemblies.TabIndex = 9;
            lstAllSubassemblies.SelectedIndexChanged += lstAllSubassemblies_SelectedIndexChanged;
            // 
            // btnNewSubassembly
            // 
            btnNewSubassembly.Location = new Point(439, 295);
            btnNewSubassembly.Name = "btnNewSubassembly";
            btnNewSubassembly.Size = new Size(105, 23);
            btnNewSubassembly.TabIndex = 10;
            btnNewSubassembly.Text = "New Subasm";
            btnNewSubassembly.UseVisualStyleBackColor = true;
            btnNewSubassembly.Click += btnNewSubassembly_Click;
            // 
            // txtNewSubassembly
            // 
            txtNewSubassembly.Location = new Point(550, 296);
            txtNewSubassembly.Name = "txtNewSubassembly";
            txtNewSubassembly.Size = new Size(227, 23);
            txtNewSubassembly.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(466, 322);
            label4.Name = "label4";
            label4.Size = new Size(138, 15);
            label4.TabIndex = 12;
            label4.Text = "List of all Basic Materials:";
            // 
            // lstAllBasicMaterials
            // 
            lstAllBasicMaterials.FormattingEnabled = true;
            lstAllBasicMaterials.ItemHeight = 15;
            lstAllBasicMaterials.Location = new Point(467, 340);
            lstAllBasicMaterials.Name = "lstAllBasicMaterials";
            lstAllBasicMaterials.Size = new Size(310, 109);
            lstAllBasicMaterials.TabIndex = 13;
            // 
            // btnNewBasicMaterial
            // 
            btnNewBasicMaterial.Location = new Point(439, 455);
            btnNewBasicMaterial.Name = "btnNewBasicMaterial";
            btnNewBasicMaterial.Size = new Size(105, 23);
            btnNewBasicMaterial.TabIndex = 14;
            btnNewBasicMaterial.Text = "New Basic Mat'l";
            btnNewBasicMaterial.UseVisualStyleBackColor = true;
            btnNewBasicMaterial.Click += btnNewBasicMaterial_Click;
            // 
            // txtNewBasicMaterial
            // 
            txtNewBasicMaterial.Location = new Point(550, 456);
            txtNewBasicMaterial.Name = "txtNewBasicMaterial";
            txtNewBasicMaterial.Size = new Size(227, 23);
            txtNewBasicMaterial.TabIndex = 15;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 322);
            label5.Name = "label5";
            label5.Size = new Size(220, 15);
            label5.TabIndex = 16;
            label5.Text = "Basic Materials in Selected Subassembly:";
            // 
            // lstBasicMaterialsInSelectedSubassembly
            // 
            lstBasicMaterialsInSelectedSubassembly.FormattingEnabled = true;
            lstBasicMaterialsInSelectedSubassembly.ItemHeight = 15;
            lstBasicMaterialsInSelectedSubassembly.Location = new Point(12, 340);
            lstBasicMaterialsInSelectedSubassembly.Name = "lstBasicMaterialsInSelectedSubassembly";
            lstBasicMaterialsInSelectedSubassembly.Size = new Size(298, 109);
            lstBasicMaterialsInSelectedSubassembly.TabIndex = 17;
            // 
            // btnAddBasicMaterialToSubassembly
            // 
            btnAddBasicMaterialToSubassembly.Location = new Point(328, 351);
            btnAddBasicMaterialToSubassembly.Name = "btnAddBasicMaterialToSubassembly";
            btnAddBasicMaterialToSubassembly.Size = new Size(116, 35);
            btnAddBasicMaterialToSubassembly.TabIndex = 18;
            btnAddBasicMaterialToSubassembly.Text = "<-";
            btnAddBasicMaterialToSubassembly.UseVisualStyleBackColor = true;
            btnAddBasicMaterialToSubassembly.Click += btnAddBasicMaterialToSubassembly_Click;
            // 
            // btnRemoveBasicMaterialFromSubassembly
            // 
            btnRemoveBasicMaterialFromSubassembly.Location = new Point(328, 405);
            btnRemoveBasicMaterialFromSubassembly.Name = "btnRemoveBasicMaterialFromSubassembly";
            btnRemoveBasicMaterialFromSubassembly.Size = new Size(116, 35);
            btnRemoveBasicMaterialFromSubassembly.TabIndex = 19;
            btnRemoveBasicMaterialFromSubassembly.Text = "->";
            btnRemoveBasicMaterialFromSubassembly.UseVisualStyleBackColor = true;
            btnRemoveBasicMaterialFromSubassembly.Click += btnRemoveBasicMaterialFromSubassembly_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(789, 534);
            Controls.Add(btnRemoveBasicMaterialFromSubassembly);
            Controls.Add(btnAddBasicMaterialToSubassembly);
            Controls.Add(lstBasicMaterialsInSelectedSubassembly);
            Controls.Add(label5);
            Controls.Add(txtNewBasicMaterial);
            Controls.Add(btnNewBasicMaterial);
            Controls.Add(lstAllBasicMaterials);
            Controls.Add(label4);
            Controls.Add(txtNewSubassembly);
            Controls.Add(btnNewSubassembly);
            Controls.Add(lstAllSubassemblies);
            Controls.Add(btnRemoveSubassemblyFromProduct);
            Controls.Add(btnAddSubassemblyToProduct);
            Controls.Add(lstSubassembliesInProduct);
            Controls.Add(label3);
            Controls.Add(btnNewProduct);
            Controls.Add(txtNewProduct);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lstProducts);
            Name = "Form1";
            Text = "PlastiCo Manufacturing";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstProducts;
        private Label label1;
        private Label label2;
        private TextBox txtNewProduct;
        private Button btnNewProduct;
        private Label label3;
        private ListBox lstSubassembliesInProduct;
        private Button btnAddSubassemblyToProduct;
        private Button btnRemoveSubassemblyFromProduct;
        private ListBox lstAllSubassemblies;
        private Button btnNewSubassembly;
        private TextBox txtNewSubassembly;
        private Label label4;
        private ListBox lstAllBasicMaterials;
        private Button btnNewBasicMaterial;
        private TextBox txtNewBasicMaterial;
        private Label label5;
        private ListBox lstBasicMaterialsInSelectedSubassembly;
        private Button btnAddBasicMaterialToSubassembly;
        private Button btnRemoveBasicMaterialFromSubassembly;
    }
}
