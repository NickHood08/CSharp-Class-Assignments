using System.Collections.Generic;

namespace HW4
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: Main Form
    ///
    /// File Purpose:
    /// The purpose of this file is to launch and run the program.
    /// It also contains all functions/methods for the program.
    ///
    /// Program Purpose:
    /// The purpose of the program is to hold a product and all of the subassemblies
    /// that make the product up and all of the basic materials that make up the subassembly.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// This function initializes form 1
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        const int NO_ITEM_SELECTED = -1;  //Const representing no item selected in a listbox
        const string EMPTY_TITLE = "";   //Const representing an empty string for the title of a messagebox

        //The three dictionaries below are responsible for holding all the basic materails, subassemblies and products (in that order)
        SortedDictionary<string, string> dicBasicMaterials = new SortedDictionary<string, string>();
        SortedDictionary<string, SortedDictionary<string, string>> dicSubassemblies = new SortedDictionary<string, SortedDictionary<string, string>>();
        SortedDictionary<string, SortedDictionary<string, SortedDictionary<string, string>>> dicProducts = new SortedDictionary<string, SortedDictionary<string, SortedDictionary<string, string>>>();

        /// <summary>
        /// This function creates and displays the base data for the program when the program first starts up
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            dicBasicMaterials.Add("Axel", "Axel");
            dicBasicMaterials.Add("Base", "Base");
            dicBasicMaterials.Add("Frame", "Frame");
            dicBasicMaterials.Add("Leg", "Leg");
            dicBasicMaterials.Add("Long Rail", "Long Rail");
            dicBasicMaterials.Add("Seat", "Seat");
            dicBasicMaterials.Add("Short Rail", "Short Rail");
            SortedDictionary<string, string> basicMaterialTemp = new SortedDictionary<string, string>();
            dicSubassemblies.Add("3-Wheel Frame", basicMaterialTemp);
            dicSubassemblies.Add("4-Wheel Frame", basicMaterialTemp);
            basicMaterialTemp.Add(dicBasicMaterials["Base"], dicBasicMaterials["Base"]);
            basicMaterialTemp.Add(dicBasicMaterials["Long Rail"], dicBasicMaterials["Long Rail"]);
            basicMaterialTemp.Add(dicBasicMaterials["Short Rail"], dicBasicMaterials["Short Rail"]);
            dicSubassemblies.Add("Box", basicMaterialTemp);
            SortedDictionary<string, SortedDictionary<string, string>> subassemblyTemp = new SortedDictionary<string, SortedDictionary<string, string>>();
            subassemblyTemp.Add("4-Wheel Frame", basicMaterialTemp);
            subassemblyTemp.Add("Box", basicMaterialTemp);
            dicProducts.Add("Wagon", subassemblyTemp);
            populateProductListbox();
            populateSubassembliesListbox();
            populateBasicMaterialsListbox();
        }

        /// <summary>
        /// This function adds a new product to the product dictionary and repopulates the products listbox.
        /// This only happens if the product doesnt already exist.
        /// If the product already exists, a message box is displayed to the user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewProduct_Click(object sender, EventArgs e)
        {
            if (!dicProducts.ContainsKey(txtNewProduct.Text))
            {
                SortedDictionary<string, SortedDictionary<string, string>> dicSubassembliesNew = new SortedDictionary<string, SortedDictionary<string, string>>();
                dicProducts.Add(txtNewProduct.Text, dicSubassembliesNew);
                populateProductListbox();
            }
            else
            {
                MessageBox.Show("This product already exists", EMPTY_TITLE, MessageBoxButtons.OK);

            }
            txtNewProduct.Clear();
        }

        /// <summary>
        /// This function makes sure an item and a product are selected, then checks if the subassembly is already a subassembly
        /// in the product. If any of these checks fail the user is notified. If the checks pass then the subassemly is added
        /// to the products subassemly dictionary
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddSubassemblyToProduct_Click(object sender, EventArgs e)
        {
            if (!(lstProducts.SelectedIndex == NO_ITEM_SELECTED) && !(lstAllSubassemblies.SelectedIndex == NO_ITEM_SELECTED))
            {
                foreach (string subasm in lstAllSubassemblies.SelectedItems)
                {
                    if (!dicProducts[lstProducts.Items[lstProducts.SelectedIndex].ToString()!].ContainsKey(subasm))
                    {
                        dicProducts[lstProducts.Items[lstProducts.SelectedIndex].ToString()!].Add(subasm, dicSubassemblies[subasm]);
                    }
                    else
                    {
                        MessageBox.Show($"{subasm} is already a subassembly in the product.", EMPTY_TITLE, MessageBoxButtons.OK);
                    }
                }
                populateSubassembliesInProductListbox();
            }
            else
            {
                MessageBox.Show("Please make sure a product and at least one subassembly on the right are selected.", EMPTY_TITLE, MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// This function checks if a product and a subassembly in the product is selected.
        /// If the check pass then the subassembly is removed from the products subassembly
        /// dictionary. If they fail the user is notified.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRemoveSubassemblyFromProduct_Click(object sender, EventArgs e)
        {
            if (!(lstProducts.SelectedIndex == NO_ITEM_SELECTED) && !(lstSubassembliesInProduct.SelectedIndex == NO_ITEM_SELECTED))
            {
                foreach (string subasm in lstSubassembliesInProduct.SelectedItems)
                {
                    dicProducts[lstProducts.Items[lstProducts.SelectedIndex].ToString()!].Remove(subasm);
                }
                populateSubassembliesInProductListbox();
            }
            else
            {
                MessageBox.Show("Please make sure a product and at least one subassembly on the left are selected.", EMPTY_TITLE, MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// This function adds a new subassembly to the dictionary of all subassemblies as long as it doesnt already exist
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewSubassembly_Click(object sender, EventArgs e)
        {
            if (!dicProducts.ContainsKey(txtNewProduct.Text))
            {
                SortedDictionary<string, string> dicBasicMaterialsNew = new SortedDictionary<string, string>();
                dicSubassemblies.Add(txtNewSubassembly.Text, dicBasicMaterialsNew);
                populateSubassembliesListbox();
            }
            else
            {
                MessageBox.Show("This Subassembly already exists", EMPTY_TITLE, MessageBoxButtons.OK);
            }
            txtNewSubassembly.Clear();
        }

        /// <summary>
        /// This function makes sure a subassembly and a basic material are selected, then checks if the basic material is already
        /// in the subassembly. If any of these checks fail the user is notified. If the checks pass then the basic material is added
        /// to the subassembly's basic material dictionary
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddBasicMaterialToSubassembly_Click(object sender, EventArgs e)
        {
            if (!(lstAllSubassemblies.SelectedIndex == NO_ITEM_SELECTED) && !(lstAllBasicMaterials.SelectedIndex == NO_ITEM_SELECTED))
            {
                foreach (string basicMaterial in lstAllBasicMaterials.SelectedItems)
                {
                    if (!dicSubassemblies[lstAllSubassemblies.Items[lstAllSubassemblies.SelectedIndex].ToString()!].ContainsKey(basicMaterial))
                    {
                        dicSubassemblies[lstAllSubassemblies.Items[lstAllSubassemblies.SelectedIndex].ToString()!].Add(basicMaterial, basicMaterial);
                    }
                    else
                    {
                        MessageBox.Show($"{basicMaterial} is already a subassembly in the product.", EMPTY_TITLE, MessageBoxButtons.OK);
                    }
                }
                populateBasicMaterialsInSubassemblyListbox();
            }
            else
            {
                MessageBox.Show("Please make sure a subassembly and at least one Basic Material on the right are selected.", EMPTY_TITLE, MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// This function checks if a subassembly and a basic material in the subassembly is selected.
        /// If the check pass then the basic material is removed from the subassembly's basic material
        /// dictionary. If they fail the user is notified.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRemoveBasicMaterialFromSubassembly_Click(object sender, EventArgs e)
        {
            if (!(lstAllSubassemblies.SelectedIndex == NO_ITEM_SELECTED) && !(lstBasicMaterialsInSelectedSubassembly.SelectedIndex == NO_ITEM_SELECTED))
            {
                foreach (string basicMaterial in lstBasicMaterialsInSelectedSubassembly.SelectedItems)
                {
                    dicSubassemblies[lstAllSubassemblies.Items[lstAllSubassemblies.SelectedIndex].ToString()!].Remove(basicMaterial);
                }
                populateBasicMaterialsInSubassemblyListbox();
            }
            else
            {
                MessageBox.Show("Please make sure a subassembly and at least one Basic Material on the left are selected.", EMPTY_TITLE, MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// Adds a new basic material to the dictionary of all basic materials as long as it doesnt already exist
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewBasicMaterial_Click(object sender, EventArgs e)
        {
            if (!dicProducts.ContainsKey(txtNewProduct.Text))
            {
                dicBasicMaterials.Add(txtNewBasicMaterial.Text, txtNewBasicMaterial.Text);
                populateBasicMaterialsListbox();
            }
            else
            {
                MessageBox.Show("This Basic Material already exists", EMPTY_TITLE, MessageBoxButtons.OK);
            }
            txtNewBasicMaterial.Clear();
        }

        /// <summary>
        /// Checks if a product is selected and calls the function for populating the subassemblies in product listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstProducts.SelectedIndex != NO_ITEM_SELECTED)
            {
                populateSubassembliesInProductListbox();
            }
        }

        /// <summary>
        /// Checks if a subassembly is selected and calls the function for populating the basic materials in subassembly listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lstAllSubassemblies_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstAllSubassemblies.SelectedIndex != NO_ITEM_SELECTED)
            {
                populateBasicMaterialsInSubassemblyListbox();
            }
        }

        /// <summary>
        /// This function clears the products listbox, loops through the dictionary of all products, and
        /// adds the product to the list box
        /// </summary>
        private void populateProductListbox()
        {
            lstProducts.Items.Clear();
            foreach (string product in dicProducts.Keys)
            {
                lstProducts.Items.Add(product);
            }
        }

        /// <summary>
        /// This function clears the subassemblies listbox, loops through the dictionary of all subassemblies, and
        /// adds the subassembly to the list box
        /// </summary>
        private void populateSubassembliesListbox()
        {
            lstAllSubassemblies.Items.Clear();
            foreach (string subassembly in dicSubassemblies.Keys)
            {
                lstAllSubassemblies.Items.Add(subassembly);
            }
        }

        /// <summary>
        /// This function clears the basic amterials listbox, loops through the dictionary of all basic materials, and
        /// adds the basic material to the list box
        /// </summary>
        private void populateBasicMaterialsListbox()
        {
            lstAllBasicMaterials.Items.Clear();
            foreach (string basicMaterial in dicBasicMaterials.Keys)
            {
                lstAllBasicMaterials.Items.Add(basicMaterial);
            }
        }

        /// <summary>
        /// This function clears the subassemblies in producy listbox, loops through the products dictionary of all its subassemblies, and
        /// adds the product to the list box
        /// </summary>
        private void populateSubassembliesInProductListbox()
        {
            lstSubassembliesInProduct.Items.Clear();
            foreach (string subasm in dicProducts[lstProducts.Items[lstProducts.SelectedIndex].ToString()!].Keys)
            {
                lstSubassembliesInProduct.Items.Add(subasm);
            }
        }

        /// <summary>
        /// This function clears the basic materials in subassembly listbox, loops through the subassembly's dictionary of all its basic materials, and
        /// adds the product to the list box
        /// </summary>
        private void populateBasicMaterialsInSubassemblyListbox()
        {
            lstBasicMaterialsInSelectedSubassembly.Items.Clear();
            foreach (string basicMaterial in dicSubassemblies[lstAllSubassemblies.Items[lstAllSubassemblies.SelectedIndex].ToString()!].Keys)
            {
                lstBasicMaterialsInSelectedSubassembly.Items.Add(basicMaterial);
            }
        }
    }
}
