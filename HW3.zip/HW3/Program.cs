﻿using System.Security.AccessControl;

namespace HW3
{
    /// <summary>
    /// Filename: Program.cs
    /// Part of Project: Main Part
    ///
    /// File Purpose:
    /// The purpose of this file is to launch and run the program.
    ///
    /// Program Purpose:
    /// The purpose of the program is to read from a file, 
    /// all data collected over the course of three shifts,
    /// and to make a report that contains the bottles id/value/histogram scaling, 
    /// and the number of bottles (under, on, and off) target, 
    /// and the (lowest, average, and highest) bottle value for each shift.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// A struct for holding the sample data.
        /// </summary>
        struct MeasurementSampleData
        {
            public int id;           //The ID of the bottle observed
            public int value;        //The value of the bottle observed
            public TimeOnly time;    //The time when the bottle was observed
        }
        /// <summary>
        /// A struct for holding all max, min, and averages for all three shifts.
        /// </summary>
        struct Observations
        {
            public int observationTotalFirstShift;    //The total number of bottles observed during first shift.
            public int observationTotalSecondShift;   //The total number of bottles observed during second shift.
            public int observationTotalThirdShift;    //The total number of bottles observed during third shift.
            public int numUnderTargetFirstShift;      //The number of bottles under target observed during first shift.
            public int numUnderTargetSecondShift;     //The number of bottles under target observed during second shift.
            public int numUnderTargetThirdShift;      //The number of bottles under target observed during third shift.
            public int numOnTargetFirstShift;         //The number of bottles on target observed during first shift.
            public int numOnTargetSecondShift;        //The number of bottles on target observed during second shift.
            public int numOnTargetThirdShift;         //The number of bottles on target observed during third shift.
            public int numOverTargetFirstShift;       //The number of bottles over target observed during first shift.
            public int numOverTargetSecondShift;      //The number of bottles over target observed during second shift.
            public int numOverTargetThirdShift;       //The number of bottles over target observed during third shift.
        }
        /// <summary>
        /// A struct for holding all stats.
        /// </summary>
        struct Statistics
        {
            public int minValueObservedFirstShift;         //The lowest value bottle during first shift.
            public int minValueObservedSecondShift;        //The lowest value bottle during second shift.
            public int minValueObservedThirdShift;         //The lowest value bottle during third shift.
            public float averageValueObservedFirstShift;   //The average value bottle during first shift.
            public float averageValueObservedSecondShift;  //The average value bottle during second shift.
            public float averageValueObservedThirdShift;   //The average value bottle during third shift.
            public int maxValueObservedFirstShift;         //The highest value bottle during first shift.
            public int maxValueObservedSecondShift;        //The highest value bottle during second shift.
            public int maxValueObservedThirdShift;         //The highest value bottle during third shift.
        }
        /// <summary>
        /// The main function where everything takes place. 
        /// First the user is asked for a file to read from. Upon entering a vaild file path,
        /// The user is asked for a file to write to. Upon entering a valid file path,
        /// the observations and statistics are generated, written to the output file,
        /// and asks if the user wants the generated data to be displayed.
        /// If the user enters y/Y then the data is displayed to the user.
        /// </summary>
        /// <param name="args">Arguments.</param>
        static void Main(string[] args)
        {
            string? readingFilePath = "";
            string? reportFilePath = "";
            string? veiwReportFileAnswer = "";
            List<MeasurementSampleData> allSampleData = new List<MeasurementSampleData>();
            List<MeasurementSampleData> firstShiftSampleData = new List<MeasurementSampleData>();
            List<MeasurementSampleData> secondShiftSampleData = new List<MeasurementSampleData>();
            List<MeasurementSampleData> thirdShiftSampleData = new List<MeasurementSampleData>();
            Observations observations = new Observations();
            Statistics statistics = new Statistics();
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Title = "Snape Potion Manufacturing Quality Program";
            Console.WriteLine("Please enter the path and the name of the file containing the measurements:");
            readingFilePath = Console.ReadLine();
            if(File.Exists(readingFilePath))
            {
                readDataFromFile(readingFilePath, ref allSampleData);
                allSampleData.Sort((s1, s2) => s1.value.CompareTo(s2.value));
                divideIntoShifts(ref allSampleData, ref firstShiftSampleData, ref secondShiftSampleData, ref thirdShiftSampleData);
                makeObservation(ref firstShiftSampleData, ref secondShiftSampleData, ref thirdShiftSampleData, ref observations);
                generateStatistics(ref firstShiftSampleData, ref secondShiftSampleData, ref thirdShiftSampleData, ref statistics);
                Console.WriteLine("Please enter the path and the name of the report file to generate:");
                reportFilePath = Console.ReadLine();
                if(File.Exists(reportFilePath))
                {
                    writeReportToFile(reportFilePath, allSampleData, observations, statistics);
                    Console.WriteLine("Report File has been generated!");
                    Console.WriteLine("Would you like to see the report file? [Y/n]");
                    veiwReportFileAnswer = Console.ReadLine();
                    if(veiwReportFileAnswer == "Y" || veiwReportFileAnswer == "y")
                    {
                        displayReport(reportFilePath);
                    }
                }
                else
                {
                    Console.WriteLine("File does not exist");
                }
            }
            else
            {
                Console.WriteLine("File does not exist");
            }
        }
        /// <summary>
        /// This function reads the data from a file, splits the data up into a MeasurementSampleData struct,
        /// and adds the sample data struct to the list.
        /// </summary>
        /// <param name="filePath">Path of the file being read from.</param> 
        /// <param name="allSampleData">The reference to the list that will hold all of the data in the file.</param>
        private static void readDataFromFile(string filePath, ref List<MeasurementSampleData> allSampleData)
        /// <param name="filePath">Path of the file being read from.</param>  //end of 8x11 paper here
        {
            string? fileContents;
            System.IO.StreamReader reader;
            reader = System.IO.File.OpenText(filePath);
            while (!reader.EndOfStream)
            {
                fileContents = reader.ReadLine();
                string[] temp = new string[3];
                temp = fileContents.Split("\t");
                MeasurementSampleData sample = new MeasurementSampleData();
                sample.id = Convert.ToInt32(temp[0]);
                sample.value = Convert.ToInt32(temp[1]);
                sample.time = TimeOnly.Parse(temp[2]);
                allSampleData.Add(sample);
            }
            reader.Close();
        }
        /// <summary>
        /// This function loops through each sample data in the list containing all sample data and 
        /// added into a different list depending on which shift the bottle was observed in.
        /// </summary>
        /// <param name="allSampleData">The list containing all sample data observed for the day.</param>
        /// <param name="firstShiftSampleData">The list containing all sample datat observed from first shift.</param>
        /// <param name="secondShiftSampleData">The list containing all sample datat observed from second shift.</param>
        /// <param name="thirdShiftSampleData">The list containing all sample datat observed from third shift.</param>
        private static void divideIntoShifts(ref List<MeasurementSampleData> allSampleData, ref List<MeasurementSampleData> firstShiftSampleData, ref List<MeasurementSampleData> secondShiftSampleData, ref List<MeasurementSampleData> thirdShiftSampleData)
        {
            foreach (MeasurementSampleData sample in allSampleData)
            {
                if (sample.time > TimeOnly.Parse("08:00") && sample.time < TimeOnly.Parse("16:00"))
                {
                    firstShiftSampleData.Add(sample);
                }
                if (sample.time > TimeOnly.Parse("16:00") && sample.time <= TimeOnly.Parse("23:59"))
                {
                    secondShiftSampleData.Add(sample);
                }
                if (sample.time > TimeOnly.Parse("00:00") && sample.time < TimeOnly.Parse("08:00"))
                {
                    thirdShiftSampleData.Add(sample);
                }
            }
        }
        /// <summary>
        /// This function makes all of the observations for all three shifts.
        /// </summary>
        /// <param name="firstShiftSampleData">The list containing all sample datat observed from first shift.</param>
        /// <param name="secondShiftSampleData">The list containing all sample datat observed from second shift.</param>
        /// <param name="thirdShiftSampleData">The list containing all sample datat observed from third shift.</param>
        /// <param name="observations">The observation struct contating all observations for all three shifts.</param>
        private static void makeObservation(ref List<MeasurementSampleData> firstShiftSampleData, ref List<MeasurementSampleData> secondShiftSampleData, ref List<MeasurementSampleData> thirdShiftSampleData, ref Observations observations)
        {
            observations.observationTotalFirstShift = firstShiftSampleData.Count;
            observations.observationTotalSecondShift = secondShiftSampleData.Count;
            observations.observationTotalThirdShift = thirdShiftSampleData.Count;
            foreach (MeasurementSampleData sample in firstShiftSampleData)
            {
                if(sample.value < 1000)
                {
                    observations.numUnderTargetFirstShift++;
                }
                if(sample.value == 1000)
                {
                    observations.numOnTargetFirstShift++;
                }
                if(sample.value > 1000)
                {
                    observations.numOverTargetFirstShift++;
                }
            }
            foreach (MeasurementSampleData sample in secondShiftSampleData)
            {
                if (sample.value < 1000)
                {
                    observations.numUnderTargetSecondShift++;
                }
                if (sample.value == 1000)
                {
                    observations.numOnTargetSecondShift++;
                }
                if (sample.value > 1000)
                {
                    observations.numOverTargetSecondShift++;
                }
            }
            foreach (MeasurementSampleData sample in thirdShiftSampleData)
            {
                if (sample.value < 1000)
                {
                    observations.numUnderTargetThirdShift++;
                }
                if (sample.value == 1000)
                {
                    observations.numOnTargetThirdShift++;
                }
                if (sample.value > 1000)
                {
                    observations.numOverTargetThirdShift++;
                }
            }
        }
        /// <summary>
        /// This function generates the statistics for all three shifts.
        /// </summary>
        /// <param name="firstShiftSampleData">The list containing all sample datat observed from first shift.</param>
        /// <param name="secondShiftSampleData">The list containing all sample datat observed from second shift.</param>
        /// <param name="thirdShiftSampleData">The list containing all sample datat observed from third shift.</param>
        /// <param name="statistics">The statistics struct contatining all stats for all three shifts.</param>
        private static void generateStatistics(ref List<MeasurementSampleData> firstShiftSampleData, ref List<MeasurementSampleData> secondShiftSampleData, ref List<MeasurementSampleData> thirdShiftSampleData, ref Statistics statistics)
        {
            statistics.averageValueObservedFirstShift = 0.00F;
            statistics.averageValueObservedSecondShift = 0.00F;
            statistics.averageValueObservedThirdShift = 0.00F;
            statistics.minValueObservedFirstShift = firstShiftSampleData.Max(sample => sample.value);
            statistics.minValueObservedSecondShift = secondShiftSampleData.Max(sample => sample.value);
            statistics.minValueObservedThirdShift = thirdShiftSampleData.Max(sample => sample.value);
            statistics.averageValueObservedFirstShift = getAverageValue(firstShiftSampleData);
            statistics.averageValueObservedSecondShift = getAverageValue(secondShiftSampleData);
            statistics.averageValueObservedThirdShift = getAverageValue(thirdShiftSampleData);
            statistics.maxValueObservedFirstShift = firstShiftSampleData.Min(sample => sample.value);
            statistics.maxValueObservedSecondShift = secondShiftSampleData.Min(sample => sample.value);
            statistics.maxValueObservedThirdShift = thirdShiftSampleData.Min(sample => sample.value);
        }
        /// <summary>
        /// This functions calculates the average bottle value for any shift. 
        /// It can even calculate all the data if the allSampleData list is passed.
        /// </summary>
        /// <param name="sampleData">The list containing all sample data observed.</param>
        /// <returns>The average value.</returns>
        private static float getAverageValue(List<MeasurementSampleData> sampleData)
        {

            float sum = 0.00F;
            foreach (MeasurementSampleData sample in sampleData)
            { 
                sum += sample.value; 
            }
            return sum/sampleData.Count;
        }
        /// <summary>
        /// This function writes the report to the file.
        /// </summary>
        /// <param name="filePath">The path of the file.</param>
        /// <param name="allSampleData"></param>
        /// <param name="observations"></param>
        /// <param name="statistics"></param>
        private static void writeReportToFile(string filePath, List<MeasurementSampleData> allSampleData, Observations observations, Statistics statistics)
        {
            System.IO.StreamWriter writer = System.IO.File.CreateText(filePath);
            writer.WriteLine(new string('=', 77));
            writer.WriteLine($"{"Snape Potion Manufacturing",55}");
            writer.WriteLine($"{"Manufacturing Shift Quality Report",58}");
            writer.WriteLine(new string('=', 77));
            writer.WriteLine("(ID  ): Value");
            foreach (MeasurementSampleData sampleData in allSampleData)
            {
                writer.WriteLine($"({sampleData.id}) {sampleData.value,4} " + getHisto(sampleData.value, allSampleData));
            }
            writer.WriteLine(new string('=', 77));
            writer.WriteLine($"{"Shift Information",50}");
            writer.WriteLine(new string('=', 77));
            writer.WriteLine($"{"First",39}" + $"{"Second",14}" + $"{"Third",14}");
            writer.WriteLine($"{"-----",39}" + $"{"------",14}" + $"{"-----",14}");
            writer.WriteLine($"{"Observations:",-25}" + $"{observations.observationTotalFirstShift,13}" + $"{observations.observationTotalSecondShift,14}" + $"{observations.observationTotalThirdShift,14}");
            writer.WriteLine($"{"Number Under Target:",-25}" + $"{observations.numUnderTargetFirstShift,13}" + $"{observations.numUnderTargetSecondShift,14}" + $"{observations.numUnderTargetThirdShift,14}");
            writer.WriteLine($"{"Number On Target:",-25}" + $"{observations.numOnTargetFirstShift,13}" + $"{observations.numOnTargetSecondShift,14}" + $"{observations.numOnTargetThirdShift,14}");
            writer.WriteLine($"{"Number Over Target:",-25}" + $"{observations.numOverTargetFirstShift,13}" + $"{observations.numOnTargetSecondShift,14}" + $"{observations.numOnTargetThirdShift,14}");
            writer.WriteLine(" ");
            writer.WriteLine($"{"Statistics:",-25}");
            writer.WriteLine($"{"Minimum Observed:",-25}" + $"{statistics.minValueObservedFirstShift,16:0.00}" + $"{statistics.minValueObservedSecondShift,14:0.00}" + $"{statistics.minValueObservedThirdShift,14:0.00}");
            writer.WriteLine($"{"Average Observed:",-25}" + $"{statistics.averageValueObservedFirstShift,16:0.00}" + $"{statistics.averageValueObservedSecondShift,14:0.00}" + $"{statistics.averageValueObservedThirdShift,14:0.00}");
            writer.WriteLine($"{"Maximum Observed:",-25}" + $"{statistics.maxValueObservedFirstShift,16:0.00}" + $"{statistics.maxValueObservedSecondShift,14:0.00}" + $"{statistics.maxValueObservedThirdShift,14:0.00}");
            writer.WriteLine(new string('=', 77));
            writer.Close();
        }
        /// <summary>
        /// This function makes the histogram scale for each bottle.
        /// </summary>
        /// <param name="value">The bottle value.</param>
        /// <param name="allSampleData">The list containing all sample data.</param>
        /// <returns>The histogram scaling for the bottle.</returns>
        private static string getHisto(int value, List<MeasurementSampleData> allSampleData)
        {
            string hitsoString = "";
            int max = allSampleData.Max(sample => sample.value);
            double histo = 0.00;
            histo = (((double)value / (double)max)) * 65;
            if (value == 1000)
            {
                for (int i = 0; i < Math.Floor(histo); i++)
                {
                    hitsoString += "=";
                }
            }
            else
            {
                for (int i = 0; i < Math.Floor(histo); i++)
                {
                    hitsoString += "*";
                }
            }
            return hitsoString;
        }
        /// <summary>
        /// This function reads the report file and displays the report to the user.
        /// </summary>
        /// <param name="reportFilePath">The path of the report file.</param>
        private static void displayReport(string reportFilePath)
        {
            string? fileContents;
            System.IO.StreamReader reader;
            reader = System.IO.File.OpenText(reportFilePath);
            while (!reader.EndOfStream)
            {
                fileContents = reader.ReadLine();
                Console.WriteLine(fileContents);
            }
            reader.Close();
        }
    }
}   
