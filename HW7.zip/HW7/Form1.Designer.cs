﻿namespace HW7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPlayer2 = new Button();
            lblPlayer1 = new Label();
            lblPlayer2 = new Label();
            btnColumn1 = new Button();
            btnColumn2 = new Button();
            btnColumn3 = new Button();
            btnColumn4 = new Button();
            btnColumn5 = new Button();
            btnColumn6 = new Button();
            btnColumn7 = new Button();
            btnColumn1Slot6 = new Button();
            btnColumn1Slot5 = new Button();
            btnColumn1Slot4 = new Button();
            btnColumn1Slot3 = new Button();
            btnColumn1Slot2 = new Button();
            btnColumn1Slot1 = new Button();
            btnColumn2Slot1 = new Button();
            btnColumn2Slot2 = new Button();
            btnColumn2Slot3 = new Button();
            btnColumn2Slot4 = new Button();
            btnColumn2Slot5 = new Button();
            btnColumn2Slot6 = new Button();
            btnColumn3Slot1 = new Button();
            btnColumn3Slot2 = new Button();
            btnColumn3Slot3 = new Button();
            btnColumn3Slot4 = new Button();
            btnColumn3Slot5 = new Button();
            btnColumn3Slot6 = new Button();
            btnColumn4Slot1 = new Button();
            btnColumn4Slot2 = new Button();
            btnColumn4Slot3 = new Button();
            btnColumn4Slot4 = new Button();
            btnColumn4Slot5 = new Button();
            btnColumn4Slot6 = new Button();
            btnColumn5Slot1 = new Button();
            btnColumn5Slot2 = new Button();
            btnColumn5Slot3 = new Button();
            btnColumn5Slot4 = new Button();
            btnColumn5Slot5 = new Button();
            btnColumn5Slot6 = new Button();
            btnColumn6Slot1 = new Button();
            btnColumn6Slot2 = new Button();
            btnColumn6Slot3 = new Button();
            btnColumn6Slot4 = new Button();
            btnColumn6Slot5 = new Button();
            btnColumn6Slot6 = new Button();
            btnColumn7Slot1 = new Button();
            btnColumn7Slot2 = new Button();
            btnColumn7Slot3 = new Button();
            btnColumn7Slot4 = new Button();
            btnColumn7Slot5 = new Button();
            btnColumn7Slot6 = new Button();
            lblGameWinner = new Label();
            btnResetBoard = new Button();
            btnPlayer1 = new Button();
            SuspendLayout();
            // 
            // btnPlayer2
            // 
            btnPlayer2.BackColor = Color.Gold;
            btnPlayer2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnPlayer2.Location = new Point(589, 162);
            btnPlayer2.Name = "btnPlayer2";
            btnPlayer2.Size = new Size(43, 36);
            btnPlayer2.TabIndex = 1;
            btnPlayer2.Text = "O";
            btnPlayer2.UseVisualStyleBackColor = false;
            btnPlayer2.MouseMove += btnPlayer2_MouseMove;
            // 
            // lblPlayer1
            // 
            lblPlayer1.AutoSize = true;
            lblPlayer1.Location = new Point(12, 135);
            lblPlayer1.Name = "lblPlayer1";
            lblPlayer1.Size = new Size(48, 15);
            lblPlayer1.TabIndex = 2;
            lblPlayer1.Text = "Player 1";
            // 
            // lblPlayer2
            // 
            lblPlayer2.AutoSize = true;
            lblPlayer2.Location = new Point(589, 135);
            lblPlayer2.Name = "lblPlayer2";
            lblPlayer2.Size = new Size(48, 15);
            lblPlayer2.TabIndex = 3;
            lblPlayer2.Text = "Player 2";
            // 
            // btnColumn1
            // 
            btnColumn1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn1.Location = new Point(96, 12);
            btnColumn1.Name = "btnColumn1";
            btnColumn1.Size = new Size(52, 45);
            btnColumn1.TabIndex = 4;
            btnColumn1.Text = "1";
            btnColumn1.UseVisualStyleBackColor = true;
            // 
            // btnColumn2
            // 
            btnColumn2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn2.Location = new Point(163, 12);
            btnColumn2.Name = "btnColumn2";
            btnColumn2.Size = new Size(52, 45);
            btnColumn2.TabIndex = 5;
            btnColumn2.Text = "2";
            btnColumn2.UseVisualStyleBackColor = true;
            // 
            // btnColumn3
            // 
            btnColumn3.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn3.Location = new Point(231, 12);
            btnColumn3.Name = "btnColumn3";
            btnColumn3.Size = new Size(52, 45);
            btnColumn3.TabIndex = 6;
            btnColumn3.Text = "3";
            btnColumn3.UseVisualStyleBackColor = true;
            // 
            // btnColumn4
            // 
            btnColumn4.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn4.Location = new Point(298, 12);
            btnColumn4.Name = "btnColumn4";
            btnColumn4.Size = new Size(52, 45);
            btnColumn4.TabIndex = 7;
            btnColumn4.Text = "4";
            btnColumn4.UseVisualStyleBackColor = true;
            // 
            // btnColumn5
            // 
            btnColumn5.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn5.Location = new Point(365, 12);
            btnColumn5.Name = "btnColumn5";
            btnColumn5.Size = new Size(52, 45);
            btnColumn5.TabIndex = 8;
            btnColumn5.Text = "5";
            btnColumn5.UseVisualStyleBackColor = true;
            // 
            // btnColumn6
            // 
            btnColumn6.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn6.Location = new Point(432, 12);
            btnColumn6.Name = "btnColumn6";
            btnColumn6.Size = new Size(52, 45);
            btnColumn6.TabIndex = 9;
            btnColumn6.Text = "6";
            btnColumn6.UseVisualStyleBackColor = true;
            // 
            // btnColumn7
            // 
            btnColumn7.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnColumn7.Location = new Point(499, 12);
            btnColumn7.Name = "btnColumn7";
            btnColumn7.Size = new Size(52, 45);
            btnColumn7.TabIndex = 10;
            btnColumn7.Text = "7";
            btnColumn7.UseVisualStyleBackColor = true;
            // 
            // btnColumn1Slot6
            // 
            btnColumn1Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn1Slot6.Location = new Point(96, 102);
            btnColumn1Slot6.Name = "btnColumn1Slot6";
            btnColumn1Slot6.Size = new Size(52, 45);
            btnColumn1Slot6.TabIndex = 11;
            btnColumn1Slot6.UseVisualStyleBackColor = true;
            // 
            // btnColumn1Slot5
            // 
            btnColumn1Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn1Slot5.Location = new Point(96, 153);
            btnColumn1Slot5.Name = "btnColumn1Slot5";
            btnColumn1Slot5.Size = new Size(52, 45);
            btnColumn1Slot5.TabIndex = 12;
            btnColumn1Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn1Slot4
            // 
            btnColumn1Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn1Slot4.Location = new Point(96, 204);
            btnColumn1Slot4.Name = "btnColumn1Slot4";
            btnColumn1Slot4.Size = new Size(52, 45);
            btnColumn1Slot4.TabIndex = 13;
            btnColumn1Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn1Slot3
            // 
            btnColumn1Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn1Slot3.Location = new Point(96, 255);
            btnColumn1Slot3.Name = "btnColumn1Slot3";
            btnColumn1Slot3.Size = new Size(52, 45);
            btnColumn1Slot3.TabIndex = 14;
            btnColumn1Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn1Slot2
            // 
            btnColumn1Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn1Slot2.Location = new Point(96, 306);
            btnColumn1Slot2.Name = "btnColumn1Slot2";
            btnColumn1Slot2.Size = new Size(52, 45);
            btnColumn1Slot2.TabIndex = 15;
            btnColumn1Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn1Slot1
            // 
            btnColumn1Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn1Slot1.Location = new Point(96, 357);
            btnColumn1Slot1.Name = "btnColumn1Slot1";
            btnColumn1Slot1.Size = new Size(52, 45);
            btnColumn1Slot1.TabIndex = 16;
            btnColumn1Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn2Slot1
            // 
            btnColumn2Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn2Slot1.Location = new Point(163, 357);
            btnColumn2Slot1.Name = "btnColumn2Slot1";
            btnColumn2Slot1.Size = new Size(52, 45);
            btnColumn2Slot1.TabIndex = 22;
            btnColumn2Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn2Slot2
            // 
            btnColumn2Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn2Slot2.Location = new Point(163, 306);
            btnColumn2Slot2.Name = "btnColumn2Slot2";
            btnColumn2Slot2.Size = new Size(52, 45);
            btnColumn2Slot2.TabIndex = 21;
            btnColumn2Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn2Slot3
            // 
            btnColumn2Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn2Slot3.Location = new Point(163, 255);
            btnColumn2Slot3.Name = "btnColumn2Slot3";
            btnColumn2Slot3.Size = new Size(52, 45);
            btnColumn2Slot3.TabIndex = 20;
            btnColumn2Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn2Slot4
            // 
            btnColumn2Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn2Slot4.Location = new Point(163, 204);
            btnColumn2Slot4.Name = "btnColumn2Slot4";
            btnColumn2Slot4.Size = new Size(52, 45);
            btnColumn2Slot4.TabIndex = 19;
            btnColumn2Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn2Slot5
            // 
            btnColumn2Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn2Slot5.Location = new Point(163, 153);
            btnColumn2Slot5.Name = "btnColumn2Slot5";
            btnColumn2Slot5.Size = new Size(52, 45);
            btnColumn2Slot5.TabIndex = 18;
            btnColumn2Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn2Slot6
            // 
            btnColumn2Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn2Slot6.Location = new Point(163, 102);
            btnColumn2Slot6.Name = "btnColumn2Slot6";
            btnColumn2Slot6.Size = new Size(52, 45);
            btnColumn2Slot6.TabIndex = 17;
            btnColumn2Slot6.UseVisualStyleBackColor = true;
            // 
            // btnColumn3Slot1
            // 
            btnColumn3Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn3Slot1.Location = new Point(231, 357);
            btnColumn3Slot1.Name = "btnColumn3Slot1";
            btnColumn3Slot1.Size = new Size(52, 45);
            btnColumn3Slot1.TabIndex = 28;
            btnColumn3Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn3Slot2
            // 
            btnColumn3Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn3Slot2.Location = new Point(231, 306);
            btnColumn3Slot2.Name = "btnColumn3Slot2";
            btnColumn3Slot2.Size = new Size(52, 45);
            btnColumn3Slot2.TabIndex = 27;
            btnColumn3Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn3Slot3
            // 
            btnColumn3Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn3Slot3.Location = new Point(231, 255);
            btnColumn3Slot3.Name = "btnColumn3Slot3";
            btnColumn3Slot3.Size = new Size(52, 45);
            btnColumn3Slot3.TabIndex = 26;
            btnColumn3Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn3Slot4
            // 
            btnColumn3Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn3Slot4.Location = new Point(231, 204);
            btnColumn3Slot4.Name = "btnColumn3Slot4";
            btnColumn3Slot4.Size = new Size(52, 45);
            btnColumn3Slot4.TabIndex = 25;
            btnColumn3Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn3Slot5
            // 
            btnColumn3Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn3Slot5.Location = new Point(231, 153);
            btnColumn3Slot5.Name = "btnColumn3Slot5";
            btnColumn3Slot5.Size = new Size(52, 45);
            btnColumn3Slot5.TabIndex = 24;
            btnColumn3Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn3Slot6
            // 
            btnColumn3Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn3Slot6.Location = new Point(231, 102);
            btnColumn3Slot6.Name = "btnColumn3Slot6";
            btnColumn3Slot6.Size = new Size(52, 45);
            btnColumn3Slot6.TabIndex = 23;
            btnColumn3Slot6.UseVisualStyleBackColor = true;
            // 
            // btnColumn4Slot1
            // 
            btnColumn4Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn4Slot1.Location = new Point(298, 357);
            btnColumn4Slot1.Name = "btnColumn4Slot1";
            btnColumn4Slot1.Size = new Size(52, 45);
            btnColumn4Slot1.TabIndex = 34;
            btnColumn4Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn4Slot2
            // 
            btnColumn4Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn4Slot2.Location = new Point(298, 306);
            btnColumn4Slot2.Name = "btnColumn4Slot2";
            btnColumn4Slot2.Size = new Size(52, 45);
            btnColumn4Slot2.TabIndex = 33;
            btnColumn4Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn4Slot3
            // 
            btnColumn4Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn4Slot3.Location = new Point(298, 255);
            btnColumn4Slot3.Name = "btnColumn4Slot3";
            btnColumn4Slot3.Size = new Size(52, 45);
            btnColumn4Slot3.TabIndex = 32;
            btnColumn4Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn4Slot4
            // 
            btnColumn4Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn4Slot4.Location = new Point(298, 204);
            btnColumn4Slot4.Name = "btnColumn4Slot4";
            btnColumn4Slot4.Size = new Size(52, 45);
            btnColumn4Slot4.TabIndex = 31;
            btnColumn4Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn4Slot5
            // 
            btnColumn4Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn4Slot5.Location = new Point(298, 153);
            btnColumn4Slot5.Name = "btnColumn4Slot5";
            btnColumn4Slot5.Size = new Size(52, 45);
            btnColumn4Slot5.TabIndex = 30;
            btnColumn4Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn4Slot6
            // 
            btnColumn4Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn4Slot6.Location = new Point(298, 102);
            btnColumn4Slot6.Name = "btnColumn4Slot6";
            btnColumn4Slot6.Size = new Size(52, 45);
            btnColumn4Slot6.TabIndex = 29;
            btnColumn4Slot6.UseVisualStyleBackColor = true;
            // 
            // btnColumn5Slot1
            // 
            btnColumn5Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn5Slot1.Location = new Point(365, 357);
            btnColumn5Slot1.Name = "btnColumn5Slot1";
            btnColumn5Slot1.Size = new Size(52, 45);
            btnColumn5Slot1.TabIndex = 40;
            btnColumn5Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn5Slot2
            // 
            btnColumn5Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn5Slot2.Location = new Point(365, 306);
            btnColumn5Slot2.Name = "btnColumn5Slot2";
            btnColumn5Slot2.Size = new Size(52, 45);
            btnColumn5Slot2.TabIndex = 39;
            btnColumn5Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn5Slot3
            // 
            btnColumn5Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn5Slot3.Location = new Point(365, 255);
            btnColumn5Slot3.Name = "btnColumn5Slot3";
            btnColumn5Slot3.Size = new Size(52, 45);
            btnColumn5Slot3.TabIndex = 38;
            btnColumn5Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn5Slot4
            // 
            btnColumn5Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn5Slot4.Location = new Point(365, 204);
            btnColumn5Slot4.Name = "btnColumn5Slot4";
            btnColumn5Slot4.Size = new Size(52, 45);
            btnColumn5Slot4.TabIndex = 37;
            btnColumn5Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn5Slot5
            // 
            btnColumn5Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn5Slot5.Location = new Point(365, 153);
            btnColumn5Slot5.Name = "btnColumn5Slot5";
            btnColumn5Slot5.Size = new Size(52, 45);
            btnColumn5Slot5.TabIndex = 36;
            btnColumn5Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn5Slot6
            // 
            btnColumn5Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn5Slot6.Location = new Point(365, 102);
            btnColumn5Slot6.Name = "btnColumn5Slot6";
            btnColumn5Slot6.Size = new Size(52, 45);
            btnColumn5Slot6.TabIndex = 35;
            btnColumn5Slot6.UseVisualStyleBackColor = true;
            // 
            // btnColumn6Slot1
            // 
            btnColumn6Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn6Slot1.Location = new Point(432, 357);
            btnColumn6Slot1.Name = "btnColumn6Slot1";
            btnColumn6Slot1.Size = new Size(52, 45);
            btnColumn6Slot1.TabIndex = 46;
            btnColumn6Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn6Slot2
            // 
            btnColumn6Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn6Slot2.Location = new Point(432, 306);
            btnColumn6Slot2.Name = "btnColumn6Slot2";
            btnColumn6Slot2.Size = new Size(52, 45);
            btnColumn6Slot2.TabIndex = 45;
            btnColumn6Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn6Slot3
            // 
            btnColumn6Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn6Slot3.Location = new Point(432, 255);
            btnColumn6Slot3.Name = "btnColumn6Slot3";
            btnColumn6Slot3.Size = new Size(52, 45);
            btnColumn6Slot3.TabIndex = 44;
            btnColumn6Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn6Slot4
            // 
            btnColumn6Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn6Slot4.Location = new Point(432, 204);
            btnColumn6Slot4.Name = "btnColumn6Slot4";
            btnColumn6Slot4.Size = new Size(52, 45);
            btnColumn6Slot4.TabIndex = 43;
            btnColumn6Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn6Slot5
            // 
            btnColumn6Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn6Slot5.Location = new Point(432, 153);
            btnColumn6Slot5.Name = "btnColumn6Slot5";
            btnColumn6Slot5.Size = new Size(52, 45);
            btnColumn6Slot5.TabIndex = 42;
            btnColumn6Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn6Slot6
            // 
            btnColumn6Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn6Slot6.Location = new Point(432, 102);
            btnColumn6Slot6.Name = "btnColumn6Slot6";
            btnColumn6Slot6.Size = new Size(52, 45);
            btnColumn6Slot6.TabIndex = 41;
            btnColumn6Slot6.UseVisualStyleBackColor = true;
            // 
            // btnColumn7Slot1
            // 
            btnColumn7Slot1.Font = new Font("Segoe UI", 15.75F);
            btnColumn7Slot1.Location = new Point(499, 357);
            btnColumn7Slot1.Name = "btnColumn7Slot1";
            btnColumn7Slot1.Size = new Size(52, 45);
            btnColumn7Slot1.TabIndex = 52;
            btnColumn7Slot1.UseVisualStyleBackColor = true;
            // 
            // btnColumn7Slot2
            // 
            btnColumn7Slot2.Font = new Font("Segoe UI", 15.75F);
            btnColumn7Slot2.Location = new Point(499, 306);
            btnColumn7Slot2.Name = "btnColumn7Slot2";
            btnColumn7Slot2.Size = new Size(52, 45);
            btnColumn7Slot2.TabIndex = 51;
            btnColumn7Slot2.UseVisualStyleBackColor = true;
            // 
            // btnColumn7Slot3
            // 
            btnColumn7Slot3.Font = new Font("Segoe UI", 15.75F);
            btnColumn7Slot3.Location = new Point(499, 255);
            btnColumn7Slot3.Name = "btnColumn7Slot3";
            btnColumn7Slot3.Size = new Size(52, 45);
            btnColumn7Slot3.TabIndex = 50;
            btnColumn7Slot3.UseVisualStyleBackColor = true;
            // 
            // btnColumn7Slot4
            // 
            btnColumn7Slot4.Font = new Font("Segoe UI", 15.75F);
            btnColumn7Slot4.Location = new Point(499, 204);
            btnColumn7Slot4.Name = "btnColumn7Slot4";
            btnColumn7Slot4.Size = new Size(52, 45);
            btnColumn7Slot4.TabIndex = 49;
            btnColumn7Slot4.UseVisualStyleBackColor = true;
            // 
            // btnColumn7Slot5
            // 
            btnColumn7Slot5.Font = new Font("Segoe UI", 15.75F);
            btnColumn7Slot5.Location = new Point(499, 153);
            btnColumn7Slot5.Name = "btnColumn7Slot5";
            btnColumn7Slot5.Size = new Size(52, 45);
            btnColumn7Slot5.TabIndex = 48;
            btnColumn7Slot5.UseVisualStyleBackColor = true;
            // 
            // btnColumn7Slot6
            // 
            btnColumn7Slot6.Font = new Font("Segoe UI", 15.75F);
            btnColumn7Slot6.Location = new Point(499, 102);
            btnColumn7Slot6.Name = "btnColumn7Slot6";
            btnColumn7Slot6.Size = new Size(52, 45);
            btnColumn7Slot6.TabIndex = 47;
            btnColumn7Slot6.UseVisualStyleBackColor = true;
            // 
            // lblGameWinner
            // 
            lblGameWinner.AutoSize = true;
            lblGameWinner.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblGameWinner.Location = new Point(163, 419);
            lblGameWinner.Name = "lblGameWinner";
            lblGameWinner.Size = new Size(179, 37);
            lblGameWinner.TabIndex = 53;
            lblGameWinner.Text = "Game Winner";
            lblGameWinner.Visible = false;
            // 
            // btnResetBoard
            // 
            btnResetBoard.Location = new Point(231, 468);
            btnResetBoard.Name = "btnResetBoard";
            btnResetBoard.Size = new Size(186, 47);
            btnResetBoard.TabIndex = 54;
            btnResetBoard.Text = "Reset Board";
            btnResetBoard.UseVisualStyleBackColor = true;
            btnResetBoard.Click += btnResetBoard_Click;
            // 
            // btnPlayer1
            // 
            btnPlayer1.BackColor = Color.Silver;
            btnPlayer1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnPlayer1.Location = new Point(12, 162);
            btnPlayer1.Name = "btnPlayer1";
            btnPlayer1.Size = new Size(43, 36);
            btnPlayer1.TabIndex = 55;
            btnPlayer1.Text = "O";
            btnPlayer1.UseVisualStyleBackColor = false;
            btnPlayer1.MouseMove += btnPlayer1_MouseMove;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(661, 548);
            Controls.Add(btnPlayer1);
            Controls.Add(btnResetBoard);
            Controls.Add(lblGameWinner);
            Controls.Add(btnColumn7Slot1);
            Controls.Add(btnColumn7Slot2);
            Controls.Add(btnColumn7Slot3);
            Controls.Add(btnColumn7Slot4);
            Controls.Add(btnColumn7Slot5);
            Controls.Add(btnColumn7Slot6);
            Controls.Add(btnColumn6Slot1);
            Controls.Add(btnColumn6Slot2);
            Controls.Add(btnColumn6Slot3);
            Controls.Add(btnColumn6Slot4);
            Controls.Add(btnColumn6Slot5);
            Controls.Add(btnColumn6Slot6);
            Controls.Add(btnColumn5Slot1);
            Controls.Add(btnColumn5Slot2);
            Controls.Add(btnColumn5Slot3);
            Controls.Add(btnColumn5Slot4);
            Controls.Add(btnColumn5Slot5);
            Controls.Add(btnColumn5Slot6);
            Controls.Add(btnColumn4Slot1);
            Controls.Add(btnColumn4Slot2);
            Controls.Add(btnColumn4Slot3);
            Controls.Add(btnColumn4Slot4);
            Controls.Add(btnColumn4Slot5);
            Controls.Add(btnColumn4Slot6);
            Controls.Add(btnColumn3Slot1);
            Controls.Add(btnColumn3Slot2);
            Controls.Add(btnColumn3Slot3);
            Controls.Add(btnColumn3Slot4);
            Controls.Add(btnColumn3Slot5);
            Controls.Add(btnColumn3Slot6);
            Controls.Add(btnColumn2Slot1);
            Controls.Add(btnColumn2Slot2);
            Controls.Add(btnColumn2Slot3);
            Controls.Add(btnColumn2Slot4);
            Controls.Add(btnColumn2Slot5);
            Controls.Add(btnColumn2Slot6);
            Controls.Add(btnColumn1Slot1);
            Controls.Add(btnColumn1Slot2);
            Controls.Add(btnColumn1Slot3);
            Controls.Add(btnColumn1Slot4);
            Controls.Add(btnColumn1Slot5);
            Controls.Add(btnColumn1Slot6);
            Controls.Add(btnColumn7);
            Controls.Add(btnColumn6);
            Controls.Add(btnColumn5);
            Controls.Add(btnColumn4);
            Controls.Add(btnColumn3);
            Controls.Add(btnColumn2);
            Controls.Add(btnColumn1);
            Controls.Add(lblPlayer2);
            Controls.Add(lblPlayer1);
            Controls.Add(btnPlayer2);
            Name = "Form1";
            Text = "Drag 'n' Drop Connect Four";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnPlayer2;
        private Label lblPlayer1;
        private Label lblPlayer2;
        private Button btnColumn1;
        private Button btnColumn2;
        private Button btnColumn3;
        private Button btnColumn4;
        private Button btnColumn5;
        private Button btnColumn6;
        private Button btnColumn7;
        private Button btnColumn1Slot6;
        private Button btnColumn1Slot5;
        private Button btnColumn1Slot4;
        private Button btnColumn1Slot3;
        private Button btnColumn1Slot2;
        private Button btnColumn1Slot1;
        private Button btnColumn2Slot1;
        private Button btnColumn2Slot2;
        private Button btnColumn2Slot3;
        private Button btnColumn2Slot4;
        private Button btnColumn2Slot5;
        private Button btnColumn2Slot6;
        private Button btnColumn3Slot1;
        private Button btnColumn3Slot2;
        private Button btnColumn3Slot3;
        private Button btnColumn3Slot4;
        private Button btnColumn3Slot5;
        private Button btnColumn3Slot6;
        private Button btnColumn4Slot1;
        private Button btnColumn4Slot2;
        private Button btnColumn4Slot3;
        private Button btnColumn4Slot4;
        private Button btnColumn4Slot5;
        private Button btnColumn4Slot6;
        private Button btnColumn5Slot1;
        private Button btnColumn5Slot2;
        private Button btnColumn5Slot3;
        private Button btnColumn5Slot4;
        private Button btnColumn5Slot5;
        private Button btnColumn5Slot6;
        private Button btnColumn6Slot1;
        private Button btnColumn6Slot2;
        private Button btnColumn6Slot3;
        private Button btnColumn6Slot4;
        private Button btnColumn6Slot5;
        private Button btnColumn6Slot6;
        private Button btnColumn7Slot1;
        private Button btnColumn7Slot2;
        private Button btnColumn7Slot3;
        private Button btnColumn7Slot4;
        private Button btnColumn7Slot5;
        private Button btnColumn7Slot6;
        private Label lblGameWinner;
        private Button btnResetBoard;
        private Button btnPlayer1;
    }
}
