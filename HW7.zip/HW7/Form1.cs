using System.Data.Common;
using System.Web;

namespace HW7
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: The form for the program
    ///
    /// File Purpose:
    /// The purpose of this file that it contains the main purpose of the program.
    /// This file contains the functionality to allow two users to play a game of tic-tac-toe.
    ///
    /// Program Purpose:
    /// The purpose of this program is to allow two users to play a game of tic-tac-toe.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initializes the form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Sets up the players buttons and the column buttons drag and drop functions and displays a messagebox asking
        /// if player one will go first and changes the properties of the players buttons depending on the answer.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            btnColumn1.AllowDrop = true;
            btnColumn2.AllowDrop = true;
            btnColumn3.AllowDrop = true;
            btnColumn4.AllowDrop = true;
            btnColumn5.AllowDrop = true;
            btnColumn6.AllowDrop = true;
            btnColumn7.AllowDrop = true;

            foreach (Button b in this.Controls.OfType<Button>())
            {
                if (b.Name == "btnPlayer1" || b.Name == "btnPlayer2" || b.Text == "1" || b.Text == "2" || b.Text == "3" || b.Text == "4" || b.Text == "5" || b.Text == "6" || b.Text == "7")
                {
                    b.DragEnter += MixedControls_DragEnter;
                    b.DragOver += MixedControls_DragOver;
                    b.DragDrop += MixedControls_DragDrop;
                    b.DragLeave += MixedControls_DragLeave;
                }
            }
            if (MessageBox.Show("Player 1 goes first?", "First turn", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                btnPlayer1.Enabled = false;
                lblPlayer2.Text = "Player 2 Go!";
            }
            else
            {
                btnPlayer2.Enabled = false;
                lblPlayer1.Text = "Player 1 Go!";
            }
        }
        /// <summary>
        /// Makes it so player one can drag and drop their button
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnPlayer1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == 0)
            {
                return;
            }

            ButtonBase bbase = (ButtonBase)sender;
            DataObject data = new DataObject();
            DragDropEffects effect = DragDropEffects.Move;
            data.SetData(string.Empty);
            effect = bbase.DoDragDrop(data, effect);
        }
        /// <summary>
        /// Makes it so player two can drag and drops their button
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnPlayer2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == 0)
            {
                return;
            }

            ButtonBase bbase = (ButtonBase)sender;
            DataObject data = new DataObject();
            DragDropEffects effect = DragDropEffects.Move;
            data.SetData(string.Empty);
            effect = bbase.DoDragDrop(data, effect);
        }
        /// <summary>
        /// applys the move DragDropEffects to the player and column buttons
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void MixedControls_DragEnter(object? sender, DragEventArgs e)
        {
            Control aControl = (Control)sender!;

            switch (aControl.Text)
            {
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                    e.Effect = DragDropEffects.Move;
                    break;
            }
        }
        /// <summary>
        /// Calls the isPlayable function on the column the user is "hovering over" to see if 
        /// the user can drop their piece in that column. Red and Green are displayed as the buttons
        /// back color indicating whether the user can drop their piece in the column
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void MixedControls_DragOver(object? sender, DragEventArgs e)
        {
            Control aControl = (Control)sender!;

            if (isPlayable(int.Parse(aControl.Text)))
            {
                aControl.BackColor = Color.Green;
            }
            else
            {
                aControl.BackColor = Color.Red;
            }
        }
        /// <summary>
        /// Like in the function above, the isPlayable function is called and if the column is playable
        /// it loops through all slots in the column the first empty slot and then places the players piece 
        /// in the slot by making that slots back color the same as the players and finally it switches turns
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void MixedControls_DragDrop(object? sender, DragEventArgs e)
        {
            Control aControl = (Control)sender!;

            if (isPlayable(int.Parse(aControl.Text)))
            {
                for (int i = 1; i <= 6; i++)
                {
                    if (this.Controls.Find(aControl.Name + "Slot" + i.ToString(), true)[0].Text == string.Empty)
                    {
                        Button b = (Button)this.Controls.Find(aControl.Name + "Slot" + i.ToString(), true)[0];
                        b.Text = "O";
                        switch (whoseTurn())
                        {
                            case 1:
                                b.BackColor = btnPlayer1.BackColor;
                                break;
                            case 2:
                                b.BackColor = btnPlayer2.BackColor;
                                break;
                        }
                        aControl.BackColor = Color.White;
                        switchTurns();
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// Sets the column buttons back color to white when the user leaves the button
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void MixedControls_DragLeave(object? sender, EventArgs e)
        {
            Control aControl = (Control)sender!;
            aControl.BackColor = Color.White;
        }
        /// <summary>
        /// First it checks if there is a winner and displays the correct message if there is 
        /// and switches the turns of the players if there is no winner
        /// </summary>
        private void switchTurns()
        {
            if (isGameWinner().Item1)
            {  
                lblGameWinner.Visible = true;
                lblGameWinner.Text = "Games goes to " + isGameWinner().Item2 + " - ";
                switch (isGameWinner().Item3)
                {
                    case "v":
                        lblGameWinner.Text += "Column " + isGameWinner().Item4;
                        break;
                    case "h":
                        lblGameWinner.Text += "Row " + isGameWinner().Item4;
                        break;
                }
                btnPlayer1.Enabled = false;
                btnPlayer2.Enabled = false;
            }
            else
            {
                if (btnPlayer1.Enabled)
                {
                    btnPlayer1.Enabled = false;
                    lblPlayer1.Text = "Player 1";
                    btnPlayer2.Enabled = true;
                    lblPlayer2.Text = "Player 2 Go!";
                }
                else
                {
                    btnPlayer1.Enabled = true;
                    lblPlayer1.Text = "Player 1 Go!";
                    btnPlayer2.Enabled = false;
                    lblPlayer2.Text = "Player 2";
                }
            }
        }
        /// <summary>
        /// Calls the functions for checking if there was a vertical win or a horizontal win
        /// </summary>
        /// <returns>
        /// A boolean for if there is a winner, int for which player won, string for if it was 
        /// a vertical or horizontal win, and an int for which row/column the win is
        /// </returns>
        private (bool, int, string, int) isGameWinner()
        {
            if (verticalWin().Item1)
            {
                return verticalWin();
            }
            if (horizontalWin().Item1)
            {
                return horizontalWin();
            }
            return (false, 0, string.Empty, 0);
        }
        /// <summary>
        /// Loops through and checks each column for a player to have 4 pieces stacked on each other.
        /// It increments the players tracker (p1 and p2) if their piece is in the slot being checked
        /// but both are wiped if both players pieces are intertwined
        /// </summary>
        /// <returns>
        /// A boolean for if there is a winner, int for which player won, string indicating it was 
        /// a vertical win, and an int for which column the win is
        /// </returns>
        private (bool, int, string, int) verticalWin()
        {
            int p1 = 0;
            int p2 = 0;
            for (int i = 1; i <= 7; i++)
            {
                for (int j = 1; j <= 6; j++)
                {
                    if (this.Controls.Find("btnColumn" + i.ToString() + "Slot" + j.ToString(), true)[0].BackColor == Color.Silver)
                    {
                        if (p2 < 0)
                        {
                            p1 = 0;
                            p2 = 0;
                        }
                        else
                        {
                            p1++;
                            if (p1 == 4)
                            {
                                return (true, 1, "v", i);
                            }
                        }

                    }
                    else if (this.Controls.Find("btnColumn" + i.ToString() + "Slot" + j.ToString(), true)[0].BackColor == Color.Gold)
                    {
                        if (p1 < 0)
                        {
                            p1 = 0;
                            p2 = 0;
                        }
                        else
                        {
                            p2++;
                            if (p2 == 4)
                            {
                                return (true, 2, "v", i);
                            }
                        }
                    }
                }
                p1 = 0; 
                p2 = 0;
            }
            return (false, 0, string.Empty, 0);
        }
        /// <summary>
        /// Loops through and checks each row for a player to have 4 pieces next to each other.
        /// It increments the players tracker (p1 and p2) if their piece is in the slot being checked
        /// but both are wiped if both players pieces are intertwined
        /// </summary>
        /// <returns>
        /// A boolean for if there is a winner, int for which player won, string indicating it was 
        /// a horizontal win, and an int for which row the win is
        /// </returns>
        private (bool, int, string, int) horizontalWin()
        {
            int p1 = 0;
            int p2 = 0;
            for (int i = 1; i <= 6; i++)
            {
                for (int j = 1; j <= 7; j++)
                {
                    if (this.Controls.Find("btnColumn" + j.ToString() + "Slot" + i.ToString(), true)[0].BackColor == Color.Silver)
                    {
                        if (p2 < 0)
                        {
                            p1 = 0;
                            p2 = 0;
                        }
                        else
                        {
                            p1++;
                            if (p1 == 4)
                            {
                                return (true, 1, "h", i);
                            }
                        }

                    }
                    else if (this.Controls.Find("btnColumn" + j.ToString() + "Slot" + i.ToString(), true)[0].BackColor == Color.Gold)
                    {
                        if (p1 < 0)
                        {
                            p1 = 0;
                            p2 = 0;
                        }
                        else
                        {
                            p2++;
                            if (p2 == 4)
                            {
                                return (true, 2, "h", i);
                            }
                        }
                    }
                }
                p1 = 0;
                p2 = 0;
            }
            return (false, 0, string.Empty, 0);
        }
        /// <summary>
        /// Gets which players turn it is at the current moment
        /// </summary>
        /// <returns>An int indicating which players turn it currently is</returns>
        private int whoseTurn()
        {
            if (btnPlayer1.Enabled)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }
        /// <summary>
        /// Check the column the user wants to drop their piece into for an emtpy slot
        /// </summary>
        /// <param name="column">The coilumn the user wants to drop their piece into</param>
        /// <returns>Boolean indicating if there is an empty slot in the column</returns>
        private bool isPlayable(int column)
        {
            int slotNum = 1;
            do
            {
                if (this.Controls.Find("btnColumn" + column.ToString() + "Slot" + slotNum, true)[0].Text == string.Empty)
                {
                    return true;
                }
                slotNum++;
            } while (slotNum <= 6);
            return false;
        }
        /// <summary>
        /// Clears all of the board slots of any pieces and restarts the game and starts with player one 
        /// going first if the board is being resent because there was a winner
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnResetBoard_Click(object sender, EventArgs e)
        {
            foreach (Button b in this.Controls.OfType<Button>())
            {
                if (b.Name != "btnPlayer1" && b.Name != "btnPlayer2" && b.Name != "btnResetBoard" && b.Text != "1" && b.Text != "2" && b.Text != "3" && b.Text != "4" && b.Text != "5" && b.Text != "6" && b.Text != "7")
                {
                    b.Text = string.Empty;
                    b.BackColor = Color.White;
                }
            }
            if (!btnPlayer1.Enabled && !btnPlayer2.Enabled)
            {
                lblPlayer1.Text = "Player 1 Go!";
                lblPlayer2.Text = "Player 2";
                btnPlayer1.Enabled = true;
                lblGameWinner.Visible = false;
            }
        }
    }
}
