﻿namespace HW11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnChangeClockForeground = new Button();
            btnChangeFormBackground = new Button();
            SuspendLayout();
            // 
            // btnChangeClockForeground
            // 
            btnChangeClockForeground.Location = new Point(145, 349);
            btnChangeClockForeground.Name = "btnChangeClockForeground";
            btnChangeClockForeground.Size = new Size(188, 46);
            btnChangeClockForeground.TabIndex = 0;
            btnChangeClockForeground.Text = "Change Clock Foreground";
            btnChangeClockForeground.UseVisualStyleBackColor = true;
            btnChangeClockForeground.Click += btnChangeClockForeground_Click;
            // 
            // btnChangeFormBackground
            // 
            btnChangeFormBackground.Location = new Point(428, 349);
            btnChangeFormBackground.Name = "btnChangeFormBackground";
            btnChangeFormBackground.Size = new Size(188, 46);
            btnChangeFormBackground.TabIndex = 1;
            btnChangeFormBackground.Text = "Change Form Background";
            btnChangeFormBackground.UseVisualStyleBackColor = true;
            btnChangeFormBackground.Click += btnChangeFormBackground_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnChangeFormBackground);
            Controls.Add(btnChangeClockForeground);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button btnChangeClockForeground;
        private Button btnChangeFormBackground;
    }
}
