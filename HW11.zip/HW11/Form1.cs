namespace HW11
{
    public partial class Form1 : Form
    {
        myClockControl.myClock testClock = new myClockControl.myClock();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Controls.Add(testClock);
        }

        private void btnChangeClockForeground_Click(object sender, EventArgs e)
        {
            testClock.ForeColor = Color.Green;
        }

        private void btnChangeFormBackground_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }
    }
}
