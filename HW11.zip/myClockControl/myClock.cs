﻿namespace myClockControl
{
    public partial class myClock : UserControl
    {
        Font arialFont = new Font("Arial", 12, FontStyle.Regular);
        SolidBrush myBrush = new SolidBrush(Color.Black);
        Color currentForeColor = Color.Black;

        public override System.Drawing.Color ForeColor
        {
            get
            {
                return currentForeColor;
            }
            set
            {
                currentForeColor = value;
                this.Invalidate();
            }
        }

        public myClock()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Refresh();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics myGfx = e.Graphics;
            myBrush.Color = currentForeColor;
            myGfx.DrawString(DateTime.Now.ToLongTimeString(), arialFont, myBrush, 10, 10);
        }
    }
}
