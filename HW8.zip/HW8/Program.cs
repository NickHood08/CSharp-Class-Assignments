using System.Data.SqlClient;
using System.Data;
namespace HW8
{
    /// <summary>
    /// Filename: Program.cs
    /// Part of Project: 
    /// Database creation, if one is not already made, and population of database. 
    /// Also to run form1 after database creation.
    ///
    /// File Purpose:
    /// The purpose of this file is that it creates the database, if one is not already made, clears out all tables, 
    /// and populates with a preset data. Then runs Form1.
    ///
    /// Program Purpose:
    /// The purpose of this program is to work as a vetrinary office record system. 
    /// Containing all owners and their registered pets.
    /// </summary>
    internal static class Program
    {

        public const string DBNAME = "VetOffice";                     //Name of the databse
        public const string SERVERNAME = @"(localdb)\MSSQLLocalDB";   //Name of the server
         
        /// <summary>
        ///  The main entry point for the application.
        ///  Creates a databse if one is not already made, then clears out all tables 
        ///  and repopulates them with predetermined data. Lastly it run form1.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string DBPATH = new FileInfo(Application.ExecutablePath).
            Directory!.ToString() + @"\" + DBNAME + ".mdf";

            string CONNECTION = "SERVER=" + SERVERNAME + ";DATABASE=" + DBNAME + 
                ";Integrated Security=SSPI;AttachDbFileName=" + DBPATH;

            if (!System.IO.File.Exists(DBPATH))
            {
                CreateDatabse(SERVERNAME, DBNAME, DBPATH, CONNECTION);
            }

            CleanOutOwnersTable(CONNECTION);
            CleanOutPetsTable(CONNECTION);

            PopulateOwnersTable(CONNECTION);
            PopulatePetsTable(CONNECTION);

            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
        /// <summary>
        /// Creates the database and the tables. 
        /// </summary>
        /// <param name="serverName">The name of the server</param>
        /// <param name="dbName">The name of the database</param>
        /// <param name="dbPath">The path of the database</param>
        /// <param name="connection">The connection string</param>
        static void CreateDatabse(string serverName, string dbName, string dbPath, string connection)
        {
            SqlConnection DBConn;
            string SQLCmd;
            SqlCommand DBCmd;

            DBConn = new SqlConnection("Server=" + serverName);
            SQLCmd = "CREATE DATABASE " + dbName + " On " + "(NAME = '" + dbName + "', " + "FILENAME = '" + dbPath + "')";
            DBCmd = new SqlCommand(SQLCmd, DBConn);

            try
            {
                DBConn.Open();
                DBCmd.ExecuteNonQuery();
                MessageBox.Show("Database was successfully created", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Cannot build database! Closing program down...");
                Application.Exit();
            }

            if (DBConn.State  == ConnectionState.Open)
            {
                DBConn.Close();
            }

            DBConn = new SqlConnection(connection);
            DBConn.Open();

            DBCmd.CommandText = "CREATE TABLE Owners (" +
                "ID int NOT NULL," +
                "OwnerName nvarchar(25) NULL," +
                "OwnerAddress nvarchar(25) NULL," +
                "OwnerCity nvarchar(25) NULL," +
                "OwnerState nvarchar(2) NULL," +
                "OwnerZipCode nvarchar(5) NULL," +
                "OwnerPhoneNumber nvarchar(14) NULL," +
                "PRIMARY KEY CLUSTERED ([ID] ASC))";

            DBCmd.Connection = DBConn;
            try
            {
                DBCmd.ExecuteNonQuery();
                MessageBox.Show("Created Owners Table");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Owners Table Already Exists");
            }

            DBCmd.CommandText = "CREATE TABLE Pets (" +
                "ID int NOT NULL," +
                "PetName nvarchar(15) NULL," +
                "PetSpecies nvarchar(15) NULL," +
                "PetBirthdate nvarchar(10) NULL," +
                "PetLastVisitDate nvarchar(10) NULL," +
                "OwnerID int NULL," +
                "PRIMARY KEY CLUSTERED ([ID] ASC))";

            DBCmd.Connection = DBConn;
            try
            {
                DBCmd.ExecuteNonQuery();
                MessageBox.Show("Created Pets Table");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Pets Table Already Exists");
            }

            if (DBConn.State == ConnectionState.Open)
            {
                DBConn.Close();
            }
        }
        /// <summary>
        /// Clears out the Owners table
        /// </summary>
        /// <param name="conn">The connection string</param>
        static void CleanOutOwnersTable(string conn)
        {
            SqlConnection DBConn;
            SqlCommand DBCmd = new SqlCommand();

            DBConn = new SqlConnection(conn);
            DBConn.Open();

            DBCmd.CommandText = "DELETE FROM Owners";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();
            DBConn.Close();
            MessageBox.Show("Deleted Everything in Owners Table");
        }
        /// <summary>
        /// Clears out the pets table
        /// </summary>
        /// <param name="conn">The connection string</param>
        static void CleanOutPetsTable(string conn)
        {
            SqlConnection DBConn;
            SqlCommand DBCmd = new SqlCommand();

            DBConn = new SqlConnection(conn);
            DBConn.Open();

            DBCmd.CommandText = "DELETE FROM Pets";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();
            DBConn.Close();
            MessageBox.Show("Deleted Everything in Pets Table");
        }
        /// <summary>
        /// Populates the owners table with preset data
        /// </summary>
        /// <param name="conn">The connection string</param>
        static void PopulateOwnersTable(string conn)
        {
            SqlConnection DBConn;
            SqlCommand DBCmd = new SqlCommand();

            DBConn = new SqlConnection(conn);
            DBConn.Open();

            DBCmd.CommandText = "INSERT INTO Owners " +
                "(ID, OwnerName, OwnerAddress, OwnerCity, OwnerState, OwnerZipCode, OwnerPhoneNumber) " +
                "VALUES ('1','John Smith','123 Elm','Saginaw','MI','48604','(989) 555-5555')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Owners " +
                "(ID, OwnerName, OwnerAddress, OwnerCity, OwnerState, OwnerZipCode, OwnerPhoneNumber) " +
                "VALUES ('2','Sue Jones','456 Oak','Flint','MI','48502','(810) 777-7777')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Owners " +
                "(ID, OwnerName, OwnerAddress, OwnerCity, OwnerState, OwnerZipCode, OwnerPhoneNumber) " +
                "VALUES ('3','Phil Williams','789 Pine','Birch Run','MI','48415','(989) 111-1111')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Owners " +
                "(ID, OwnerName, OwnerAddress, OwnerCity, OwnerState, OwnerZipCode, OwnerPhoneNumber) " +
                "VALUES ('4','Ann Taylor','654 Aspen','Burt','MI','48417','(989) 222-2222')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBConn.Close();
            MessageBox.Show("Added all Owners To Owners Table");
        }
        /// <summary>
        /// Populates the pets table with preset data
        /// </summary>
        /// <param name="conn"></param>
        static void PopulatePetsTable(string conn)
        {
            SqlConnection DBConn;
            SqlCommand DBCmd = new SqlCommand();

            DBConn = new SqlConnection(conn);
            DBConn.Open();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('1','Zippy','Turtle','10/15/2019','11/13/2019','1')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('2','Tabby','Calico Cat','9/15/2018','6/4/2019','1')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('3','Fido','Schnauzer','4/4/2018','8/7/2019','2')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('4','Buddy','Guinea Pig','7/11/2019','9/19/2019','2')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('5','Sally','GoldFish','10/12/2019','10/15/2019','3')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('6','Wilbur','Pig','1/4/2019','6/30/2019','4')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('7','Sam','Flamingo','11/15/2019','11/30/2019','4')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('8','Floyd','Toad','4/4/2019','6/23/2019','4')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBCmd.CommandText = "INSERT INTO Pets " +
                "(ID, PetName, PetSpecies, PetBirthdate, PetLastVisitDate, OwnerID) " +
                "VALUES ('9','Davey','Velociraptor','2/24/2018','5/6/2019','4')";
            DBCmd.Connection = DBConn;
            DBCmd.ExecuteNonQuery();

            DBConn.Close();
            MessageBox.Show("Added all Pets To Pets Table");
        }
    }
}