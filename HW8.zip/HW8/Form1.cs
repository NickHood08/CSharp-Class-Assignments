using System.Data;
using System.Data.SqlClient;
namespace HW8
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: 
    /// The main functionality takes place here. The user can traverse all owners in the database and 
    /// update their info or delete them and their pets from the database. The user can also add a new owner to the database.
    ///
    /// File Purpose:
    /// The purpose of this file is the user can traverse all owners in the database and 
    /// update their info or delete them and their pets from the database. The user can also add a new owner to the database.
    ///
    /// Program Purpose:
    /// The purpose of this program is to work as a vetrinary office record system. 
    /// Containing all owners and their registered pets.
    /// </summary>
    public partial class Form1 : Form
    {
        static DataSet dsOwners = new DataSet();                                          // Dataset of the owners
        static DataSet dsPets = new DataSet();                                            // Dataset of the owners pets
        const string DBNAME = "VetOffice";                                                // The name of the database
        const string SERVERNAME = @"(localdb)\MSSQLLocalDB";                              // The name of the server
        static string DBPATH = new FileInfo(Application.ExecutablePath).
            Directory!.ToString() + @"\" + DBNAME + ".mdf";                               // The path of the database
        static string CONNECTION = "SERVER=" + SERVERNAME + ";DATABASE=" +                 
            DBNAME + ";Integrated Security=SSPI;AttachDbFileName=" +
            DBPATH;                                                                       // The connection to the database
        SqlConnection myConn = new SqlConnection(CONNECTION);                             // The connection to the database
        SqlDataAdapter? DBAdaptOwners;                                                    // Data adapter for owners
        SqlDataAdapter? DBAdaptPets;                                                      // Data adapter for pets

        bool addingNewOwner;                                                              // Boolean for determining if the user is
                                                                                          // adding a new record or updating one

        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Fills the owners dataset with all owners in the database
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            string SQLCmd;

            SQLCmd = "Select * From Owners";
            DBAdaptOwners = new SqlDataAdapter(SQLCmd, CONNECTION);
            DBAdaptOwners.Fill(dsOwners, "Owners");

            txtOwnerName.DataBindings.Add(new Binding("Text", dsOwners, "Owners.OwnerName"));
            txtOwnerID.DataBindings.Add(new Binding("Text", dsOwners, "Owners.ID"));
            txtOwnerAddress.DataBindings.Add(new Binding("Text", dsOwners, "Owners.OwnerAddress"));
            txtOwnerCity.DataBindings.Add(new Binding("Text", dsOwners, "Owners.OwnerCity"));
            txtOwnerState.DataBindings.Add(new Binding("Text", dsOwners, "Owners.OwnerState"));
            txtOwnerZipCode.DataBindings.Add(new Binding("Text", dsOwners, "Owners.OwnerZipCode"));
            txtOwnerPhoneNumber.DataBindings.Add(new Binding("Text", dsOwners, "Owners.OwnerPhoneNumber"));
        }
        /// <summary>
        /// Traverses to the first owner record
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnTraverseToFirstOwner_Click(object sender, EventArgs e)
        {
            BindingContext![dsOwners, "Owners"].Position = 0;
        }
        /// <summary>
        /// Traverses one owner record backwards
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnTraverseBackOne_Click(object sender, EventArgs e)
        {
            BindingContext![dsOwners, "Owners"].Position = (BindingContext[dsOwners, "Owners"].Position - 1);
        }
        /// <summary>
        /// Traveres one owner record to the right
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnTraverseRightOne_Click(object sender, EventArgs e)
        {
            BindingContext![dsOwners, "Owners"].Position = (BindingContext[dsOwners, "Owners"].Position + 1);
        }
        /// <summary>
        /// Traverses to the last owner record 
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnTraverseToLastOwner_Click(object sender, EventArgs e)
        {
            BindingContext![dsOwners, "Owners"].Position = (dsOwners.Tables["Owners"]!.Rows.Count);
        }
        /// <summary>
        /// Makes a new record in the database and switches the boolean for
        /// determining if the user is adding a new user or updating one
        /// then calls the switchTextBox function
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnAddNewOwner_Click(object sender, EventArgs e)
        {
            BindingContext![dsOwners, "Owners"].EndCurrentEdit();
            BindingContext![dsOwners, "Owners"].AddNew();
            addingNewOwner = true;
            switchTextBoxesEnabled();
        }
        /// <summary>
        /// Deletes the owner and their pets from the database
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnDeleteOwner_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show($"Are you sure you want to delete this record? (This will also delete any onwers pets from our records too)", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                myConn.Open();
                SqlCommand cmd = new SqlCommand("Delete Owners where ID ='" + txtOwnerID.Text + "'", myConn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Deleted Successfully.");
                myConn.Close();

                myConn.Open();
                SqlCommand cmd2 = new SqlCommand("Delete Pets where OwnerID ='" + txtOwnerID.Text + "'", myConn);
                cmd2.ExecuteNonQuery();
                MessageBox.Show("Data Deleted Successfully.");
                myConn.Close();

                dsOwners.Clear();
                DBAdaptOwners!.Fill(dsOwners, "Owners");
                BindingContext![dsOwners, "Owners"].Position = BindingContext![dsOwners, "Owners"].Position;
            }
        }
        /// <summary>
        /// sets the boolean for determining if the user is updating a record or adding a new one to false
        /// and calls the switchTextBoxes function to switch the textboxes enabled property
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnUpdateOwner_Click(object sender, EventArgs e)
        {
            addingNewOwner = false;
            switchTextBoxesEnabled();
        }
        /// <summary>
        /// Saves the changes the user is making
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            SqlCommandBuilder myBuilder = new SqlCommandBuilder(DBAdaptOwners);
            myBuilder.GetUpdateCommand();
            BindingContext![dsOwners, "Owners"].EndCurrentEdit();
            myConn.Open();
            DBAdaptOwners!.Update(dsOwners, "Owners");
            myConn.Close();
            dsOwners.AcceptChanges();
            addingNewOwner = false;
            switchTextBoxesEnabled();
        }
        /// <summary>
        /// Cancels the changes the user is making
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnCancelChanges_Click(object sender, EventArgs e)
        {
            BindingContext![dsOwners, "Owners"].CancelCurrentEdit();
            if (addingNewOwner)
            {
                BindingContext![dsOwners, "Owners"].Position = dsOwners.Tables["Owners"]!.Rows.Count;
                addingNewOwner = false;
            }
            switchTextBoxesEnabled();
        }
        /// <summary>
        /// Switches the enabled property of the textboxes and 
        /// clears out the textboxes if the user is trying to add a new owner
        /// </summary>
        private void switchTextBoxesEnabled()
        {
            if (addingNewOwner)
            {
                txtOwnerName.Text = string.Empty;
                txtOwnerAddress.Text = string.Empty;
                txtOwnerCity.Text = string.Empty;
                txtOwnerState.Text = string.Empty;
                txtOwnerZipCode.Text = string.Empty;
                txtOwnerPhoneNumber.Text = string.Empty;
                txtOwnerID.Text = dsOwners.Tables["Owners"]!.Rows.Count + 1 + "";
            }

            if (txtOwnerName.Enabled)
            {
                txtOwnerName.Enabled = false;
                txtOwnerAddress.Enabled = false;
                txtOwnerCity.Enabled = false;
                txtOwnerState.Enabled = false;
                txtOwnerZipCode.Enabled = false;
                txtOwnerPhoneNumber.Enabled = false;
                btnSaveChanges.Visible = false;
                btnCancelChanges.Visible = false;
            }
            else
            {
                txtOwnerName.Enabled = true;
                txtOwnerAddress.Enabled = true;
                txtOwnerCity.Enabled = true;
                txtOwnerState.Enabled = true;
                txtOwnerZipCode.Enabled = true;
                txtOwnerPhoneNumber.Enabled = true;
                btnSaveChanges.Visible = true;
                btnCancelChanges.Visible = true;
            }
        }
        /// <summary>
        /// Gets the pets the owner has and displays them in the data grid view.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Args</param>
        private void txtOwnerID_TextChanged(object sender, EventArgs e)
        {
            string SQLCmd;
            SqlCommandBuilder cmdBuilder;
            SQLCmd = "Select * From Pets Where OwnerID = '" + txtOwnerID.Text.Trim() + "'";
            DBAdaptPets = new SqlDataAdapter(SQLCmd, CONNECTION);
            cmdBuilder = new SqlCommandBuilder(DBAdaptPets);
            DBAdaptPets.InsertCommand = cmdBuilder.GetInsertCommand();
            dsPets.Clear();
            DBAdaptPets.Fill(dsPets, "Pets");
            dgvOwnersPets.DataSource = dsPets.Tables["Pets"];
        }
    }
}
