﻿namespace HW8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpOwnerInfo = new GroupBox();
            btnCancelChanges = new Button();
            btnSaveChanges = new Button();
            btnTraverseToLastOwner = new Button();
            btnTraverseRightOne = new Button();
            btnUpdateOwner = new Button();
            btnDeleteOwner = new Button();
            btnAddNewOwner = new Button();
            btnTraverseBackOne = new Button();
            btnTraverseToFirstOwner = new Button();
            txtOwnerID = new TextBox();
            label4 = new Label();
            txtOwnerPhoneNumber = new TextBox();
            txtOwnerZipCode = new TextBox();
            txtOwnerState = new TextBox();
            txtOwnerCity = new TextBox();
            txtOwnerAddress = new TextBox();
            txtOwnerName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dgvOwnersPets = new DataGridView();
            grpOwnerInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOwnersPets).BeginInit();
            SuspendLayout();
            // 
            // grpOwnerInfo
            // 
            grpOwnerInfo.Controls.Add(btnCancelChanges);
            grpOwnerInfo.Controls.Add(btnSaveChanges);
            grpOwnerInfo.Controls.Add(btnTraverseToLastOwner);
            grpOwnerInfo.Controls.Add(btnTraverseRightOne);
            grpOwnerInfo.Controls.Add(btnUpdateOwner);
            grpOwnerInfo.Controls.Add(btnDeleteOwner);
            grpOwnerInfo.Controls.Add(btnAddNewOwner);
            grpOwnerInfo.Controls.Add(btnTraverseBackOne);
            grpOwnerInfo.Controls.Add(btnTraverseToFirstOwner);
            grpOwnerInfo.Controls.Add(txtOwnerID);
            grpOwnerInfo.Controls.Add(label4);
            grpOwnerInfo.Controls.Add(txtOwnerPhoneNumber);
            grpOwnerInfo.Controls.Add(txtOwnerZipCode);
            grpOwnerInfo.Controls.Add(txtOwnerState);
            grpOwnerInfo.Controls.Add(txtOwnerCity);
            grpOwnerInfo.Controls.Add(txtOwnerAddress);
            grpOwnerInfo.Controls.Add(txtOwnerName);
            grpOwnerInfo.Controls.Add(label3);
            grpOwnerInfo.Controls.Add(label2);
            grpOwnerInfo.Controls.Add(label1);
            grpOwnerInfo.Location = new Point(12, 12);
            grpOwnerInfo.Name = "grpOwnerInfo";
            grpOwnerInfo.Size = new Size(783, 293);
            grpOwnerInfo.TabIndex = 0;
            grpOwnerInfo.TabStop = false;
            grpOwnerInfo.Text = "Owner Info";
            // 
            // btnCancelChanges
            // 
            btnCancelChanges.Location = new Point(391, 241);
            btnCancelChanges.Name = "btnCancelChanges";
            btnCancelChanges.Size = new Size(83, 33);
            btnCancelChanges.TabIndex = 20;
            btnCancelChanges.Text = "Cancel";
            btnCancelChanges.UseVisualStyleBackColor = true;
            btnCancelChanges.Visible = false;
            btnCancelChanges.Click += btnCancelChanges_Click;
            // 
            // btnSaveChanges
            // 
            btnSaveChanges.Location = new Point(254, 241);
            btnSaveChanges.Name = "btnSaveChanges";
            btnSaveChanges.Size = new Size(83, 33);
            btnSaveChanges.TabIndex = 19;
            btnSaveChanges.Text = "Save";
            btnSaveChanges.UseVisualStyleBackColor = true;
            btnSaveChanges.Visible = false;
            btnSaveChanges.Click += btnSaveChanges_Click;
            // 
            // btnTraverseToLastOwner
            // 
            btnTraverseToLastOwner.Location = new Point(685, 190);
            btnTraverseToLastOwner.Name = "btnTraverseToLastOwner";
            btnTraverseToLastOwner.Size = new Size(51, 33);
            btnTraverseToLastOwner.TabIndex = 17;
            btnTraverseToLastOwner.Text = "|>";
            btnTraverseToLastOwner.UseVisualStyleBackColor = true;
            btnTraverseToLastOwner.Click += btnTraverseToLastOwner_Click;
            // 
            // btnTraverseRightOne
            // 
            btnTraverseRightOne.Location = new Point(628, 190);
            btnTraverseRightOne.Name = "btnTraverseRightOne";
            btnTraverseRightOne.Size = new Size(51, 33);
            btnTraverseRightOne.TabIndex = 16;
            btnTraverseRightOne.Text = ">>";
            btnTraverseRightOne.UseVisualStyleBackColor = true;
            btnTraverseRightOne.Click += btnTraverseRightOne_Click;
            // 
            // btnUpdateOwner
            // 
            btnUpdateOwner.Location = new Point(414, 190);
            btnUpdateOwner.Name = "btnUpdateOwner";
            btnUpdateOwner.Size = new Size(83, 33);
            btnUpdateOwner.TabIndex = 15;
            btnUpdateOwner.Text = "Update";
            btnUpdateOwner.UseVisualStyleBackColor = true;
            btnUpdateOwner.Click += btnUpdateOwner_Click;
            // 
            // btnDeleteOwner
            // 
            btnDeleteOwner.Location = new Point(325, 190);
            btnDeleteOwner.Name = "btnDeleteOwner";
            btnDeleteOwner.Size = new Size(83, 33);
            btnDeleteOwner.TabIndex = 14;
            btnDeleteOwner.Text = "Delete";
            btnDeleteOwner.UseVisualStyleBackColor = true;
            btnDeleteOwner.Click += btnDeleteOwner_Click;
            // 
            // btnAddNewOwner
            // 
            btnAddNewOwner.Location = new Point(236, 190);
            btnAddNewOwner.Name = "btnAddNewOwner";
            btnAddNewOwner.Size = new Size(83, 33);
            btnAddNewOwner.TabIndex = 13;
            btnAddNewOwner.Text = "Add";
            btnAddNewOwner.UseVisualStyleBackColor = true;
            btnAddNewOwner.Click += btnAddNewOwner_Click;
            // 
            // btnTraverseBackOne
            // 
            btnTraverseBackOne.Location = new Point(107, 190);
            btnTraverseBackOne.Name = "btnTraverseBackOne";
            btnTraverseBackOne.Size = new Size(51, 33);
            btnTraverseBackOne.TabIndex = 12;
            btnTraverseBackOne.Text = "<<";
            btnTraverseBackOne.UseVisualStyleBackColor = true;
            btnTraverseBackOne.Click += btnTraverseBackOne_Click;
            // 
            // btnTraverseToFirstOwner
            // 
            btnTraverseToFirstOwner.Location = new Point(50, 190);
            btnTraverseToFirstOwner.Name = "btnTraverseToFirstOwner";
            btnTraverseToFirstOwner.Size = new Size(51, 33);
            btnTraverseToFirstOwner.TabIndex = 11;
            btnTraverseToFirstOwner.Text = "<|";
            btnTraverseToFirstOwner.UseVisualStyleBackColor = true;
            btnTraverseToFirstOwner.Click += btnTraverseToFirstOwner_Click;
            // 
            // txtOwnerID
            // 
            txtOwnerID.Enabled = false;
            txtOwnerID.Location = new Point(644, 27);
            txtOwnerID.Name = "txtOwnerID";
            txtOwnerID.Size = new Size(46, 23);
            txtOwnerID.TabIndex = 10;
            txtOwnerID.TextChanged += txtOwnerID_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(570, 30);
            label4.Name = "label4";
            label4.Size = new Size(68, 15);
            label4.TabIndex = 9;
            label4.Text = "ID Number:";
            // 
            // txtOwnerPhoneNumber
            // 
            txtOwnerPhoneNumber.Enabled = false;
            txtOwnerPhoneNumber.Location = new Point(76, 143);
            txtOwnerPhoneNumber.Name = "txtOwnerPhoneNumber";
            txtOwnerPhoneNumber.Size = new Size(170, 23);
            txtOwnerPhoneNumber.TabIndex = 8;
            // 
            // txtOwnerZipCode
            // 
            txtOwnerZipCode.Enabled = false;
            txtOwnerZipCode.Location = new Point(316, 102);
            txtOwnerZipCode.Name = "txtOwnerZipCode";
            txtOwnerZipCode.Size = new Size(72, 23);
            txtOwnerZipCode.TabIndex = 7;
            // 
            // txtOwnerState
            // 
            txtOwnerState.Enabled = false;
            txtOwnerState.Location = new Point(264, 102);
            txtOwnerState.Name = "txtOwnerState";
            txtOwnerState.Size = new Size(36, 23);
            txtOwnerState.TabIndex = 6;
            // 
            // txtOwnerCity
            // 
            txtOwnerCity.Enabled = false;
            txtOwnerCity.Location = new Point(76, 102);
            txtOwnerCity.Name = "txtOwnerCity";
            txtOwnerCity.Size = new Size(170, 23);
            txtOwnerCity.TabIndex = 5;
            // 
            // txtOwnerAddress
            // 
            txtOwnerAddress.Enabled = false;
            txtOwnerAddress.Location = new Point(76, 73);
            txtOwnerAddress.Name = "txtOwnerAddress";
            txtOwnerAddress.Size = new Size(170, 23);
            txtOwnerAddress.TabIndex = 4;
            // 
            // txtOwnerName
            // 
            txtOwnerName.Enabled = false;
            txtOwnerName.Location = new Point(76, 27);
            txtOwnerName.Name = "txtOwnerName";
            txtOwnerName.Size = new Size(170, 23);
            txtOwnerName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 146);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 2;
            label3.Text = "Phone:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 76);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 1;
            label2.Text = "Address:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 30);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // dgvOwnersPets
            // 
            dgvOwnersPets.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOwnersPets.Location = new Point(12, 311);
            dgvOwnersPets.Name = "dgvOwnersPets";
            dgvOwnersPets.Size = new Size(776, 311);
            dgvOwnersPets.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 634);
            Controls.Add(dgvOwnersPets);
            Controls.Add(grpOwnerInfo);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            grpOwnerInfo.ResumeLayout(false);
            grpOwnerInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOwnersPets).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpOwnerInfo;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView dgvOwnersPets;
        private Button btnTraverseBackOne;
        private Button btnTraverseToFirstOwner;
        private TextBox txtOwnerID;
        private Label label4;
        private TextBox txtOwnerPhoneNumber;
        private TextBox txtOwnerZipCode;
        private TextBox txtOwnerState;
        private TextBox txtOwnerCity;
        private TextBox txtOwnerAddress;
        private TextBox txtOwnerName;
        private Button btnCancelChanges;
        private Button btnSaveChanges;
        private Button btnTraverseToLastOwner;
        private Button btnTraverseRightOne;
        private Button btnUpdateOwner;
        private Button btnDeleteOwner;
        private Button btnAddNewOwner;
    }
}
