﻿namespace HW10Client
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtGameLog = new TextBox();
            lblGameWinner = new Label();
            label1 = new Label();
            grpNetworkSettings = new GroupBox();
            grpClientSettings = new GroupBox();
            btnStopClient = new Button();
            btnStartClient = new Button();
            txtServerPort = new TextBox();
            label3 = new Label();
            txtServerAddress = new TextBox();
            label2 = new Label();
            grpNetworkEnd = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            btnClientPot = new Button();
            btnServer5 = new Button();
            btnClient1 = new Button();
            btnServer4 = new Button();
            btnClient2 = new Button();
            btnServer3 = new Button();
            btnClient3 = new Button();
            btnServer2 = new Button();
            btnClient4 = new Button();
            btnClient5 = new Button();
            btnServer1 = new Button();
            btnServerPot = new Button();
            grpNetworkSettings.SuspendLayout();
            grpClientSettings.SuspendLayout();
            grpNetworkEnd.SuspendLayout();
            SuspendLayout();
            // 
            // txtGameLog
            // 
            txtGameLog.Location = new Point(12, 217);
            txtGameLog.Multiline = true;
            txtGameLog.Name = "txtGameLog";
            txtGameLog.ReadOnly = true;
            txtGameLog.Size = new Size(547, 209);
            txtGameLog.TabIndex = 49;
            // 
            // lblGameWinner
            // 
            lblGameWinner.AutoSize = true;
            lblGameWinner.Font = new Font("Segoe UI", 18.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblGameWinner.Location = new Point(121, 169);
            lblGameWinner.Name = "lblGameWinner";
            lblGameWinner.Size = new Size(166, 35);
            lblGameWinner.TabIndex = 48;
            lblGameWinner.Text = "Game Winner";
            lblGameWinner.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 199);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 47;
            label1.Text = "Game Log:";
            // 
            // grpNetworkSettings
            // 
            grpNetworkSettings.Controls.Add(grpClientSettings);
            grpNetworkSettings.Controls.Add(grpNetworkEnd);
            grpNetworkSettings.Location = new Point(586, 15);
            grpNetworkSettings.Name = "grpNetworkSettings";
            grpNetworkSettings.Size = new Size(263, 244);
            grpNetworkSettings.TabIndex = 46;
            grpNetworkSettings.TabStop = false;
            grpNetworkSettings.Text = "Network Settings:";
            // 
            // grpClientSettings
            // 
            grpClientSettings.Controls.Add(btnStopClient);
            grpClientSettings.Controls.Add(btnStartClient);
            grpClientSettings.Controls.Add(txtServerPort);
            grpClientSettings.Controls.Add(label3);
            grpClientSettings.Controls.Add(txtServerAddress);
            grpClientSettings.Controls.Add(label2);
            grpClientSettings.Location = new Point(6, 85);
            grpClientSettings.Name = "grpClientSettings";
            grpClientSettings.Size = new Size(251, 153);
            grpClientSettings.TabIndex = 15;
            grpClientSettings.TabStop = false;
            // 
            // btnStopClient
            // 
            btnStopClient.Location = new Point(16, 124);
            btnStopClient.Name = "btnStopClient";
            btnStopClient.Size = new Size(216, 23);
            btnStopClient.TabIndex = 5;
            btnStopClient.Text = "Stop Client";
            btnStopClient.UseVisualStyleBackColor = true;
            btnStopClient.Click += btnStopClient_Click;
            // 
            // btnStartClient
            // 
            btnStartClient.Location = new Point(16, 91);
            btnStartClient.Name = "btnStartClient";
            btnStartClient.Size = new Size(216, 23);
            btnStartClient.TabIndex = 4;
            btnStartClient.Text = "Start Client";
            btnStartClient.UseVisualStyleBackColor = true;
            btnStartClient.Click += btnStartClient_Click;
            // 
            // txtServerPort
            // 
            txtServerPort.Location = new Point(145, 56);
            txtServerPort.Name = "txtServerPort";
            txtServerPort.Size = new Size(100, 23);
            txtServerPort.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 59);
            label3.Name = "label3";
            label3.Size = new Size(67, 15);
            label3.TabIndex = 2;
            label3.Text = "Server Port:";
            // 
            // txtServerAddress
            // 
            txtServerAddress.Location = new Point(145, 22);
            txtServerAddress.Name = "txtServerAddress";
            txtServerAddress.Size = new Size(100, 23);
            txtServerAddress.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 25);
            label2.Name = "label2";
            label2.Size = new Size(87, 15);
            label2.TabIndex = 0;
            label2.Text = "Server Address:";
            // 
            // grpNetworkEnd
            // 
            grpNetworkEnd.Controls.Add(radioButton2);
            grpNetworkEnd.Controls.Add(radioButton1);
            grpNetworkEnd.Enabled = false;
            grpNetworkEnd.Location = new Point(6, 22);
            grpNetworkEnd.Name = "grpNetworkEnd";
            grpNetworkEnd.Size = new Size(251, 57);
            grpNetworkEnd.TabIndex = 14;
            grpNetworkEnd.TabStop = false;
            grpNetworkEnd.Text = "Network End:";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Checked = true;
            radioButton2.Location = new Point(153, 22);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(56, 19);
            radioButton2.TabIndex = 14;
            radioButton2.TabStop = true;
            radioButton2.Text = "Client";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(57, 22);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(57, 19);
            radioButton1.TabIndex = 0;
            radioButton1.Text = "Server";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // btnClientPot
            // 
            btnClientPot.Location = new Point(501, 15);
            btnClientPot.Name = "btnClientPot";
            btnClientPot.Size = new Size(58, 142);
            btnClientPot.TabIndex = 45;
            btnClientPot.Text = "0";
            btnClientPot.UseVisualStyleBackColor = true;
            // 
            // btnServer5
            // 
            btnServer5.Enabled = false;
            btnServer5.Location = new Point(414, 24);
            btnServer5.Name = "btnServer5";
            btnServer5.Size = new Size(59, 49);
            btnServer5.TabIndex = 44;
            btnServer5.Text = "5";
            btnServer5.UseVisualStyleBackColor = true;
            // 
            // btnClient1
            // 
            btnClient1.Location = new Point(414, 108);
            btnClient1.Name = "btnClient1";
            btnClient1.Size = new Size(59, 49);
            btnClient1.TabIndex = 43;
            btnClient1.Text = "5";
            btnClient1.UseVisualStyleBackColor = true;
            // 
            // btnServer4
            // 
            btnServer4.Enabled = false;
            btnServer4.Location = new Point(329, 24);
            btnServer4.Name = "btnServer4";
            btnServer4.Size = new Size(59, 49);
            btnServer4.TabIndex = 42;
            btnServer4.Text = "5";
            btnServer4.UseVisualStyleBackColor = true;
            // 
            // btnClient2
            // 
            btnClient2.Location = new Point(329, 108);
            btnClient2.Name = "btnClient2";
            btnClient2.Size = new Size(59, 49);
            btnClient2.TabIndex = 41;
            btnClient2.Text = "5";
            btnClient2.UseVisualStyleBackColor = true;
            // 
            // btnServer3
            // 
            btnServer3.Enabled = false;
            btnServer3.Location = new Point(250, 24);
            btnServer3.Name = "btnServer3";
            btnServer3.Size = new Size(59, 49);
            btnServer3.TabIndex = 40;
            btnServer3.Text = "5";
            btnServer3.UseVisualStyleBackColor = true;
            // 
            // btnClient3
            // 
            btnClient3.Location = new Point(250, 108);
            btnClient3.Name = "btnClient3";
            btnClient3.Size = new Size(59, 49);
            btnClient3.TabIndex = 39;
            btnClient3.Text = "5";
            btnClient3.UseVisualStyleBackColor = true;
            // 
            // btnServer2
            // 
            btnServer2.Enabled = false;
            btnServer2.Location = new Point(171, 24);
            btnServer2.Name = "btnServer2";
            btnServer2.Size = new Size(59, 49);
            btnServer2.TabIndex = 38;
            btnServer2.Text = "5";
            btnServer2.UseVisualStyleBackColor = true;
            // 
            // btnClient4
            // 
            btnClient4.Location = new Point(171, 108);
            btnClient4.Name = "btnClient4";
            btnClient4.Size = new Size(59, 49);
            btnClient4.TabIndex = 37;
            btnClient4.Text = "5";
            btnClient4.UseVisualStyleBackColor = true;
            // 
            // btnClient5
            // 
            btnClient5.Location = new Point(96, 108);
            btnClient5.Name = "btnClient5";
            btnClient5.Size = new Size(59, 49);
            btnClient5.TabIndex = 36;
            btnClient5.Text = "5";
            btnClient5.UseVisualStyleBackColor = true;
            // 
            // btnServer1
            // 
            btnServer1.Enabled = false;
            btnServer1.Location = new Point(96, 24);
            btnServer1.Name = "btnServer1";
            btnServer1.Size = new Size(59, 49);
            btnServer1.TabIndex = 35;
            btnServer1.Text = "5";
            btnServer1.UseVisualStyleBackColor = true;
            // 
            // btnServerPot
            // 
            btnServerPot.Location = new Point(12, 15);
            btnServerPot.Name = "btnServerPot";
            btnServerPot.Size = new Size(58, 142);
            btnServerPot.TabIndex = 34;
            btnServerPot.Text = "0";
            btnServerPot.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(860, 440);
            Controls.Add(txtGameLog);
            Controls.Add(lblGameWinner);
            Controls.Add(label1);
            Controls.Add(grpNetworkSettings);
            Controls.Add(btnClientPot);
            Controls.Add(btnServer5);
            Controls.Add(btnClient1);
            Controls.Add(btnServer4);
            Controls.Add(btnClient2);
            Controls.Add(btnServer3);
            Controls.Add(btnClient3);
            Controls.Add(btnServer2);
            Controls.Add(btnClient4);
            Controls.Add(btnClient5);
            Controls.Add(btnServer1);
            Controls.Add(btnServerPot);
            Name = "Form1";
            Text = "Mancala - Client";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            grpNetworkSettings.ResumeLayout(false);
            grpClientSettings.ResumeLayout(false);
            grpClientSettings.PerformLayout();
            grpNetworkEnd.ResumeLayout(false);
            grpNetworkEnd.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtGameLog;
        private Label lblGameWinner;
        private Label label1;
        private GroupBox grpNetworkSettings;
        private GroupBox grpClientSettings;
        private Button btnStopClient;
        private Button btnStartClient;
        private TextBox txtServerPort;
        private Label label3;
        private TextBox txtServerAddress;
        private Label label2;
        private GroupBox grpNetworkEnd;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private Button btnClientPot;
        private Button btnServer5;
        private Button btnClient1;
        private Button btnServer4;
        private Button btnClient2;
        private Button btnServer3;
        private Button btnClient3;
        private Button btnServer2;
        private Button btnClient4;
        private Button btnClient5;
        private Button btnServer1;
        private Button btnServerPot;
    }
}
