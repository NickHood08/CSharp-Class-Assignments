﻿namespace HW10
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnServerPot = new Button();
            btnServer1 = new Button();
            btnClient5 = new Button();
            btnClient4 = new Button();
            btnServer2 = new Button();
            btnClient3 = new Button();
            btnServer3 = new Button();
            btnClient2 = new Button();
            btnServer4 = new Button();
            btnClient1 = new Button();
            btnServer5 = new Button();
            btnClientPot = new Button();
            grpNetworkSettings = new GroupBox();
            grpServerSettings = new GroupBox();
            btnStopServer = new Button();
            btnStartServer = new Button();
            txtPortNumber = new TextBox();
            label4 = new Label();
            grpNetworkEnd = new GroupBox();
            rdoClient = new RadioButton();
            rdoServer = new RadioButton();
            grpGameControls = new GroupBox();
            label3 = new Label();
            grpWhoGoesFirst = new GroupBox();
            rdo2GoesFirst = new RadioButton();
            rdo1GoesFirst = new RadioButton();
            grpPlayer = new GroupBox();
            rdoPlayer2 = new RadioButton();
            rdoPlayer1 = new RadioButton();
            label1 = new Label();
            lblGameWinner = new Label();
            txtGameLog = new TextBox();
            grpNetworkSettings.SuspendLayout();
            grpServerSettings.SuspendLayout();
            grpNetworkEnd.SuspendLayout();
            grpGameControls.SuspendLayout();
            grpWhoGoesFirst.SuspendLayout();
            grpPlayer.SuspendLayout();
            SuspendLayout();
            // 
            // btnServerPot
            // 
            btnServerPot.Location = new Point(12, 27);
            btnServerPot.Name = "btnServerPot";
            btnServerPot.Size = new Size(58, 142);
            btnServerPot.TabIndex = 0;
            btnServerPot.Text = "0";
            btnServerPot.UseVisualStyleBackColor = true;
            // 
            // btnServer1
            // 
            btnServer1.Location = new Point(94, 36);
            btnServer1.Name = "btnServer1";
            btnServer1.Size = new Size(59, 49);
            btnServer1.TabIndex = 1;
            btnServer1.Text = "5";
            btnServer1.UseVisualStyleBackColor = true;
            // 
            // btnClient5
            // 
            btnClient5.Enabled = false;
            btnClient5.Location = new Point(94, 120);
            btnClient5.Name = "btnClient5";
            btnClient5.Size = new Size(59, 49);
            btnClient5.TabIndex = 2;
            btnClient5.Text = "5";
            btnClient5.UseVisualStyleBackColor = true;
            // 
            // btnClient4
            // 
            btnClient4.Enabled = false;
            btnClient4.Location = new Point(171, 120);
            btnClient4.Name = "btnClient4";
            btnClient4.Size = new Size(59, 49);
            btnClient4.TabIndex = 3;
            btnClient4.Text = "5";
            btnClient4.UseVisualStyleBackColor = true;
            // 
            // btnServer2
            // 
            btnServer2.Location = new Point(171, 36);
            btnServer2.Name = "btnServer2";
            btnServer2.Size = new Size(59, 49);
            btnServer2.TabIndex = 4;
            btnServer2.Text = "5";
            btnServer2.UseVisualStyleBackColor = true;
            // 
            // btnClient3
            // 
            btnClient3.Enabled = false;
            btnClient3.Location = new Point(252, 120);
            btnClient3.Name = "btnClient3";
            btnClient3.Size = new Size(59, 49);
            btnClient3.TabIndex = 5;
            btnClient3.Text = "5";
            btnClient3.UseVisualStyleBackColor = true;
            // 
            // btnServer3
            // 
            btnServer3.Location = new Point(252, 36);
            btnServer3.Name = "btnServer3";
            btnServer3.Size = new Size(59, 49);
            btnServer3.TabIndex = 6;
            btnServer3.Text = "5";
            btnServer3.UseVisualStyleBackColor = true;
            // 
            // btnClient2
            // 
            btnClient2.Enabled = false;
            btnClient2.Location = new Point(333, 120);
            btnClient2.Name = "btnClient2";
            btnClient2.Size = new Size(59, 49);
            btnClient2.TabIndex = 7;
            btnClient2.Text = "5";
            btnClient2.UseVisualStyleBackColor = true;
            // 
            // btnServer4
            // 
            btnServer4.Location = new Point(333, 36);
            btnServer4.Name = "btnServer4";
            btnServer4.Size = new Size(59, 49);
            btnServer4.TabIndex = 8;
            btnServer4.Text = "5";
            btnServer4.UseVisualStyleBackColor = true;
            // 
            // btnClient1
            // 
            btnClient1.Enabled = false;
            btnClient1.Location = new Point(414, 120);
            btnClient1.Name = "btnClient1";
            btnClient1.Size = new Size(59, 49);
            btnClient1.TabIndex = 9;
            btnClient1.Text = "5";
            btnClient1.UseVisualStyleBackColor = true;
            // 
            // btnServer5
            // 
            btnServer5.Location = new Point(414, 36);
            btnServer5.Name = "btnServer5";
            btnServer5.Size = new Size(59, 49);
            btnServer5.TabIndex = 10;
            btnServer5.Text = "5";
            btnServer5.UseVisualStyleBackColor = true;
            // 
            // btnClientPot
            // 
            btnClientPot.Location = new Point(501, 27);
            btnClientPot.Name = "btnClientPot";
            btnClientPot.Size = new Size(58, 142);
            btnClientPot.TabIndex = 11;
            btnClientPot.Text = "0";
            btnClientPot.UseVisualStyleBackColor = true;
            // 
            // grpNetworkSettings
            // 
            grpNetworkSettings.Controls.Add(grpServerSettings);
            grpNetworkSettings.Controls.Add(grpNetworkEnd);
            grpNetworkSettings.Location = new Point(586, 27);
            grpNetworkSettings.Name = "grpNetworkSettings";
            grpNetworkSettings.Size = new Size(263, 220);
            grpNetworkSettings.TabIndex = 12;
            grpNetworkSettings.TabStop = false;
            grpNetworkSettings.Text = "Network Settings:";
            // 
            // grpServerSettings
            // 
            grpServerSettings.Controls.Add(btnStopServer);
            grpServerSettings.Controls.Add(btnStartServer);
            grpServerSettings.Controls.Add(txtPortNumber);
            grpServerSettings.Controls.Add(label4);
            grpServerSettings.Location = new Point(6, 85);
            grpServerSettings.Name = "grpServerSettings";
            grpServerSettings.Size = new Size(251, 129);
            grpServerSettings.TabIndex = 15;
            grpServerSettings.TabStop = false;
            // 
            // btnStopServer
            // 
            btnStopServer.Location = new Point(19, 95);
            btnStopServer.Name = "btnStopServer";
            btnStopServer.Size = new Size(209, 23);
            btnStopServer.TabIndex = 3;
            btnStopServer.Text = "Stop Server";
            btnStopServer.UseVisualStyleBackColor = true;
            btnStopServer.Click += btnStopServer_Click;
            // 
            // btnStartServer
            // 
            btnStartServer.Location = new Point(19, 62);
            btnStartServer.Name = "btnStartServer";
            btnStartServer.Size = new Size(209, 23);
            btnStartServer.TabIndex = 2;
            btnStartServer.Text = "Start Server";
            btnStartServer.UseVisualStyleBackColor = true;
            btnStartServer.Click += btnStartServer_Click;
            // 
            // txtPortNumber
            // 
            txtPortNumber.Location = new Point(145, 22);
            txtPortNumber.Name = "txtPortNumber";
            txtPortNumber.Size = new Size(100, 23);
            txtPortNumber.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 25);
            label4.Name = "label4";
            label4.Size = new Size(88, 15);
            label4.TabIndex = 0;
            label4.Text = "Listens on Port:";
            // 
            // grpNetworkEnd
            // 
            grpNetworkEnd.Controls.Add(rdoClient);
            grpNetworkEnd.Controls.Add(rdoServer);
            grpNetworkEnd.Enabled = false;
            grpNetworkEnd.Location = new Point(6, 22);
            grpNetworkEnd.Name = "grpNetworkEnd";
            grpNetworkEnd.Size = new Size(251, 57);
            grpNetworkEnd.TabIndex = 14;
            grpNetworkEnd.TabStop = false;
            grpNetworkEnd.Text = "Network End:";
            // 
            // rdoClient
            // 
            rdoClient.AutoSize = true;
            rdoClient.Location = new Point(153, 22);
            rdoClient.Name = "rdoClient";
            rdoClient.Size = new Size(56, 19);
            rdoClient.TabIndex = 14;
            rdoClient.Text = "Client";
            rdoClient.UseVisualStyleBackColor = true;
            // 
            // rdoServer
            // 
            rdoServer.AutoSize = true;
            rdoServer.Checked = true;
            rdoServer.Location = new Point(57, 22);
            rdoServer.Name = "rdoServer";
            rdoServer.Size = new Size(57, 19);
            rdoServer.TabIndex = 0;
            rdoServer.TabStop = true;
            rdoServer.Text = "Server";
            rdoServer.UseVisualStyleBackColor = true;
            // 
            // grpGameControls
            // 
            grpGameControls.Controls.Add(label3);
            grpGameControls.Controls.Add(grpWhoGoesFirst);
            grpGameControls.Controls.Add(grpPlayer);
            grpGameControls.Location = new Point(586, 253);
            grpGameControls.Name = "grpGameControls";
            grpGameControls.Size = new Size(263, 176);
            grpGameControls.TabIndex = 13;
            grpGameControls.TabStop = false;
            grpGameControls.Text = "Game Controls:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(50, 154);
            label3.Name = "label3";
            label3.Size = new Size(165, 15);
            label3.TabIndex = 17;
            label3.Text = "Server Controls These Settings";
            // 
            // grpWhoGoesFirst
            // 
            grpWhoGoesFirst.Controls.Add(rdo2GoesFirst);
            grpWhoGoesFirst.Controls.Add(rdo1GoesFirst);
            grpWhoGoesFirst.Location = new Point(6, 85);
            grpWhoGoesFirst.Name = "grpWhoGoesFirst";
            grpWhoGoesFirst.Size = new Size(251, 57);
            grpWhoGoesFirst.TabIndex = 16;
            grpWhoGoesFirst.TabStop = false;
            grpWhoGoesFirst.Text = "Goes First:";
            // 
            // rdo2GoesFirst
            // 
            rdo2GoesFirst.AutoSize = true;
            rdo2GoesFirst.Location = new Point(153, 22);
            rdo2GoesFirst.Name = "rdo2GoesFirst";
            rdo2GoesFirst.Size = new Size(85, 19);
            rdo2GoesFirst.TabIndex = 14;
            rdo2GoesFirst.Text = "2 Goes First";
            rdo2GoesFirst.UseVisualStyleBackColor = true;
            // 
            // rdo1GoesFirst
            // 
            rdo1GoesFirst.AutoSize = true;
            rdo1GoesFirst.Checked = true;
            rdo1GoesFirst.Location = new Point(19, 22);
            rdo1GoesFirst.Name = "rdo1GoesFirst";
            rdo1GoesFirst.Size = new Size(85, 19);
            rdo1GoesFirst.TabIndex = 0;
            rdo1GoesFirst.TabStop = true;
            rdo1GoesFirst.Text = "1 Goes First";
            rdo1GoesFirst.UseVisualStyleBackColor = true;
            // 
            // grpPlayer
            // 
            grpPlayer.Controls.Add(rdoPlayer2);
            grpPlayer.Controls.Add(rdoPlayer1);
            grpPlayer.Location = new Point(6, 22);
            grpPlayer.Name = "grpPlayer";
            grpPlayer.Size = new Size(251, 57);
            grpPlayer.TabIndex = 15;
            grpPlayer.TabStop = false;
            grpPlayer.Text = "Player:";
            // 
            // rdoPlayer2
            // 
            rdoPlayer2.AutoSize = true;
            rdoPlayer2.Location = new Point(153, 22);
            rdoPlayer2.Name = "rdoPlayer2";
            rdoPlayer2.Size = new Size(66, 19);
            rdoPlayer2.TabIndex = 14;
            rdoPlayer2.Text = "Player 2";
            rdoPlayer2.UseVisualStyleBackColor = true;
            // 
            // rdoPlayer1
            // 
            rdoPlayer1.AutoSize = true;
            rdoPlayer1.Checked = true;
            rdoPlayer1.Location = new Point(19, 22);
            rdoPlayer1.Name = "rdoPlayer1";
            rdoPlayer1.Size = new Size(66, 19);
            rdoPlayer1.TabIndex = 0;
            rdoPlayer1.TabStop = true;
            rdoPlayer1.Text = "Player 1";
            rdoPlayer1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 211);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 14;
            label1.Text = "Game Log:";
            // 
            // lblGameWinner
            // 
            lblGameWinner.AutoSize = true;
            lblGameWinner.Font = new Font("Segoe UI", 18.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblGameWinner.Location = new Point(121, 181);
            lblGameWinner.Name = "lblGameWinner";
            lblGameWinner.Size = new Size(166, 35);
            lblGameWinner.TabIndex = 15;
            lblGameWinner.Text = "Game Winner";
            lblGameWinner.Visible = false;
            // 
            // txtGameLog
            // 
            txtGameLog.Location = new Point(12, 229);
            txtGameLog.Multiline = true;
            txtGameLog.Name = "txtGameLog";
            txtGameLog.ReadOnly = true;
            txtGameLog.Size = new Size(547, 200);
            txtGameLog.TabIndex = 16;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(860, 440);
            Controls.Add(txtGameLog);
            Controls.Add(lblGameWinner);
            Controls.Add(label1);
            Controls.Add(grpGameControls);
            Controls.Add(grpNetworkSettings);
            Controls.Add(btnClientPot);
            Controls.Add(btnServer5);
            Controls.Add(btnClient1);
            Controls.Add(btnServer4);
            Controls.Add(btnClient2);
            Controls.Add(btnServer3);
            Controls.Add(btnClient3);
            Controls.Add(btnServer2);
            Controls.Add(btnClient4);
            Controls.Add(btnClient5);
            Controls.Add(btnServer1);
            Controls.Add(btnServerPot);
            Name = "Form1";
            Text = "Mancala - Server";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            grpNetworkSettings.ResumeLayout(false);
            grpServerSettings.ResumeLayout(false);
            grpServerSettings.PerformLayout();
            grpNetworkEnd.ResumeLayout(false);
            grpNetworkEnd.PerformLayout();
            grpGameControls.ResumeLayout(false);
            grpGameControls.PerformLayout();
            grpWhoGoesFirst.ResumeLayout(false);
            grpWhoGoesFirst.PerformLayout();
            grpPlayer.ResumeLayout(false);
            grpPlayer.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnServerPot;
        private Button btnServer1;
        private Button btnClient5;
        private Button btnClient4;
        private Button btnServer2;
        private Button btnClient3;
        private Button btnServer3;
        private Button btnClient2;
        private Button btnServer4;
        private Button btnClient1;
        private Button btnServer5;
        private Button btnClientPot;
        private GroupBox grpNetworkSettings;
        private GroupBox grpNetworkEnd;
        private RadioButton rdoClient;
        private RadioButton rdoServer;
        private GroupBox grpGameControls;
        private GroupBox grpServerSettings;
        private Label label1;
        private Label lblGameWinner;
        private TextBox txtGameLog;
        private GroupBox grpWhoGoesFirst;
        private RadioButton rdo2GoesFirst;
        private RadioButton rdo1GoesFirst;
        private GroupBox grpPlayer;
        private RadioButton rdoPlayer2;
        private RadioButton rdoPlayer1;
        private Label label3;
        private Button btnStopServer;
        private Button btnStartServer;
        private TextBox txtPortNumber;
        private Label label4;
    }
}
