using System.Net.Sockets;

namespace HW10
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: 
    /// The server side of the project
    ///
    /// File Purpose:
    /// The server side where a server, given a certain address
    /// and port number, is created to play against someone in mancala.
    ///
    /// Program Purpose:
    /// The purpose of this program is to work with networks and threads
    /// to make a mancala game that is playable between a server and client.
    /// </summary>
    public partial class Form1 : Form
    {
        TcpListener server;                         //server connections for tcp network services
        Socket aConnection;                         //socket interface
        NetworkStream netStream;                    //stream of data for network access
        BinaryWriter netWriter;                     //writes the data to the net stream to be sent to server
        BinaryReader netReader;                     //reads data sent from server
        Thread GetDataThread;                       //thread for getting data from the server
        int[] tileCounts = new int[12];             //contains the values of all the tiles for the game
        bool myTurn = false;                        //checker for if it is the clients turn or not
        /// <summary>
        /// Initializes the form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Sets all the button clicks to a mixed button click funtion and sets
        /// the initial values for each tile.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void Form1_Load(object sender, EventArgs e)
        {

            btnStopServer.Enabled = false;
            CheckForIllegalCrossThreadCalls = false;

            btnServer1.Click += MixedButtonClick;
            btnServer2.Click += MixedButtonClick;
            btnServer3.Click += MixedButtonClick;
            btnServer4.Click += MixedButtonClick;
            btnServer5.Click += MixedButtonClick;
            btnClient5.Click += MixedButtonClick;
            btnClient4.Click += MixedButtonClick;
            btnClient3.Click += MixedButtonClick;
            btnClient2.Click += MixedButtonClick;
            btnClient1.Click += MixedButtonClick;

            tileCounts[0] = 0;
            tileCounts[1] = 5;
            tileCounts[2] = 5;
            tileCounts[3] = 5;
            tileCounts[4] = 5;
            tileCounts[5] = 5;
            tileCounts[6] = 0;
            tileCounts[7] = 5;
            tileCounts[8] = 5;
            tileCounts[9] = 5;
            tileCounts[10] = 5;
            tileCounts[11] = 5;
        }
        /// <summary>
        /// If the button clicked is not the pots, have 0 pieces, and it is the users turn
        /// then the name of the button clicked is sent to the other user so they can see the 
        /// same move on thier board and the make move function is called.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void MixedButtonClick(object? sender, EventArgs e)
        {
            Control aControl = (Control)sender!;
            if (aControl.Text != "0" && myTurn && aControl.Name != "btnServerPot" && aControl.Name != "btnClientPot")
            {
                if (myTurn)
                {
                    netWriter.Write(aControl.Name);
                }

                int pieces = int.Parse(aControl.Text);

                switch (aControl.Name)
                {
                    case "btnServer1":
                        makeMove(1, pieces);
                        break;
                    case "btnServer2":
                        makeMove(2, pieces);
                        break;
                    case "btnServer3":
                        makeMove(3, pieces);
                        break;
                    case "btnServer4":
                        makeMove(4, pieces);
                        break;
                    case "btnServer5":
                        makeMove(5, pieces);
                        break;
                    case "btnClient1":
                        makeMove(7, pieces);
                        break;
                    case "btnClient2":
                        makeMove(8, pieces);
                        break;
                    case "btnClient3":
                        makeMove(9, pieces);
                        break;
                    case "btnClient4":
                        makeMove(10, pieces);
                        break;
                    case "btnClient5":
                        makeMove(11, pieces);
                        break;
                }
            }
        }
        /// <summary>
        /// The main mancala functionality takes place here. Given the position, the number is wiped to 0 and then 
        /// 1 piece is dropped in each tile until there are no pieces left. Then updateTiles functions is called,
        /// the check for win function is called. If no win the proper message is sent to the other player
        /// that describes the move that was made.
        /// </summary>
        /// <param name="position">posistion of the button that was clicked</param>
        /// <param name="pieces">number of pieces to use</param>
        private void makeMove(int position, int pieces)
        {
            tileCounts[position] = 0;
            for (int i = pieces; i > 0; i--)
            {
                position++;
                if (position > 11)
                {
                    position = 0;
                }
                tileCounts[position] += 1;
            }
            updateTiles();
            if (!chechForWin())
            {
                if (position != 0 && position != 6)
                {
                    if (myTurn)
                    {
                        string move = "From Server: B";
                        move = makeMoveString(move);
                        netWriter.Write(move);
                    }
                    switchTurn();
                }
                else
                {
                    if (myTurn)
                    {
                        string move = "From Server: BD";
                        move = makeMoveString(move);
                        netWriter.Write(move);
                    }
                }
            }
        }
        /// <summary>
        /// Updates the board tiles with the correct amount of pieces
        /// </summary>
        private void updateTiles()
        {
            btnServerPot.Text = tileCounts[0].ToString();
            btnServer1.Text = tileCounts[1].ToString();
            btnServer2.Text = tileCounts[2].ToString();
            btnServer3.Text = tileCounts[3].ToString();
            btnServer4.Text = tileCounts[4].ToString();
            btnServer5.Text = tileCounts[5].ToString();
            btnClientPot.Text = tileCounts[6].ToString();
            btnClient1.Text = tileCounts[7].ToString();
            btnClient2.Text = tileCounts[8].ToString();
            btnClient3.Text = tileCounts[9].ToString();
            btnClient4.Text = tileCounts[10].ToString();
            btnClient5.Text = tileCounts[11].ToString();
        }
        /// <summary>
        /// checks for a win from either player then the proper message is displayed on the label and a final
        /// message is sent describing the last move.
        /// </summary>
        /// <returns>Boolean for is there was a win</returns>
        private bool chechForWin()
        {
            if (btnServer1.Text == "0" && btnServer2.Text == "0" && btnServer3.Text == "0" && btnServer4.Text == "0" && btnServer5.Text == "0")
            {
                lblGameWinner.Visible = true;
                lblGameWinner.Text = "Player" + getPlayer() + " wins";
                if (myTurn)
                {
                    string move = "From Server: BW";
                    move = makeMoveString(move);
                    netWriter.Write(move);
                }
                disableButtons();
                return true;
            }
            if (btnClient1.Text == "0" && btnClient2.Text == "0" && btnClient3.Text == "0" && btnClient4.Text == "0" && btnClient5.Text == "0")
            {
                lblGameWinner.Visible = true;
                if (getPlayer() == 1)
                {
                    lblGameWinner.Text = "Player 2 wins";
                }
                else
                {
                    lblGameWinner.Text = "Player 1 wins";
                }
                if (myTurn)
                {
                    string move = "From Server: BW";
                    move = makeMoveString(move);
                    netWriter.Write(move);
                }
                disableButtons();
                return true;
            }
            return false;
        }
        /// <summary>
        /// Creates the string containing the number of pieces in each tile
        /// </summary>
        /// <param name="move">String for holding the move made by the user</param>
        /// <returns>The final string of the move made</returns>
        private string makeMoveString(string move)
        {
            for (int i = 0; i < tileCounts.Length; i++)
            {
                move += "-" + tileCounts[i];
            }
            return move;
        }
        /// <summary>
        /// starts a server with a specific address and a user given port number then 
        /// once a connection is made the client recieves a message containing 
        /// which player number the server is and which player number goes first then 
        /// sets myTurn to true if servers player number matches the first turn player number
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnStartServer_Click(object sender, EventArgs e)
        {
            if (txtPortNumber.Text == string.Empty)
            {
                MessageBox.Show("Please enter a port number.", string.Empty, MessageBoxButtons.OK);
            }
            else
            {
                txtGameLog.Text = string.Empty;
                grpGameControls.Enabled = false;
                this.Text += " - I am player " + getPlayer() + " and player " + getGoesFirst() + " goes first";
                try
                {
                    server = new TcpListener(System.Net.IPAddress.Parse("127.0.0.1"), int.Parse(txtPortNumber.Text));
                    server.Start();

                    btnStartServer.Enabled = false;
                    btnStopServer.Enabled = true;
                    txtGameLog.Text += "Listening for client connection... \r\n";
                    Application.DoEvents();
                    aConnection = server.AcceptSocket();
                    txtGameLog.Text += "...client connection accepted \r\n";
                    netStream = new NetworkStream(aConnection);

                    netWriter = new BinaryWriter(netStream);
                    netReader = new BinaryReader(netStream);
                    netWriter.Write("From Server: S" + getPlayer() + getGoesFirst() + "\r\n");
                    if (getPlayer() == getGoesFirst())
                    {
                        myTurn = true;
                    }
                    GetDataThread = new Thread(GetDataFromClient);
                    GetDataThread.Start();
                }
                catch (IOException ex)
                {
                    txtGameLog.Text += ex.Message + "\r\n";
                }
                catch (SocketException ex)
                {
                    txtGameLog.Text += ex.Message + "\r\n";
                }
            }
        }
        /// <summary>
        /// Looks for incoming data from the client and does the makeMove process if
        /// the client made a move else it displays the message from the client
        /// </summary>
        void GetDataFromClient()
        {
            string data = string.Empty;

            try
            {
                do
                {
                    if (netReader != null)
                    {
                        data = netReader.ReadString();
                    }
                    if (data.Length == 10)
                    {
                        Button b = (Button)this.Controls.Find(data, true)[0];
                        makeMove(int.Parse(data.Substring(9, 1)) + 6, int.Parse(b.Text));
                    }
                    else
                    {
                        txtGameLog.Text += data + "\r\n";
                    }
                }
                while ((data != "~~END~~") && (aConnection.Connected));
                StopListening();
            }
            catch (IOException ex)
            {
                txtGameLog.Text += ex + "\r\n";
                StopListening();
            }
        }
        /// <summary>
        /// Stops the server
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnStopServer_Click(object sender, EventArgs e)
        {
            StopListening();
        }
        /// <summary>
        /// Stops listening for incoming data and sends a finaly message to the other
        /// telling it to stop listening for more data. Then everything is closed and stopped.
        /// </summary>
        void StopListening()
        {
            btnStartServer.Enabled = true;
            btnStopServer.Enabled = false;
            grpGameControls.Enabled = true;

            try
            {
                if (netWriter != null)
                {
                    netWriter.Write("~~END~~");
                }
            }
            catch (Exception ex) {}

            try
            {
                if (netWriter != null)
                {
                    netWriter.Close();
                }
                if (netReader != null)
                {
                    netReader.Close();
                }
                if (netStream != null)
                {
                    netStream.Close();
                }
                server.Stop();

                netWriter = null;
                netReader = null;
                netStream = null;
                server = null;

                try
                {
                    if (GetDataThread != null)
                    {
                        GetDataThread = null;
                    }
                }
                catch (Exception ex) {}
            }
            catch (Exception ex) {}
            finally
            {
                txtGameLog.Text += "Server has been stopped \r\n";
            }
        }
        /// <summary>
        /// Gets the servers player number
        /// </summary>
        /// <returns>Servers player number</returns>
        private int getPlayer()
        {
            if (rdoPlayer1.Checked)
            {
                return 1;
            }
            return 2;
        }
        /// <summary>
        /// Gets the number of the player who goes first
        /// </summary>
        /// <returns>The number of the player who goes first</returns>
        private int getGoesFirst()
        {
            if (rdo1GoesFirst.Checked)
            {
                return 1;
            }
            return 2;
        }
        /// <summary>
        /// switches the players myTurn bool and either enables or disables
        /// the buttons depending on if it is the players turn
        /// </summary>
        private void switchTurn()
        {
            if (myTurn)
            {
                myTurn = false;
                disableButtons();
            }
            else
            {
                myTurn = true;
                enableButtons();
            }
        }
        /// <summary>
        /// Loops through all the button on the form and enables the players buttons
        /// </summary>
        private void enableButtons()
        {
            foreach (Button b in this.Controls.OfType<Button>())
            {
                if (b.Name == "btnServer1" || b.Name == "btnServer2" || b.Name == "btnServer3" || b.Name == "btnServer4" || b.Name == "btnServer5" || b.Name == "btnServer6")
                {
                    b.Enabled = true;
                }
            }
        }
        /// <summary>
        /// Loops through all the button on the form and disables the players buttons
        /// </summary>
        private void disableButtons()
        {
            foreach (Button b in this.Controls.OfType<Button>())
            {
                if (b.Name == "btnServer1" || b.Name == "btnServer2" || b.Name == "btnServer3" || b.Name == "btnServer4" || b.Name == "btnServer5" || b.Name == "btnServer6")
                {
                    b.Enabled = false;
                }
            }
        }
        /// <summary>
        /// Calls the function to stop the server
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopListening();
        }
    }
}
