﻿using Microsoft.VisualBasic;
using System.Xml.Linq;

namespace HW5
{
    /// <summary>
    /// Filename: Program.cs
    /// Part of Project: Main Part
    ///
    /// File Purpose:
    /// The purpose of this file is that it is the main program file 
    /// that contains all functionality for the program to work.
    ///
    /// Program Purpose:
    /// The purpose of this program is to read from a file, if user gives a real file name/path.
    /// While reading the file, the contents of the line are split an used for the instance of 
    /// a new employee. Once created, the new employee instance is then added to a list of all
    /// employees. Once done reading the file, the list of all employees is sorted by employee ID.
    /// Then the sales report is displayed to the user, ordered by sales order ID number and then 
    /// by employees last name and first name if there are same last names. Lastly the statistics
    /// summary is displayed to the user.
    /// </summary>
    internal class Program
    {
        const string EMPTY_LINE = " ";  //String for writing an empty line in the console
        /// <summary>
        /// Employee class containing all employee attributes, constructor, and functions
        /// </summary>
        public class Employee
        {
            public string firstName;       //The first fame of the employee
            public string lastName;        //The last name of the employee
            public int orderID;            //The sales order ID number
            public int ID;                 //The employees ID 
            public float gamesSales;       //The games sales amount
            public int gamesQuantity;      //The games sales quantity
            public float dollsSales;       //The dolls sales amount
            public int dollsQuantity;      //The dolls sales quantity
            public float buildingSales;    //The building sales amount
            public int buildingQuantity;   //The building sales quantity
            public float modelSales;       //The model sales amount
            public int modelQuantity;      //The model sales quantity
            public float totalSales;       //The amount of all sales added together
            /// <summary>
            /// Constructor for creating a new employee
            /// </summary>
            /// <param name="firstName">The first name of the employee read from the file</param>
            /// <param name="lastName">The last name of the employee read from the file</param>
            /// <param name="orderID">The sales order ID number read from the file</param>
            /// <param name="ID">The emplyee ID read from the file</param>
            /// <param name="gamesSales">The ganes sales amount read from the file</param>
            /// <param name="gamesQuantity">The games sales quantity read from the file</param>
            /// <param name="dollsSales">The dolls sales amount read from the file</param>
            /// <param name="dollsQuantity">The dolls sales quantity read from the file</param>
            /// <param name="buildingSales">The building sales amount read from the file</param>
            /// <param name="buildingQuantity">The building sales quantity read from the file</param>
            /// <param name="modelSales">The model sales amount read from the file</param>
            /// <param name="modelQuantity">The model sales quantity read from the file</param>
            public Employee(string firstName,
                string lastName,
                int orderID,
                int ID,
                float gamesSales,
                int gamesQuantity,
                float dollsSales,
                int dollsQuantity,
                float buildingSales,
                int buildingQuantity,
                float modelSales,
                int modelQuantity)
            {
                this.firstName = firstName;
                this.lastName = lastName;
                this.orderID = orderID;
                this.ID = ID;
                this.gamesSales = gamesSales;
                this.gamesQuantity = gamesQuantity;
                this.dollsSales = dollsSales;
                this.dollsQuantity = dollsQuantity;
                this.buildingSales = buildingSales;
                this.buildingQuantity = buildingQuantity;
                this.modelSales = modelSales;
                this.modelQuantity = modelQuantity;
                getTotalSales();
            }
            /// <summary>
            /// Function for getting the total sales for an employee
            /// </summary>
            public void getTotalSales()
            {
                this.totalSales = gamesSales + dollsSales + buildingSales + modelSales;
            }
        }
        /// <summary>
        /// The main function where everything takes place. If a valid file/file path was provided, 
        /// the file is read and a new employee instance is made containing what was read from the file.
        /// The new employee instance is put into a list of employees and once complete is ordered by employee ID.
        /// Then functions are called to print the sales report by sales order id number, the sales report by last name then first name, 
        /// and finally the statistics report.
        /// </summary>
        /// <param name="args">Arguments</param>
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>();
            string? readingFilePath;
            Console.WriteLine("Please enter the path and the name of the file containing the measurements:");
            readingFilePath = Console.ReadLine();
            if (File.Exists(readingFilePath))
            {
                readDataFromFile(readingFilePath, ref employees);
                employees.Sort((emp1, emp2) => emp1.ID.CompareTo(emp2.ID));
                wrtieEmptyLines();
                printSalesReportByOrder(employees);
                wrtieEmptyLines();
                printSalesReportByName(employees);
                wrtieEmptyLines();
                printStatisticsSummary(employees);
            }
            else
            {
                Console.WriteLine("Bad File Name/Path");
            }
        }
        /// <summary>
        /// this function writes two empty lines to give space between what is displayed to user
        /// </summary>
        private static void wrtieEmptyLines()
        {
            Console.WriteLine(EMPTY_LINE);
            Console.WriteLine(EMPTY_LINE);
        }
        /// <summary>
        /// This function reads from a file and creates a new employee instance using the 
        /// information read from the file. The employee instance is then added to a list of all employees
        /// </summary>
        /// <param name="filePath">The path of the file being read from</param>
        /// <param name="employees">The list of all employees</param>
        private static void readDataFromFile(string filePath, ref List<Employee> employees)
        {
            string? fileContents;
            System.IO.StreamReader reader;
            reader = System.IO.File.OpenText(filePath);
            while (!reader.EndOfStream)
            {
                fileContents = reader.ReadLine();
                string[] temp = new string[12];
                temp = fileContents!.Split(" ");
                Employee employee = new Employee(temp[0],
                    temp[1],
                    Convert.ToInt32(temp[2]),
                    Convert.ToInt32(temp[3]),
                    float.Parse(temp[4]),
                    Convert.ToInt32(temp[5]),
                    float.Parse(temp[6]),
                    Convert.ToInt32(temp[7]),
                    float.Parse(temp[8]),
                    Convert.ToInt32(temp[9]),
                    float.Parse(temp[10]),
                    Convert.ToInt32(temp[11]));
                employees.Add(employee);
            }
            reader.Close();
        }
        /// <summary>
        /// This function prints the sales report in order by sales order ID number
        /// </summary>
        /// <param name="employees">List of all employees</param>
        private static void printSalesReportByOrder(List<Employee> employees)
        {
            Console.WriteLine($"{"Waste O' Time Toys",57}");
            Console.WriteLine($"{"*** Salers Report by Order ***",63}");
            Console.WriteLine($"{"--------------------------------",64}");
            Console.WriteLine(EMPTY_LINE);
            Console.WriteLine($"{"Name",-17}    {"ID",-3}     {"Games",-7}    {"Dolls",-7}  {"Building",-9}   {"Models",-7}      {"Total",-7}");
            Console.WriteLine($"{"-----------------",-17}    {"---",-3}   {"---------",9}  {"---------",9}  {"---------",9}  {"---------",9}    {"---------",9}");
            var empsSortedByOrder = from emp in employees                         
                                    orderby emp.orderID
                                    select emp;
            foreach (Employee employee in empsSortedByOrder)
            {
                string fullName = employee.lastName + ", " + employee.firstName;  
                Console.WriteLine($"{fullName,-17}    {employee.orderID,3:000}   {employee.gamesSales,9:C}  {employee.dollsSales,9:C}  {employee.buildingSales,9:C}  {employee.modelSales,9:C}    {employee.totalSales,9:C}");
            }
        }
        /// <summary>
        /// This function prints the sales report in order by last name
        /// </summary>
        /// <param name="employees">List of all employees</param>
        private static void printSalesReportByName(List<Employee> employees)
        {
            Console.WriteLine($"{"Waste O' Time Toys",57}");
            Console.WriteLine($"{"*** Salers Report by Name ***",63}");
            Console.WriteLine($"{"--------------------------------",64}");
            Console.WriteLine(EMPTY_LINE);
            Console.WriteLine($"{"Name",-17}    {"ID",-3}     {"Games",-7}    {"Dolls",-7}  {"Building",-9}   {"Models",-7}      {"Total",-7}");
            Console.WriteLine($"{"-----------------",-17}    {"---",-3}   {"---------",9}  {"---------",9}  {"---------",9}  {"---------",9}    {"---------",9}");
            var empsSortedByName = from emp in employees                           
                                    orderby emp.lastName, emp.firstName
                                    select emp;
            foreach (Employee employee in empsSortedByName)
            {
                string fullName = employee.lastName + ", " + employee.firstName;   
                Console.WriteLine($"{fullName,-17}    {employee.orderID,3:000}   {employee.gamesSales,9:C}  {employee.dollsSales,9:C}  {employee.buildingSales,9:C}  {employee.modelSales,9:C}    {employee.totalSales,9:C}");
            }
        }
        /// <summary>
        /// This function prints the statistics summary
        /// </summary>
        /// <param name="employees">List of all employees</param>
        private static void printStatisticsSummary(List<Employee> employees)
        {
            var gamesQuantity = (from emps in employees select emps.gamesQuantity);                     
            var dollsQuantity = (from emps in employees select emps.dollsQuantity);                     
            var buildingQuantity = (from emps in employees select emps.buildingQuantity);               
            var modelQuantity = (from emps in employees select emps.modelQuantity);                     
            var gamesStats = (from emps in employees select emps.gamesSales);                           
            var dollsStats = (from emps in employees select emps.dollsSales);                           
            var buildingStats = (from emps in employees select emps.buildingSales);                     
            var modelStats = (from emps in employees select emps.modelSales);                           
            var totalGamesSales = gamesStats.Sum();                                                     
            var totalDollsSales = dollsStats.Sum();                                                     
            var totalBuildingSales = buildingStats.Sum();                                               
            var totalModelSales = modelStats.Sum();                                                     
            var grandTotal = totalGamesSales + totalDollsSales + totalBuildingSales + totalModelSales;  
            Console.WriteLine(new string('-', 73));
            Console.WriteLine($"{"Sales Statistics Summary", 45}");
            Console.WriteLine(new string('-', 73));
            Console.WriteLine($"{"Quantity Statistics",37}");
            Console.WriteLine($"{"Games", 17}{"Dolls",10}{"Building",11}{"Model",11}");
            Console.WriteLine($"{"Low",-7}{gamesQuantity.Min(),10}{dollsQuantity.Min(),10}{buildingQuantity.Min(),11}{modelQuantity.Min(),11}");
            Console.WriteLine($"{"Ave",-7}{gamesQuantity.Average(),10:0.00}{dollsQuantity.Average(),10:0.00}{buildingQuantity.Average(),11:0.00}{modelQuantity.Average(),11:0.00}");
            Console.WriteLine($"{"High",-7}{gamesQuantity.Max(),10}{dollsQuantity.Max(),10}{buildingQuantity.Max(),11}{modelQuantity.Max(),11}");
            wrtieEmptyLines();
            Console.WriteLine($"{"Sales Statistics",34}");
            Console.WriteLine($"{"Games",17}{"Dolls",10}{"Building",11}{"Model",11}");
            Console.WriteLine($"{"Low",-7}{gamesStats.Min(),10:C}{dollsStats.Min(),10:C}{buildingStats.Min(),11:C}{modelStats.Min(),11:C}");
            Console.WriteLine($"{"Ave",-7}{gamesStats.Average(),10:C}{dollsStats.Average(),10:C}{buildingStats.Average(),11:C}{modelStats.Average(),11:C}");
            Console.WriteLine($"{"High",-7}{gamesStats.Max(),10:C}{dollsStats.Max(),10:C}{buildingStats.Max(),11:C}{modelStats.Max(),11:C}{"**Total**",13}");
            Console.WriteLine(new string('-', 73));
            Console.WriteLine($"{"Total",-7}{totalGamesSales,10:C}{totalDollsSales,10:C}{totalBuildingSales,11:C}{totalModelSales,11:C}{grandTotal,13:C}");
            wrtieEmptyLines();
            var aboveAverageEmployees = from emps in employees
                                        where emps.totalSales > (from emps2 in employees select emps2.totalSales).Average()
                                        orderby emps.firstName, emps.lastName
                                        select emps;
            Console.WriteLine($"There are {aboveAverageEmployees.Count()} employees who sold above the average sales level.");
            Console.WriteLine("The names of the above average selling employees in alphabetical order are:");
            foreach (Employee emps in aboveAverageEmployees)
            {
                Console.WriteLine($"{emps.firstName} {emps.lastName}");
            }
        }
    }
}
