﻿namespace HW9
{
    /// <summary>
    /// Filename: SalesPerson.cs
    /// Part of Project: 
    /// A class for containing a sales person data
    ///
    /// File Purpose:
    /// A class for containing a sales person data
    ///
    /// Program Purpose:
    /// A class for containing a sales person data
    /// </summary>
    public class SalesPerson
    {
        private string? firstName;  //The sales persons first name
        private string? lastName;   //The sales persons last name
        private int orderID;        //The order id
        private int employeeID;     //The employee id
        private float gamesSales;   //The total of games sales
        private int gamesQuantity;  //The quantity of games sold
        private float dollsSales;   //The total of dolls sold
        private int dollsQuantity;  //The quantity of dolls sold
        private float buildSales;   //The total of buildings sold
        private int buildQuantity;  //The quanity of buildings sold
        private float modelSales;   //The total of models sold
        private int modelQuantity;  //The quantity of models sold

        /// <summary>
        /// The constructor
        /// </summary>
        /// <param name="firstName">The sales persons first name</param>
        /// <param name="lastName">The sales persons last name</param>
        /// <param name="orderID">The order id</param>
        /// <param name="employeeID">The employee id</param>
        /// <param name="gamesSales">The total of games sales</param>
        /// <param name="gamesQuantity">The quantity of games sold</param>
        /// <param name="dollsSales">The total of dolls sold</param>
        /// <param name="dollsQuantity">The quantity of dolls sold</param>
        /// <param name="buildSales">The total of buildings sold</param>
        /// <param name="buildQuantity">The quanity of buildings sold</param>
        /// <param name="modelSales">The total of models sold</param>
        /// <param name="modelQuantity">The quantity of models sold</param>
        public SalesPerson(string firstName, string lastName, int orderID, int employeeID, float gamesSales, int gamesQuantity, float dollsSales, int dollsQuantity, float buildSales, int buildQuantity, float modelSales, int modelQuantity)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.orderID = orderID;
            this.employeeID = employeeID;
            this.gamesSales = gamesSales;
            this.gamesQuantity = gamesQuantity;
            this.dollsSales = dollsSales;
            this.dollsQuantity = dollsQuantity;
            this.buildSales = buildSales;
            this.buildQuantity = buildQuantity;
            this.modelSales = modelSales;
            this.modelQuantity = modelQuantity;
        }

        /// <summary>
        /// returns the first name
        /// </summary>
        /// <returns>The sales persons first name</returns>
        public string getFirstName()
        {
            if (firstName is null)
            {
                firstName = string.Empty;
            }
            return firstName;
        }

        /// <summary>
        /// returns the last name
        /// </summary>
        /// <returns>The sales persons last name</returns>
        public string getLastName()
        {
            if (lastName is null)
            {
                lastName = string.Empty;
            }
            return lastName;
        }

        /// <summary>
        /// returns the order id
        /// </summary>
        /// <returns>The order id</returns>
        public int getOrderID() {  return orderID; }

        /// <summary>
        /// returns the employee id
        /// </summary>
        /// <returns>The employee id</returns>
        public int getEmployeeID() {  return employeeID; }

        /// <summary>
        /// returns the games sales total
        /// </summary>
        /// <returns>The games sales total</returns>
        public float getGamesSales() {  return gamesSales; }

        /// <summary>
        /// returns the quantity of games sold
        /// </summary>
        /// <returns>The quantity of games sold</returns>
        public float getGamesQuantity() { return gamesQuantity; }

        /// <summary>
        /// returns the dolls sales total
        /// </summary>
        /// <returns>The dolls sales total</returns>
        public float getDollsSales() {  return dollsSales; }

        /// <summary>
        /// returns the quantity of dolls sold
        /// </summary>
        /// <returns>The quantity of dolls sold</returns>
        public float getDollsQuantity() {  return dollsQuantity; }

        /// <summary>
        /// returns the build sales total
        /// </summary>
        /// <returns>The build sales total</returns>
        public float getBuildSales() {  return buildSales; }

        /// <summary>
        /// reutnrs the quantity of buildins sold
        /// </summary>
        /// <returns>The quantity of buildings sold</returns>
        public float getBuildQuantity() {  return buildQuantity; }

        /// <summary>
        /// reutrns the model sales total
        /// </summary>
        /// <returns>The model sales total</returns>
        public float getModelSales() { return modelSales; }

        /// <summary>
        /// returns the quantity of models sold
        /// </summary>
        /// <returns>The quantity of modles sold</returns>
        public float getModelQuantity() {  return modelQuantity; }
    }
}
