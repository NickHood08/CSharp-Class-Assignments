using Microsoft.VisualBasic;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
namespace HW9
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: 
    /// The main functionality takes place. An excel sheet is made, a sales person is made
    /// using the data read from the file, then displays their data on the excel sheet,
    /// lastly the totals, maxs, averages, and mins of all the data is calulated and displayed
    ///
    /// File Purpose:
    /// The purpose of this file is to display an excel spreadsheet containing the data
    /// of a sales person read in from a file called ToyOrder.txt. Then the totals.
    /// maxs, averages, and mins of all the data is calulated and displayed.
    ///
    /// Program Purpose:
    /// The purpose of this program is to display an excel spreadsheet containing the data
    /// of a sales person read in from a file called ToyOrder.txt. Then the totals.
    /// maxs, averages, and mins of all the data is calulated and displayed.
    /// </summary>
    public partial class Form1 : Form
    {
        Excel.Application theExcelSheet = new Excel.Application();   //the excel spreadsheet
        List<SalesPerson> mySalesForce = new List<SalesPerson>();    //List for holding all the sales people
        int row = 1;                                                 //keeps track of which row its currently on

        /// <summary>
        /// Initializes the form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Where all of the functions are called to create the spreadsheet
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            getSalesForce();
            theExcelSheet.Visible = true;
            theExcelSheet.Workbooks.Add();
            populateHeaders();
            populateSalesPeopleInfo();
            populateTotals();
            populateMaxs();
            populateAverages();
            populateMins();
        }

        /// <summary>
        /// Reads through a file called ToyOrder.txt and creates a new sales person using the data
        /// and adds them to the list of sales people
        /// </summary>
        private void getSalesForce()
        {
            string filePath = "ToyOrder.txt";
            string? fileContents;
            System.IO.StreamReader reader;
            if (File.Exists(filePath))
            {
                reader = System.IO.File.OpenText(filePath);
                while (!reader.EndOfStream)
                {
                    fileContents = reader.ReadLine();
                    string[] temp = new string[12];
                    temp = fileContents!.Split(" ");
                    mySalesForce.Add(new SalesPerson(temp[0],
                        temp[1], int.Parse(temp[2]), int.Parse(temp[3]),
                        float.Parse(temp[4]), int.Parse(temp[5]),
                        float.Parse(temp[6]), int.Parse(temp[7]),
                        float.Parse(temp[8]), int.Parse(temp[9]),
                        float.Parse(temp[10]), int.Parse(temp[11])));
                }
                reader.Close();
            }
            else
            {
                MessageBox.Show("No file called ToyOrder.txt in bin folder. Please add a space seperated txt file called ToyOrder to the bin folder and retry!");
                this.Close();
            }
        }

        /// <summary>
        /// Creates the headers
        /// </summary>
        public void populateHeaders()
        {
            theExcelSheet.Cells[row, 1] = "First Name";
            theExcelSheet.Cells[row, 2] = "Last Name";
            theExcelSheet.Cells[row, 3] = "Order ID";
            theExcelSheet.Cells[row, 4] = "Employee ID";
            theExcelSheet.Cells[row, 6] = "Games Sales";
            theExcelSheet.Cells[row, 7] = "Dolls Sales";
            theExcelSheet.Cells[row, 8] = "Build Sales";
            theExcelSheet.Cells[row, 9] = "Model Sales";
            theExcelSheet.Cells[row, 10] = "Total Sales";
            theExcelSheet.Cells[row, 11] = "Min Sales";
            theExcelSheet.Cells[row, 12] = "Avg Sales";
            theExcelSheet.Cells[row, 13] = "Max Sales";
            theExcelSheet.Cells[row, 15] = "Games Qty";
            theExcelSheet.Cells[row, 16] = "Dolls Qty";
            theExcelSheet.Cells[row, 17] = "Build Qty";
            theExcelSheet.Cells[row, 18] = "Model Qty";
            theExcelSheet.Cells[row, 19] = "Total Qty";
            theExcelSheet.Cells[row, 20] = "Min Qty";
            theExcelSheet.Cells[row, 21] = "Avg Qty";
            theExcelSheet.Cells[row, 22] = "Max Qty";
        }

        /// <summary>
        /// Loops through the list of sales people and displays their info in the 
        /// spreadsheet accordingly then adds 2 to the row variable to create a blank row
        /// between the employees stats and the overall stats
        /// </summary>
        public void populateSalesPeopleInfo()
        {
            foreach (SalesPerson sp in mySalesForce)
            {
                row++;
                theExcelSheet.Cells[row, 1] = sp.getFirstName();
                theExcelSheet.Cells[row, 2] = sp.getLastName();
                theExcelSheet.Cells[row, 3] = sp.getOrderID();
                theExcelSheet.Cells[row, 4] = sp.getEmployeeID();
                theExcelSheet.Cells[row, 6] = sp.getGamesSales();
                theExcelSheet.Cells[row, 7] = sp.getDollsSales();
                theExcelSheet.Cells[row, 8] = sp.getBuildSales();
                theExcelSheet.Cells[row, 9] = sp.getModelSales();
                theExcelSheet.Cells[row, 10] = $"=sum(f{row}..i{row})";
                theExcelSheet.Cells[row, 11] = $"=min(f{row}..i{row})";
                theExcelSheet.Cells[row, 12] = $"=average(f{row}..i{row})";
                theExcelSheet.Cells[row, 13] = $"=max(f{row}..i{row})";
                theExcelSheet.Cells[row, 15] = sp.getGamesQuantity();
                theExcelSheet.Cells[row, 16] = sp.getDollsQuantity();
                theExcelSheet.Cells[row, 17] = sp.getBuildQuantity();
                theExcelSheet.Cells[row, 18] = sp.getModelQuantity();
                theExcelSheet.Cells[row, 19] = $"=sum(o{row}..r{row})";
                theExcelSheet.Cells[row, 20] = $"=min(o{row}..r{row})";
                theExcelSheet.Cells[row, 21] = $"=average(o{row}..r{row})";
                theExcelSheet.Cells[row, 22] = $"=max(o{row}..r{row})";
            }
            row += 2; //adds 1 blank row between employees stats and overall stats
        }

        /// <summary>
        /// displays the totals of every column
        /// </summary>
        public void populateTotals()
        {
            theExcelSheet.Cells[row, 5] = "Total:";
            theExcelSheet.Cells[row, 6] = $"=sum(f2..f{row - 2})";
            theExcelSheet.Cells[row, 7] = $"=sum(g2..g{row - 2})";
            theExcelSheet.Cells[row, 8] = $"=sum(h2..h{row - 2})";
            theExcelSheet.Cells[row, 9] = $"=sum(i2..i{row - 2})";
            theExcelSheet.Cells[row, 10] = $"=sum(j2..j{row - 2})";
            theExcelSheet.Cells[row, 11] = $"=sum(k2..k{row - 2})";
            theExcelSheet.Cells[row, 12] = $"=sum(l2..l{row - 2})";
            theExcelSheet.Cells[row, 13] = $"=sum(m2..m{row - 2})";
            theExcelSheet.Cells[row, 15] = $"=sum(o2..o{row - 2})";
            theExcelSheet.Cells[row, 16] = $"=sum(p2..p{row - 2})";
            theExcelSheet.Cells[row, 17] = $"=sum(q2..q{row - 2})";
            theExcelSheet.Cells[row, 18] = $"=sum(r2..r{row - 2})";
            theExcelSheet.Cells[row, 19] = $"=sum(s2..s{row - 2})";
            theExcelSheet.Cells[row, 20] = $"=sum(t2..t{row - 2})";
            theExcelSheet.Cells[row, 21] = $"=sum(u2..u{row - 2})";
            theExcelSheet.Cells[row, 22] = $"=sum(v2..v{row - 2})";
            row++;
        }

        /// <summary>
        /// displays the maxs for each column
        /// </summary>
        public void populateMaxs()
        {
            theExcelSheet.Cells[row, 5] = "Max:";
            theExcelSheet.Cells[row, 6] = $"=max(f2..f{row - 3})";
            theExcelSheet.Cells[row, 7] = $"=max(g2..g{row - 3})";
            theExcelSheet.Cells[row, 8] = $"=max(h2..h{row - 3})";
            theExcelSheet.Cells[row, 9] = $"=max(i2..i{row - 3})";
            theExcelSheet.Cells[row, 10] = $"=max(j2..j{row - 3})";
            theExcelSheet.Cells[row, 11] = $"=max(k2..k{row - 3})";
            theExcelSheet.Cells[row, 12] = $"=max(l2..l{row - 3})";
            theExcelSheet.Cells[row, 13] = $"=max(m2..m{row - 3})";
            theExcelSheet.Cells[row, 15] = $"=max(o2..o{row - 3})";
            theExcelSheet.Cells[row, 16] = $"=max(p2..p{row - 3})";
            theExcelSheet.Cells[row, 17] = $"=max(q2..q{row - 3})";
            theExcelSheet.Cells[row, 18] = $"=max(r2..r{row - 3})";
            theExcelSheet.Cells[row, 19] = $"=max(s2..s{row - 3})";
            theExcelSheet.Cells[row, 20] = $"=max(t2..t{row - 3})";
            theExcelSheet.Cells[row, 21] = $"=max(u2..u{row - 3})";
            theExcelSheet.Cells[row, 22] = $"=max(v2..v{row - 3})";
            row++;
        }

        /// <summary>
        /// displays the averages for each column
        /// </summary>
        public void populateAverages()
        {
            theExcelSheet.Cells[row, 5] = "Avg:";
            theExcelSheet.Cells[row, 6] = $"=average(f2..f{row - 4})";
            theExcelSheet.Cells[row, 7] = $"=average(g2..g{row - 4})";
            theExcelSheet.Cells[row, 8] = $"=average(h2..h{row - 4})";
            theExcelSheet.Cells[row, 9] = $"=average(i2..i{row - 4})";
            theExcelSheet.Cells[row, 10] = $"=average(j2..j{row - 4})";
            theExcelSheet.Cells[row, 11] = $"=average(k2..k{row - 4})";
            theExcelSheet.Cells[row, 12] = $"=average(l2..l{row - 4})";
            theExcelSheet.Cells[row, 13] = $"=average(m2..m{row - 4})";
            theExcelSheet.Cells[row, 15] = $"=average(o2..o{row - 4})";
            theExcelSheet.Cells[row, 16] = $"=average(p2..p{row - 4})";
            theExcelSheet.Cells[row, 17] = $"=average(q2..q{row - 4})";
            theExcelSheet.Cells[row, 18] = $"=average(r2..r{row - 4})";
            theExcelSheet.Cells[row, 19] = $"=average(s2..s{row - 4})";
            theExcelSheet.Cells[row, 20] = $"=average(t2..t{row - 4})";
            theExcelSheet.Cells[row, 21] = $"=average(u2..u{row - 4})";
            theExcelSheet.Cells[row, 22] = $"=average(v2..v{row - 4})";
            row++;
        }

        /// <summary>
        /// displays the mins for each column
        /// </summary>
        public void populateMins()
        {
            theExcelSheet.Cells[row, 5] = "Min:";
            theExcelSheet.Cells[row, 6] = $"=min(f2..f{row - 5})";
            theExcelSheet.Cells[row, 7] = $"=min(g2..g{row - 5})";
            theExcelSheet.Cells[row, 8] = $"=min(h2..h{row - 5})";
            theExcelSheet.Cells[row, 9] = $"=min(i2..i{row - 5})";
            theExcelSheet.Cells[row, 10] = $"=min(j2..j{row - 5})";
            theExcelSheet.Cells[row, 11] = $"=min(k2..k{row - 5})";
            theExcelSheet.Cells[row, 12] = $"=min(l2..l{row - 5})";
            theExcelSheet.Cells[row, 13] = $"=min(m2..m{row - 5})";
            theExcelSheet.Cells[row, 15] = $"=min(o2..o{row - 5})";
            theExcelSheet.Cells[row, 16] = $"=min(p2..p{row - 5})";
            theExcelSheet.Cells[row, 17] = $"=min(q2..q{row - 5})";
            theExcelSheet.Cells[row, 18] = $"=min(r2..r{row - 5})";
            theExcelSheet.Cells[row, 19] = $"=min(s2..s{row - 5})";
            theExcelSheet.Cells[row, 20] = $"=min(t2..t{row - 5})";
            theExcelSheet.Cells[row, 21] = $"=min(u2..u{row - 5})";
            theExcelSheet.Cells[row, 22] = $"=min(v2..v{row - 5})";
        }
    }
}
