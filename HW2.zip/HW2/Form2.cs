﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2
{
    /// <summary>
    /// Filename: Form2.cs
    /// Part of Project: Form 2: Receipt Form
    ///
    /// File Purpose:
    /// The purpose of this file is for populating the textbox with the correct information and prices based
    /// on the selections made by the user in the other form. The user may only exit the application through this form.
    ///
    /// Program Purpose:
    /// The purpose of this program is to let a user select their billing information using the 
    /// provided options and revieve a receipt with the correct information including the correct names
    /// and prices, individual items, subtotals, and final totals, displayed in a nicely aligned receipt.
    /// The user may also return to the selection screen from the receipt screen and change their 
    /// selsections and be provided with a new and updated receipt upon navigating back the the receipt screen.
    /// </summary>
    public partial class Form2 : Form
    {

        private static float SALES_TAX_RATE = 0.06F; //Sales tax rate

        public static Form2 instance; //form2 instance variable
        float examinationFee = 0.00F; //variable for holding the examination fee
        float glassesSubtotal = 0.00F; //variable for holding the glasses subtotal
        float contactsSubtotal = 0.00F; //variable for holding the contacts subtotal
        float subtotal = 0.00F; //variable for holding the subtotal
        float salesTax = 0.00F; //variable for holding subtotal * SALES_TAX
        float finalTotal = 0.00F; //variable for holding the final total

        /// <summary>
        /// This funcation initializes the form and makes the form2 instace variable created above 
        /// equal this instance of form2
        /// </summary>
        public Form2()
        {
            InitializeComponent();
            instance = this;
        }

        /// <summary>
        /// This function makes this form invisible and makes form1 visible with the previous selctions still shown
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void btnBackToBillingScreen_Click(object sender, EventArgs e)
        {

            this.Visible = false;
            Form1.instance.Visible = true;
        }

        /// <summary>
        /// This function displays a message to the user that the order has been processed and sends the
        /// user back to a cleared out form1.
        /// </summary>
        /// <param name="sender">Sender objects</param>
        /// <param name="e">Event arguments</param>
        private void btnProcessOrder_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Order has been processed", "", MessageBoxButtons.OK);
            Form1.instance.clearForm();  
            this.Visible = false;    
            Form1.instance.Visible = true;

        }

        /// <summary>
        /// This function starts the closing application process.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void btnExitSystem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// This function provides a message to the user asking if they are sure they want to 
        /// close the application. If yes the boolean in form 1 is switched to true and both form are closed.
        /// If no, cancel.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to quit?", "", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
            }
            Form1.instance.flag = true;
            Form1.instance.Close();
        }

        /// <summary>
        /// This function populates the textbox by writing the opening with the clients name then calls the 
        /// writeExaminationSection, writeGlassesSection, writeContactsSection, and writeFinalSection functions to.
        /// </summary>
        /// <param name="billingInfo">List containing the major billing information.</param>
        /// <param name="glassesInfo">List containing all glasses selections.</param>
        /// <param name="contactsInfo">List containing all contact selection options.</param>
        public void populateForm(List<String> billingInfo, List<String> glassesInfo, List<String> contactsInfo)
        {
            txtReceipt.Text = "";
            examinationFee = 0.00F; 
            glassesSubtotal = 0.00F; 
            contactsSubtotal = 0.00F; 
            subtotal = 0.00F; 
            salesTax = 0.00F; 
            finalTotal = 0.00F;
            txtReceipt.Text = new string('-', 69) + "\r\n";
            txtReceipt.Text += string.Format("{0,70}","Obi-Wan Optometry") + "\r\n";
            txtReceipt.Text += new string('-', 69) + "\r\n";
            txtReceipt.Text += "\r\n";
            txtReceipt.Text += "Client: " + billingInfo[0] + "\r\n";
            txtReceipt.Text += "\r\n";
            txtReceipt.Text += "\r\n";
            if (billingInfo.Contains("Eye Exam"))
            {
                writeExaminationSection();
            }
            if (billingInfo.Contains("Glasses"))
            {
                writeGlassesSection(glassesInfo);
            }
            if (billingInfo.Contains("Contacts"))
            {
                writeContactsSection(contactsInfo);
            }
            writeFinalSection();
        }

        /// <summary>
        /// This function populates the textbox with "Examination" and the price of the examination and sets the 
        /// examinationFee variable equal 100.
        /// </summary>
        private void writeExaminationSection()
        {
            examinationFee = 100;
            txtReceipt.Text += "   " + string.Format("{0,-72}", "Examination:") + string.Format("{0:C}", 100) + "\r\n";
            txtReceipt.Text += "\r\n";
            txtReceipt.Text += "\r\n";
        }

        /// <summary>
        /// This function writes the glasses order secetion by looping through the glassesInfo list,
        /// calls the updateGlassesSubtotal function and passes the item price for updating the
        /// glasses subtotal, and writes the selection and its price to the texbox.
        /// </summary>
        /// <param name="glassesInfo">List containing all glasses selections.</param>
        private void writeGlassesSection(List<String> glassesInfo)
        {
            txtReceipt.Text += "   " + string.Format("{0,-32}", "Glasses Order --") + "\r\n";
            foreach (string glassesItem in glassesInfo)
            {
                updateGlassesSubtotal(getGlassesItemPrice(glassesItem));
                txtReceipt.Text += "     " + string.Format("{0,-70}", glassesItem) + string.Format("{0:C}", getGlassesItemPrice(glassesItem)) + "\r\n";
            }
            txtReceipt.Text += "   " + new string('-', 63) + "\r\n";
            txtReceipt.Text += "     " + string.Format("{0,-70}", "Glasses Subtotal") + string.Format("{0:C}", glassesSubtotal) + "\r\n";
            txtReceipt.Text += "\r\n";
            txtReceipt.Text += "\r\n";
        }

        /// <summary>
        /// This function adds the price of the glasses item to the glasses subtotal.
        /// </summary>
        /// <param name="glassesItemPrice">Individual price of a glasses item.</param>
        private void updateGlassesSubtotal(float glassesItemPrice)
        {
            glassesSubtotal += glassesItemPrice;
        }

        /// <summary>
        /// This function writes the contacts order secetion by looping through the glassesInfo list,
        /// calls the updateGlassesSubtotal function and passes the item price for updating the
        /// glasses subtotal, and writes the selection and its price to the texbox.
        /// </summary>
        /// <param name="contactsInfo">List containing all contact selections.</param>
        private void writeContactsSection(List<String> contactsInfo)
        {
            txtReceipt.Text += "   " + string.Format("{0,-32}", "Contacts Order --") + "\r\n";
            foreach (string contactsItem in contactsInfo)
            {
                if (contactsItem == "Darth Maul" || contactsItem == "C3PO Gold" || contactsItem == "R2D2 Blue" || contactsItem == "Yoda Green")
                {
                    updateContactsSubtotal(getContactsItemPrice(contactsItem));
                    txtReceipt.Text += "     " + string.Format("{0,-70}", $"Colored Lens ({contactsItem})") + string.Format("{0:C}", getContactsItemPrice(contactsItem)) + "\r\n";
                    break;
                }
                updateContactsSubtotal(getContactsItemPrice(contactsItem));
                txtReceipt.Text += "     " + string.Format("{0,-70}", contactsItem) + string.Format("{0:C}", getContactsItemPrice(contactsItem)) + "\r\n";
            }

            txtReceipt.Text += "   " + new string('-', 63) + "\r\n";
            txtReceipt.Text += "     " + string.Format("{0,-70}", "Contacts Subtotal") + string.Format("{0:C}", contactsSubtotal) + "\r\n";
            txtReceipt.Text += "\r\n";
            txtReceipt.Text += "\r\n";
        }

        /// <summary>
        /// This function adds the price of a contact selections individual price to the contacts subtotal.
        /// </summary>
        /// <param name="contactsItemPrice">Individual price of a contact item.</param>
        private void updateContactsSubtotal(float contactsItemPrice)
        {
            contactsSubtotal += contactsItemPrice;
        }

        /// <summary>
        /// This function calls the calcReceiptSubtotal, calcSalesTax, and calcFinalTotal function to
        /// calculate the subtotals and final total, populates the textbox.
        /// </summary>
        private void writeFinalSection()
        {
            calcReceiptSubtotal();
            txtReceipt.Text += "     " + string.Format("{0,-70}", "Receipt Subtotal") + string.Format("{0:C}", subtotal) + "\r\n";
            calcSalesTax();
            txtReceipt.Text += "     " + string.Format("{0,-70}", "Sales Tax") + string.Format("{0:C}", salesTax) + "\r\n";
            txtReceipt.Text += "   " + new string('-', 63) + "\r\n";
            calcFinalTotal();
            txtReceipt.Text += "     " + string.Format("{0,-70}", "Total") + string.Format("{0:C}", finalTotal) + "\r\n";
        }

        /// <summary>
        /// This function calculates the subtotal by adding the examination fee with
        /// the glasses subtotal and the contacts subtotal.
        /// </summary>
        private void calcReceiptSubtotal()
        {
            subtotal = examinationFee + glassesSubtotal + contactsSubtotal;
        }

        /// <summary>
        /// This function calculates the the sales tax byt multiplying the subtotal with the 
        /// sales tax rate.
        /// </summary>
        private void calcSalesTax()
        {
            salesTax = subtotal * SALES_TAX_RATE;
        }

        /// <summary>
        /// This function calculates the final total by adding the subtotal and sales tax.
        /// </summary>
        private void calcFinalTotal()
        {
            finalTotal = subtotal + salesTax;
        }

        /// <summary>
        /// This function returns the price of a glasses item.
        /// </summary>
        /// <param name="glassesItem">List containing all glasses selections.</param>
        /// <returns></returns>
        private float getGlassesItemPrice(string glassesItem)
        {
            switch (glassesItem)
            {
                case "Plastic Lens/Frame":
                    return 175;
                case "Glass Lens/Frame":
                    return 225;
                case "Anti-Scratch Coating":
                case "Tinted Lens":
                case "Computer Strain HD Lens":
                case "Rolled Lens Edges":
                case "Photosensitive Lens":
                case "Progressive Lens":
                    return 50;
            }
            return 0;
        }

        /// <summary>
        /// This function returns the price of a contact item.
        /// </summary>
        /// <param name="contactItem">List containing all contact selections.</param>
        /// <returns></returns>
        private float getContactsItemPrice(string contactItem)
        {
                switch (contactItem)
                {
                    case "Daily Wear":
                        return 100;
                    case "Extended Wear":
                        return 150;
                    case "Gas Permeable":
                        return 200;
                    case "Replacement Insurance":
                    case "Cleaning Supplies for One Year":
                    case "Darth Maul":
                    case "C3PO Gold":
                    case "R2D2 Blue":
                    case "Yoda Green":
                        return 75;
                }
            return 0;
        }
    }
}
