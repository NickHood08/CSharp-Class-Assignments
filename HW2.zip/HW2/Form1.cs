namespace HW2
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: Form 1: Billing information selection form
    ///
    /// File Purpose:
    /// The purpose of this file is for selecting a users billing information from the various options provided.
    /// The user may not exit the application from this form. They must navigate to the next form, by pressing
    /// the Proceed to Receipt Screen button then clicking the x in the top right or the Exit System button.
    ///
    /// Program Purpose:
    /// The purpose of this program is to let a user select their billing information using the 
    /// provided options and revieve a receipt with the correct information including the correct names
    /// and prices, individual items, subtotals, and final totals, displayed in a nicely aligned receipt.
    /// The user may also return to the selection screen from the receipt screen and change their 
    /// selsections and be provided with a new and updated receipt upon navigating back the the receipt screen.
    /// </summary>
    public partial class Form1 : Form
    {

        public static Form1 instance; //instance of form one so form 2 can make visible when user returns to this screen
        Form2 form2 = new Form2(); //form2 ready for when user wants to proceed to receipt screen
        List<String> billingInfo = new List<String>(); //list that holds the 3 main choices and if the user wants colored lens
        List<String> glassesInfo = new List<String>(); //list that holds all glasses selection
        List<String> contactsInfo = new List<String>(); //list that holds all contacts selections
        public bool flag = false; // boolean for deciding if user is allowed to close application

        /// <summary>
        /// This funcation initializes the form and makes the form1 instace variable created above 
        /// equal this instance of form1
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            instance = this;
        }

        /// <summary>
        /// This function loads the combobox options into the combobox when the form loads
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            cboColoredLensColors.Items.Add("Darth Maul");
            cboColoredLensColors.Items.Add("C3PO Gold");
            cboColoredLensColors.Items.Add("R2D2 Blue");
            cboColoredLensColors.Items.Add("Yoda Green");
        }

        /// <summary>
        /// This function checks the glasses checkbox checked status and makes the glasses options visible
        /// or invisible depending on the checked status.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void chkGlasses_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGlasses.Checked)
            {
                grpGlassesOptions.Visible = true;
            }
            else
            {
                grpGlassesOptions.Visible = false;
            }
        }


        /// <summary>
        /// This function checks the contacts checkbox checked status and makes the contacts options visible
        /// or invisible depending on the checked status.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void chkContacts_CheckedChanged(object sender, EventArgs e)
        {
            if (chkContacts.Checked)
            {
                grpContactOptions.Visible = true;
            }
            else
            {
                grpContactOptions.Visible = false;
            }
        }

        /// <summary>
        /// This function checks the colored checkbox checked status and makes the colored lens options visible
        /// or invisible depending on the checked status.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void chkColoredLens_CheckedChanged(object sender, EventArgs e)
        {
            if (chkColoredLens.Checked)
            {
                cboColoredLensColors.Visible = true;
            }
            else
            {
                cboColoredLensColors.Visible = false;
            }
        }

        /// <summary>
        /// This function checks if colored lens is checked and if a color has been selected.
        /// If not the user must either uncheck the colored lens checkbox or pick a color in the combobox.
        /// If user meets criteria, the billing info is collected via getBillingInfo function,
        /// form2 is created, form2 is populated, this form is made invisible, finally form2 is shown
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void btnProceedToReceiptScreen_Click(object sender, EventArgs e)
        {
            if (chkColoredLens.Checked && string.IsNullOrEmpty(cboColoredLensColors.Text))
            {
                MessageBox.Show("No Lens Color has been Selected");
            }
            else
            {
                getBillingInfo();
                Form2.instance.populateForm(billingInfo, glassesInfo, contactsInfo);
                this.Visible = false; 
                form2.Show();

            }
        }

        /// <summary>
        /// This function clears all lists, in case the user has already comeback from the receipt screen to make changes
        /// or they processed their previous order and a new user is using the system. 
        /// It ensures no overflow or repeating data. Then goes through all selections and checks if they were selected.
        /// If they were then they are added to their respective list.
        /// </summary>
        private void getBillingInfo()
        {
            billingInfo.Clear();
            glassesInfo.Clear();
            contactsInfo.Clear();

            billingInfo.Add(txtClientName.Text);
            if (chkEyeExam.Checked)
            {
                billingInfo.Add(chkEyeExam.Text);
            }
            if (chkGlasses.Checked)
            {
                billingInfo.Add(chkGlasses.Text);
            }
            if (chkContacts.Checked)
            {
                billingInfo.Add(chkContacts.Text);
            }
            if (rdoPlasticLensFrame.Checked)
            {
                glassesInfo.Add(rdoPlasticLensFrame.Text);
            }
            if (rdoGlassLensFrame.Checked)
            {
                glassesInfo.Add(rdoGlassLensFrame.Text);
            }
            if (chkAntiScratchCoating.Checked)
            {
                glassesInfo.Add(chkAntiScratchCoating.Text);
            }
            if (chkTintedLens.Checked)
            {
                glassesInfo.Add(chkTintedLens.Text);
            }
            if (chkComputerStrainHDLens.Checked)
            {
                glassesInfo.Add(chkComputerStrainHDLens.Text);
            }
            if (chkRolledLensEdges.Checked)
            {
                glassesInfo.Add(chkRolledLensEdges.Text);
            }
            if (chkPhotosensitiveLens.Checked)
            {
                glassesInfo.Add(chkPhotosensitiveLens.Text);
            }
            if (chkProgressiveLens.Checked)
            {
                glassesInfo.Add(chkProgressiveLens.Text);
            }
            if (rdoDailyWear.Checked)
            {
                contactsInfo.Add(rdoDailyWear.Text);
            }
            if (rdoExtendedWear.Checked)
            {
                contactsInfo.Add(rdoExtendedWear.Text);
            }
            if (rdoGasPermeable.Checked)
            {
                contactsInfo.Add(rdoGasPermeable.Text);
            }
            if (chkReplacementInsurance.Checked)
            {
                contactsInfo.Add(chkReplacementInsurance.Text);
            }
            if (chkCleaningSuppliesOneYear.Checked)
            {
                contactsInfo.Add(chkCleaningSuppliesOneYear.Text);
            }
            if (chkColoredLens.Checked)
            {
                billingInfo.Add(chkColoredLens.Text);
                contactsInfo.Add(cboColoredLensColors.Text);
            }
        }

        /// <summary>
        /// This function checks if the boolean variable has been changed to true which means the user is trying to
        /// exit the application from the receipt screen which allows the application to close.
        /// Otherwise the user cannot close the application.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">Event arguments</param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!flag)
            {
                MessageBox.Show("You can only close the application from the receipt screen!", "", MessageBoxButtons.OK);
                e.Cancel = true;
            }
        }

        /// <summary>
        /// This function clears the form from all previous selcetions to a blank selection screen.
        /// </summary>
        public void clearForm()
        {
            billingInfo.Clear();
            txtClientName.Text = "";
            chkEyeExam.Checked = false;
            chkGlasses.Checked = false;
            chkContacts.Checked = false;
            rdoPlasticLensFrame.Checked = true;
            rdoGlassLensFrame.Checked = false;
            chkAntiScratchCoating.Checked = false;
            chkTintedLens.Checked = false;
            chkComputerStrainHDLens.Checked = false;
            chkRolledLensEdges.Checked = false;
            chkPhotosensitiveLens.Checked = false;
            chkProgressiveLens.Checked = false;
            rdoDailyWear.Checked = true;
            rdoExtendedWear.Checked = false;
            rdoGasPermeable.Checked = false;
            chkReplacementInsurance.Checked = false;
            chkCleaningSuppliesOneYear.Checked = false;
            chkColoredLens.Checked = false;
            cboColoredLensColors.Text = "";
        }
    }
}
