﻿namespace HW2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtClientName = new TextBox();
            grpServices = new GroupBox();
            chkContacts = new CheckBox();
            chkGlasses = new CheckBox();
            chkEyeExam = new CheckBox();
            grpGlassesOptions = new GroupBox();
            chkProgressiveLens = new CheckBox();
            chkPhotosensitiveLens = new CheckBox();
            chkRolledLensEdges = new CheckBox();
            chkComputerStrainHDLens = new CheckBox();
            chkTintedLens = new CheckBox();
            chkAntiScratchCoating = new CheckBox();
            grpLensType = new GroupBox();
            rdoGlassLensFrame = new RadioButton();
            rdoPlasticLensFrame = new RadioButton();
            grpContactOptions = new GroupBox();
            cboColoredLensColors = new ComboBox();
            chkColoredLens = new CheckBox();
            chkCleaningSuppliesOneYear = new CheckBox();
            chkReplacementInsurance = new CheckBox();
            grpContactTypes = new GroupBox();
            rdoGasPermeable = new RadioButton();
            rdoExtendedWear = new RadioButton();
            rdoDailyWear = new RadioButton();
            btnProceedToReceiptScreen = new Button();
            grpServices.SuspendLayout();
            grpGlassesOptions.SuspendLayout();
            grpLensType.SuspendLayout();
            grpContactOptions.SuspendLayout();
            grpContactTypes.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 15);
            label1.Name = "label1";
            label1.Size = new Size(76, 15);
            label1.TabIndex = 5;
            label1.Text = "Client Name:";
            // 
            // txtClientName
            // 
            txtClientName.Location = new Point(94, 12);
            txtClientName.Name = "txtClientName";
            txtClientName.Size = new Size(219, 23);
            txtClientName.TabIndex = 0;
            // 
            // grpServices
            // 
            grpServices.Controls.Add(chkContacts);
            grpServices.Controls.Add(chkGlasses);
            grpServices.Controls.Add(chkEyeExam);
            grpServices.Location = new Point(12, 41);
            grpServices.Name = "grpServices";
            grpServices.Size = new Size(411, 53);
            grpServices.TabIndex = 1;
            grpServices.TabStop = false;
            grpServices.Text = "Services:";
            // 
            // chkContacts
            // 
            chkContacts.AutoSize = true;
            chkContacts.Location = new Point(322, 22);
            chkContacts.Name = "chkContacts";
            chkContacts.Size = new Size(73, 19);
            chkContacts.TabIndex = 2;
            chkContacts.Text = "Contacts";
            chkContacts.UseVisualStyleBackColor = true;
            chkContacts.CheckedChanged += chkContacts_CheckedChanged;
            // 
            // chkGlasses
            // 
            chkGlasses.AutoSize = true;
            chkGlasses.Location = new Point(169, 22);
            chkGlasses.Name = "chkGlasses";
            chkGlasses.Size = new Size(64, 19);
            chkGlasses.TabIndex = 1;
            chkGlasses.Text = "Glasses";
            chkGlasses.UseVisualStyleBackColor = true;
            chkGlasses.CheckedChanged += chkGlasses_CheckedChanged;
            // 
            // chkEyeExam
            // 
            chkEyeExam.AutoSize = true;
            chkEyeExam.Location = new Point(6, 22);
            chkEyeExam.Name = "chkEyeExam";
            chkEyeExam.Size = new Size(76, 19);
            chkEyeExam.TabIndex = 0;
            chkEyeExam.Text = "Eye Exam";
            chkEyeExam.UseVisualStyleBackColor = true;
            // 
            // grpGlassesOptions
            // 
            grpGlassesOptions.Controls.Add(chkProgressiveLens);
            grpGlassesOptions.Controls.Add(chkPhotosensitiveLens);
            grpGlassesOptions.Controls.Add(chkRolledLensEdges);
            grpGlassesOptions.Controls.Add(chkComputerStrainHDLens);
            grpGlassesOptions.Controls.Add(chkTintedLens);
            grpGlassesOptions.Controls.Add(chkAntiScratchCoating);
            grpGlassesOptions.Controls.Add(grpLensType);
            grpGlassesOptions.Location = new Point(12, 100);
            grpGlassesOptions.Name = "grpGlassesOptions";
            grpGlassesOptions.Size = new Size(411, 209);
            grpGlassesOptions.TabIndex = 2;
            grpGlassesOptions.TabStop = false;
            grpGlassesOptions.Text = "Glasses Options:";
            grpGlassesOptions.Visible = false;
            // 
            // chkProgressiveLens
            // 
            chkProgressiveLens.AutoSize = true;
            chkProgressiveLens.Location = new Point(218, 163);
            chkProgressiveLens.Name = "chkProgressiveLens";
            chkProgressiveLens.Size = new Size(113, 19);
            chkProgressiveLens.TabIndex = 6;
            chkProgressiveLens.Text = "Progressive Lens";
            chkProgressiveLens.UseVisualStyleBackColor = true;
            // 
            // chkPhotosensitiveLens
            // 
            chkPhotosensitiveLens.AutoSize = true;
            chkPhotosensitiveLens.Location = new Point(218, 128);
            chkPhotosensitiveLens.Name = "chkPhotosensitiveLens";
            chkPhotosensitiveLens.Size = new Size(130, 19);
            chkPhotosensitiveLens.TabIndex = 5;
            chkPhotosensitiveLens.Text = "Photosensitive Lens";
            chkPhotosensitiveLens.UseVisualStyleBackColor = true;
            // 
            // chkRolledLensEdges
            // 
            chkRolledLensEdges.AutoSize = true;
            chkRolledLensEdges.Location = new Point(218, 90);
            chkRolledLensEdges.Name = "chkRolledLensEdges";
            chkRolledLensEdges.Size = new Size(120, 19);
            chkRolledLensEdges.TabIndex = 4;
            chkRolledLensEdges.Text = "Rolled Lens Edges";
            chkRolledLensEdges.UseVisualStyleBackColor = true;
            // 
            // chkComputerStrainHDLens
            // 
            chkComputerStrainHDLens.AutoSize = true;
            chkComputerStrainHDLens.Location = new Point(18, 163);
            chkComputerStrainHDLens.Name = "chkComputerStrainHDLens";
            chkComputerStrainHDLens.Size = new Size(160, 19);
            chkComputerStrainHDLens.TabIndex = 3;
            chkComputerStrainHDLens.Text = "Computer Strain HD Lens";
            chkComputerStrainHDLens.UseVisualStyleBackColor = true;
            // 
            // chkTintedLens
            // 
            chkTintedLens.AutoSize = true;
            chkTintedLens.Location = new Point(18, 128);
            chkTintedLens.Name = "chkTintedLens";
            chkTintedLens.Size = new Size(86, 19);
            chkTintedLens.TabIndex = 2;
            chkTintedLens.Text = "Tinted Lens";
            chkTintedLens.UseVisualStyleBackColor = true;
            // 
            // chkAntiScratchCoating
            // 
            chkAntiScratchCoating.AutoSize = true;
            chkAntiScratchCoating.Location = new Point(18, 90);
            chkAntiScratchCoating.Name = "chkAntiScratchCoating";
            chkAntiScratchCoating.Size = new Size(137, 19);
            chkAntiScratchCoating.TabIndex = 1;
            chkAntiScratchCoating.Text = "Anti-Scratch Coating";
            chkAntiScratchCoating.UseVisualStyleBackColor = true;
            // 
            // grpLensType
            // 
            grpLensType.Controls.Add(rdoGlassLensFrame);
            grpLensType.Controls.Add(rdoPlasticLensFrame);
            grpLensType.Location = new Point(18, 22);
            grpLensType.Name = "grpLensType";
            grpLensType.Size = new Size(377, 53);
            grpLensType.TabIndex = 0;
            grpLensType.TabStop = false;
            // 
            // rdoGlassLensFrame
            // 
            rdoGlassLensFrame.AutoSize = true;
            rdoGlassLensFrame.Location = new Point(240, 18);
            rdoGlassLensFrame.Name = "rdoGlassLensFrame";
            rdoGlassLensFrame.Size = new Size(117, 19);
            rdoGlassLensFrame.TabIndex = 1;
            rdoGlassLensFrame.Text = "Glass Lens/Frame";
            rdoGlassLensFrame.UseVisualStyleBackColor = true;
            // 
            // rdoPlasticLensFrame
            // 
            rdoPlasticLensFrame.AutoSize = true;
            rdoPlasticLensFrame.Checked = true;
            rdoPlasticLensFrame.Location = new Point(37, 18);
            rdoPlasticLensFrame.Name = "rdoPlasticLensFrame";
            rdoPlasticLensFrame.Size = new Size(124, 19);
            rdoPlasticLensFrame.TabIndex = 0;
            rdoPlasticLensFrame.TabStop = true;
            rdoPlasticLensFrame.Text = "Plastic Lens/Frame";
            rdoPlasticLensFrame.UseVisualStyleBackColor = true;
            // 
            // grpContactOptions
            // 
            grpContactOptions.Controls.Add(cboColoredLensColors);
            grpContactOptions.Controls.Add(chkColoredLens);
            grpContactOptions.Controls.Add(chkCleaningSuppliesOneYear);
            grpContactOptions.Controls.Add(chkReplacementInsurance);
            grpContactOptions.Controls.Add(grpContactTypes);
            grpContactOptions.Location = new Point(12, 315);
            grpContactOptions.Name = "grpContactOptions";
            grpContactOptions.Size = new Size(416, 213);
            grpContactOptions.TabIndex = 3;
            grpContactOptions.TabStop = false;
            grpContactOptions.Text = "Contacts Options:";
            grpContactOptions.Visible = false;
            // 
            // cboColoredLensColors
            // 
            cboColoredLensColors.FormattingEnabled = true;
            cboColoredLensColors.Location = new Point(119, 175);
            cboColoredLensColors.Name = "cboColoredLensColors";
            cboColoredLensColors.Size = new Size(121, 23);
            cboColoredLensColors.TabIndex = 4;
            cboColoredLensColors.Visible = false;
            // 
            // chkColoredLens
            // 
            chkColoredLens.AutoSize = true;
            chkColoredLens.Location = new Point(18, 177);
            chkColoredLens.Name = "chkColoredLens";
            chkColoredLens.Size = new Size(95, 19);
            chkColoredLens.TabIndex = 3;
            chkColoredLens.Text = "Colored Lens";
            chkColoredLens.UseVisualStyleBackColor = true;
            chkColoredLens.CheckedChanged += chkColoredLens_CheckedChanged;
            // 
            // chkCleaningSuppliesOneYear
            // 
            chkCleaningSuppliesOneYear.AutoSize = true;
            chkCleaningSuppliesOneYear.Location = new Point(18, 138);
            chkCleaningSuppliesOneYear.Name = "chkCleaningSuppliesOneYear";
            chkCleaningSuppliesOneYear.Size = new Size(188, 19);
            chkCleaningSuppliesOneYear.TabIndex = 2;
            chkCleaningSuppliesOneYear.Text = "Cleaning Supplies for One Year";
            chkCleaningSuppliesOneYear.UseVisualStyleBackColor = true;
            // 
            // chkReplacementInsurance
            // 
            chkReplacementInsurance.AutoSize = true;
            chkReplacementInsurance.Location = new Point(18, 99);
            chkReplacementInsurance.Name = "chkReplacementInsurance";
            chkReplacementInsurance.Size = new Size(149, 19);
            chkReplacementInsurance.TabIndex = 1;
            chkReplacementInsurance.Text = "Replacement Insurance";
            chkReplacementInsurance.UseVisualStyleBackColor = true;
            // 
            // grpContactTypes
            // 
            grpContactTypes.Controls.Add(rdoGasPermeable);
            grpContactTypes.Controls.Add(rdoExtendedWear);
            grpContactTypes.Controls.Add(rdoDailyWear);
            grpContactTypes.Location = new Point(18, 22);
            grpContactTypes.Name = "grpContactTypes";
            grpContactTypes.Size = new Size(377, 57);
            grpContactTypes.TabIndex = 0;
            grpContactTypes.TabStop = false;
            // 
            // rdoGasPermeable
            // 
            rdoGasPermeable.AutoSize = true;
            rdoGasPermeable.Location = new Point(258, 22);
            rdoGasPermeable.Name = "rdoGasPermeable";
            rdoGasPermeable.Size = new Size(103, 19);
            rdoGasPermeable.TabIndex = 2;
            rdoGasPermeable.Text = "Gas Permeable";
            rdoGasPermeable.UseVisualStyleBackColor = true;
            // 
            // rdoExtendedWear
            // 
            rdoExtendedWear.AutoSize = true;
            rdoExtendedWear.Location = new Point(133, 22);
            rdoExtendedWear.Name = "rdoExtendedWear";
            rdoExtendedWear.Size = new Size(104, 19);
            rdoExtendedWear.TabIndex = 1;
            rdoExtendedWear.Text = "Extended Wear";
            rdoExtendedWear.UseVisualStyleBackColor = true;
            // 
            // rdoDailyWear
            // 
            rdoDailyWear.AutoSize = true;
            rdoDailyWear.Checked = true;
            rdoDailyWear.Location = new Point(16, 22);
            rdoDailyWear.Name = "rdoDailyWear";
            rdoDailyWear.Size = new Size(81, 19);
            rdoDailyWear.TabIndex = 0;
            rdoDailyWear.TabStop = true;
            rdoDailyWear.Text = "Daily Wear";
            rdoDailyWear.UseVisualStyleBackColor = true;
            // 
            // btnProceedToReceiptScreen
            // 
            btnProceedToReceiptScreen.Location = new Point(12, 534);
            btnProceedToReceiptScreen.Name = "btnProceedToReceiptScreen";
            btnProceedToReceiptScreen.Size = new Size(416, 38);
            btnProceedToReceiptScreen.TabIndex = 4;
            btnProceedToReceiptScreen.Text = "Proceed to Receipt Screen";
            btnProceedToReceiptScreen.UseVisualStyleBackColor = true;
            btnProceedToReceiptScreen.Click += btnProceedToReceiptScreen_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(452, 589);
            Controls.Add(btnProceedToReceiptScreen);
            Controls.Add(grpContactOptions);
            Controls.Add(grpGlassesOptions);
            Controls.Add(grpServices);
            Controls.Add(txtClientName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Obi-Wan Optometry -- Eye Care for Generations of Jedi";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            grpServices.ResumeLayout(false);
            grpServices.PerformLayout();
            grpGlassesOptions.ResumeLayout(false);
            grpGlassesOptions.PerformLayout();
            grpLensType.ResumeLayout(false);
            grpLensType.PerformLayout();
            grpContactOptions.ResumeLayout(false);
            grpContactOptions.PerformLayout();
            grpContactTypes.ResumeLayout(false);
            grpContactTypes.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtClientName;
        private GroupBox grpServices;
        private CheckBox chkContacts;
        private CheckBox chkGlasses;
        private CheckBox chkEyeExam;
        private GroupBox grpGlassesOptions;
        private GroupBox grpLensType;
        private RadioButton rdoPlasticLensFrame;
        private CheckBox chkProgressiveLens;
        private CheckBox chkPhotosensitiveLens;
        private CheckBox chkRolledLensEdges;
        private CheckBox chkComputerStrainHDLens;
        private CheckBox chkTintedLens;
        private CheckBox chkAntiScratchCoating;
        private RadioButton rdoGlassLensFrame;
        private GroupBox grpContactOptions;
        private Button btnProceedToReceiptScreen;
        private ComboBox cboColoredLensColors;
        private CheckBox chkColoredLens;
        private CheckBox chkCleaningSuppliesOneYear;
        private CheckBox chkReplacementInsurance;
        private GroupBox grpContactTypes;
        private RadioButton rdoGasPermeable;
        private RadioButton rdoExtendedWear;
        private RadioButton rdoDailyWear;
    }
}
