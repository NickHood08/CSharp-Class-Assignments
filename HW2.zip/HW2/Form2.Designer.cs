﻿namespace HW2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtReceipt = new TextBox();
            btnBackToBillingScreen = new Button();
            btnProcessOrder = new Button();
            btnExitSystem = new Button();
            SuspendLayout();
            // 
            // txtReceipt
            // 
            txtReceipt.Location = new Point(12, 12);
            txtReceipt.Multiline = true;
            txtReceipt.Name = "txtReceipt";
            txtReceipt.Size = new Size(361, 520);
            txtReceipt.TabIndex = 3;
            // 
            // btnBackToBillingScreen
            // 
            btnBackToBillingScreen.Location = new Point(12, 538);
            btnBackToBillingScreen.Name = "btnBackToBillingScreen";
            btnBackToBillingScreen.Size = new Size(361, 50);
            btnBackToBillingScreen.TabIndex = 0;
            btnBackToBillingScreen.Text = "Go Back to Billing Screen";
            btnBackToBillingScreen.UseVisualStyleBackColor = true;
            btnBackToBillingScreen.Click += btnBackToBillingScreen_Click;
            // 
            // btnProcessOrder
            // 
            btnProcessOrder.Location = new Point(12, 594);
            btnProcessOrder.Name = "btnProcessOrder";
            btnProcessOrder.Size = new Size(361, 50);
            btnProcessOrder.TabIndex = 1;
            btnProcessOrder.Text = "Process Order";
            btnProcessOrder.UseVisualStyleBackColor = true;
            btnProcessOrder.Click += btnProcessOrder_Click;
            // 
            // btnExitSystem
            // 
            btnExitSystem.Location = new Point(12, 650);
            btnExitSystem.Name = "btnExitSystem";
            btnExitSystem.Size = new Size(361, 50);
            btnExitSystem.TabIndex = 2;
            btnExitSystem.Text = "Exit System";
            btnExitSystem.UseVisualStyleBackColor = true;
            btnExitSystem.Click += btnExitSystem_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(385, 709);
            Controls.Add(btnExitSystem);
            Controls.Add(btnProcessOrder);
            Controls.Add(btnBackToBillingScreen);
            Controls.Add(txtReceipt);
            Name = "Form2";
            Text = "Obi-Wan Optometry -- Receipt Screen";
            FormClosing += Form2_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtReceipt;
        private Button btnBackToBillingScreen;
        private Button btnProcessOrder;
        private Button btnExitSystem;
    }
}