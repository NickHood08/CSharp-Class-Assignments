using System.Collections;
using System.Numerics;
using System.Xml.Serialization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CIS311HW1
{
    /// <summary>
    /// Filename:Form1.cs
    /// 
    /// File Purpose:
    /// This file is the main file where all the core functions and methods are carried out in relation to the GUI
    /// 
    /// Program Purpose:
    /// This program allows veterinarions to create new pet records and write them to a file and view all records in the file.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// This is the default constructor for the main form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        List<PetRecord> lstPetRecords = new List<PetRecord>(); //List of all pet records in the file
        int index = 0; //The index of the current record being displayed

        /// <summary>
        /// This function runs on form1 load and it reads from the fils that holds all the pet records and puts them into a list.
        /// Then if the list is empty then it will change the form so the user can enter in data to create a record and will not let user leave until at least one record is made and in the file.
        /// If the list is not empty, the form is populated with the first record in the file.
        /// </summary>
        /// <param name="sender">The object sender</param>
        /// <param name="e">The event arguments</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            cboAgeUnits.Items.Add("Months");
            cboAgeUnits.Items.Add("Years");

            string? recordsContents = "";

            System.IO.StreamReader reader;

            reader = System.IO.File.OpenText("PetRecords.txt");
            while (!reader.EndOfStream)
            {
                recordsContents = reader.ReadLine();
                if (recordsContents != null && recordsContents != "") 
                {
                    string[] temp = new string[7];
                    temp = recordsContents.Split(",");
                    lstPetRecords.Add(new PetRecord(temp[0], temp[1], temp[2], Convert.ToInt32(temp[3]), Convert.ToBoolean(temp[4]), temp[5], temp[6]));
                }
            }
            reader.Close();
            if(lstPetRecords.Count == 0 ) 
            {
                btnAddNewPetRecord.Visible = false;
                switchForm();
            }
            else
            {
                populateForm();
            }
        }

        /// <summary>
        /// This function "switches" the useability of the form.
        /// </summary>
        private void switchForm()
        {
            if (btnAddNewPetRecord.Visible)
            {
                txtPetName.Enabled = false;
                txtOwnerName.Enabled = false;
                txtSpecies.Enabled = false;
                txtAge.Enabled = false;
                chkSpayedNeutered.Enabled = false;
                cboAgeUnits.Enabled = false;
                txtLastVisit.Enabled = false;
                btnLeft.Text = "<<";
                btnRight.Text = ">>";
                populateForm();
            }
            else
            {
                txtPetName.Enabled = true;
                txtOwnerName.Enabled = true;
                txtSpecies.Enabled = true;
                txtAge.Enabled = true;
                chkSpayedNeutered.Enabled = true;
                cboAgeUnits.Enabled = true;
                txtLastVisit.Enabled = true;
                btnLeft.Text = "Save";
                btnRight.Text = "Cancel";
            }
        }

        /// <summary>
        /// This function clears everything on the form.
        /// </summary>
        private void clearForm()
        {
            txtPetName.Text = "";
            txtOwnerName.Text = "";
            txtSpecies.Text = ""; ;
            txtAge.Text = "";
            chkSpayedNeutered.Checked = false;
            txtLastVisit.Text = "";
        }

        /// <summary>
        /// This function populates the form with the appropriate data of the current record.
        /// </summary>
        private void populateForm()
        {
            txtPetName.Text = lstPetRecords[index].getPetName();
            txtOwnerName.Text = lstPetRecords[index].getOwnerName();
            txtSpecies.Text = lstPetRecords[index].getPetSpecies();
            txtAge.Text = lstPetRecords[index].getPetAge() + "";
            cboAgeUnits.Text = lstPetRecords[index].getAgeUnits();
            chkSpayedNeutered.Checked = lstPetRecords[index].getSpayedOrNeutered();
            txtLastVisit.Text = lstPetRecords[index].getLastVisit();
            this.Text = $"Veterinary Clinic System - Pet {index+1}/{lstPetRecords.Count}";
        }

        /// <summary>
        /// This function goes through the list of all records and writes them into the file.
        /// </summary>
        private void updateRecords()
        {
            System.IO.StreamWriter writer = System.IO.File.CreateText("PetRecords.txt");
            foreach (PetRecord pr in lstPetRecords)
            {
                writer.WriteLine($"{pr.getPetName()},{pr.getOwnerName()},{pr.getPetSpecies()},{pr.getPetAge()},{pr.getSpayedOrNeutered()},{pr.getLastVisit()},{pr.getAgeUnits()}");
            }
            writer.Close();
        }

        /// <summary>
        /// This function handles all the << and "save" operations.
        /// The "save" operations consist of creating a record and adding it to the list of all records. Then writing all records to the file and switching the form to view mode.
        /// The "<<" operations consist of decrementing the index by 1 and populating the form with the appropriate data if there is a record to be found.
        /// If there is no record found then a message box is shown stating no record was found.
        /// </summary>
        /// <param name="sender">The object sender</param>
        /// <param name="e">The event Arguments</param>
        private void btnLeft_Click(object sender, EventArgs e)
        {
            if (btnLeft.Text == "Save")
            {
                lstPetRecords.Add(new PetRecord(txtPetName.Text, txtOwnerName.Text, txtSpecies.Text, Convert.ToInt32(txtAge.Text), chkSpayedNeutered.Checked, txtLastVisit.Text, cboAgeUnits.Text));
                updateRecords();
                btnAddNewPetRecord.Visible = true;
                switchForm();
                populateForm();
            }
            else
            {
                if (index-1 == -1)
                {
                    MessageBox.Show("No records found");
                }
                else
                {
                    index -= 1;
                    populateForm();
                }
            }
        }

        /// <summary>
        /// This function handles the cancel and >> operations.
        /// The cancel operations consist of clearing the form of any data inputted by the user, switching the form in view only mode, 
        /// and populating the form with the appropriate data. Unless there are no records then the user must create a record before switching to view mode.
        /// The >> operations consist of increasing the index variable by 1 and populating the form if there is a record to be found in the list.
        /// If there is no record to be found then a message box is displayed to the user saying no records were found.
        /// </summary>
        /// <param name="sender">The object sender</param>
        /// <param name="e">The event Arguments</param>
        private void btnRight_Click(object sender, EventArgs e)
        {
            if (btnRight.Text == "Cancel")
            {
                if(lstPetRecords.Count > 0) 
                {
                    btnAddNewPetRecord.Visible = true;
                    switchForm();
                    populateForm();
                }
            }
            else
            {
                if (index + 2 > lstPetRecords.Count)
                {
                    MessageBox.Show("No records found");
                }
                else
                {
                    index += 1;
                    populateForm();
                }
            }
        }

        /// <summary>
        /// This function makes the add button invisible and switches the form so the user can create a record and save the record into the file.
        /// </summary>
        /// <param name="sender">The object sender</param>
        /// <param name="e">The event Arguments</param>
        private void btnAddNewPetRecord_Click(object sender, EventArgs e)
        {
            btnAddNewPetRecord.Visible = false;
            switchForm();
            clearForm();
        }
    }
}
