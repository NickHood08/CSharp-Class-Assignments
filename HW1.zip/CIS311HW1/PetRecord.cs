﻿using System;
/// <summary>
/// Filename:PetRecord.cs
/// 
/// File Purpose:
/// This file was made to make handling and storing the data for a pet record easier.
/// 
/// Class Purpose:
/// This class was made for the purpose of storing the data of a pet record.
/// </summary>
public class PetRecord
{

	private string petName;         //The name of the pet
    private string ownerName;       //The name of the owner of the pet
    private string petSpecies;      //The species of the pet
    private string lastVisit;       //The date of the last visit
    private int petAge;             //The age of the pet
    private bool spayedOrNeutered;  //Boolean value for showing if a pet had been spayed or neutered
    private string ageUnits;        //The age units

    /// <summary>
    /// This is the constructor for a pet record
    /// </summary>
    /// <param name="petName">The name of the pet</param>
    /// <param name="ownerName">The name of the owner of the pet</param>
    /// <param name="petSpecies">The species of the pet</param>
    /// <param name="petAge">The age of the pet</param>
    /// <param name="spayedOrNeutered">Boolean value for showing if a pet had been spayed or neutered</param>
    /// <param name="lastVisit">The date of the last visit</param>
    /// <param name="ageUnits">The age units</param>
    public PetRecord(string petName, string ownerName, string petSpecies, int petAge, bool spayedOrNeutered, string lastVisit, string ageUnits)
	{
		this.petName = petName;
		this.ownerName = ownerName;
		this.petSpecies = petSpecies;
		this.petAge = petAge;
		this.spayedOrNeutered = spayedOrNeutered;
		this.lastVisit = lastVisit;
		this.ageUnits = ageUnits;
	}

	/// <summary>
	/// This function returns the name of the pet
	/// </summary>
	/// <returns>string - The name of the pet</returns>
	public string getPetName() {  return petName; }

    /// <summary>
    /// This function returns the name of the owner of the pet
    /// </summary>
    /// <returns>string - The name of the owner of the pet</returns>
    public string getOwnerName() {  return ownerName; }

    /// <summary>
    /// This function returns the species of the pet
    /// </summary>
    /// <returns>string - The species of the pet</returns>
    public string getPetSpecies() {  return petSpecies; }

    /// <summary>
    /// This function returns the age of the pet
    /// </summary>
    /// <returns>string - The age of the pet</returns>
    public int getPetAge() {  return petAge; }

    /// <summary>
    /// This function returns the value for showing if a pet had been spayed or neutered
    /// </summary>
    /// <returns>boolean - The value for showing if a pet had been spayed or neutered</returns>
    public bool getSpayedOrNeutered() {  return spayedOrNeutered; }

    /// <summary>
    /// This function returns the date of the last visit
    /// </summary>
    /// <returns>string - The date of the last visit</returns>
    public string getLastVisit() { return lastVisit;}

    /// <summary>
    /// This function returns the age units
    /// </summary>
    /// <returns>string - The age units</returns>
    public string getAgeUnits() {  return ageUnits; }

}
