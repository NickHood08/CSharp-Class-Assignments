﻿namespace CIS311HW1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPetName = new Label();
            lblSpecies = new Label();
            lblOwnerName = new Label();
            lblAge = new Label();
            lblLastVisit = new Label();
            lblAgeUnits = new Label();
            cboAgeUnits = new ComboBox();
            chkSpayedNeutered = new CheckBox();
            btnLeft = new Button();
            btnAddNewPetRecord = new Button();
            btnRight = new Button();
            txtPetName = new TextBox();
            txtOwnerName = new TextBox();
            txtAge = new TextBox();
            txtLastVisit = new TextBox();
            txtSpecies = new TextBox();
            SuspendLayout();
            // 
            // lblPetName
            // 
            lblPetName.AutoSize = true;
            lblPetName.Location = new Point(24, 59);
            lblPetName.Name = "lblPetName";
            lblPetName.Size = new Size(62, 15);
            lblPetName.TabIndex = 10;
            lblPetName.Text = "Pet Name:";
            // 
            // lblSpecies
            // 
            lblSpecies.AutoSize = true;
            lblSpecies.Location = new Point(24, 116);
            lblSpecies.Name = "lblSpecies";
            lblSpecies.Size = new Size(49, 15);
            lblSpecies.TabIndex = 12;
            lblSpecies.Text = "Species:";
            // 
            // lblOwnerName
            // 
            lblOwnerName.AutoSize = true;
            lblOwnerName.Location = new Point(291, 59);
            lblOwnerName.Name = "lblOwnerName";
            lblOwnerName.Size = new Size(80, 15);
            lblOwnerName.TabIndex = 11;
            lblOwnerName.Text = "Owner Name:";
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(291, 121);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(31, 15);
            lblAge.TabIndex = 13;
            lblAge.Text = "Age:";
            // 
            // lblLastVisit
            // 
            lblLastVisit.AutoSize = true;
            lblLastVisit.Location = new Point(291, 179);
            lblLastVisit.Name = "lblLastVisit";
            lblLastVisit.Size = new Size(56, 15);
            lblLastVisit.TabIndex = 15;
            lblLastVisit.Text = "Last Visit:";
            // 
            // lblAgeUnits
            // 
            lblAgeUnits.AutoSize = true;
            lblAgeUnits.Location = new Point(634, 95);
            lblAgeUnits.Name = "lblAgeUnits";
            lblAgeUnits.Size = new Size(61, 15);
            lblAgeUnits.TabIndex = 14;
            lblAgeUnits.Text = "Age Units:";
            // 
            // cboAgeUnits
            // 
            cboAgeUnits.Enabled = false;
            cboAgeUnits.FormattingEnabled = true;
            cboAgeUnits.Location = new Point(634, 113);
            cboAgeUnits.Name = "cboAgeUnits";
            cboAgeUnits.Size = new Size(99, 23);
            cboAgeUnits.TabIndex = 4;
            // 
            // chkSpayedNeutered
            // 
            chkSpayedNeutered.AutoSize = true;
            chkSpayedNeutered.Enabled = false;
            chkSpayedNeutered.Location = new Point(24, 178);
            chkSpayedNeutered.Name = "chkSpayedNeutered";
            chkSpayedNeutered.Size = new Size(123, 19);
            chkSpayedNeutered.TabIndex = 5;
            chkSpayedNeutered.Text = "Spayed/Neutered?";
            chkSpayedNeutered.UseVisualStyleBackColor = true;
            // 
            // btnLeft
            // 
            btnLeft.Location = new Point(24, 272);
            btnLeft.Name = "btnLeft";
            btnLeft.Size = new Size(139, 39);
            btnLeft.TabIndex = 7;
            btnLeft.Text = "<<";
            btnLeft.UseVisualStyleBackColor = true;
            btnLeft.Click += btnLeft_Click;
            // 
            // btnAddNewPetRecord
            // 
            btnAddNewPetRecord.Location = new Point(169, 272);
            btnAddNewPetRecord.Name = "btnAddNewPetRecord";
            btnAddNewPetRecord.Size = new Size(413, 39);
            btnAddNewPetRecord.TabIndex = 8;
            btnAddNewPetRecord.Text = "Add New Pet Record";
            btnAddNewPetRecord.UseVisualStyleBackColor = true;
            btnAddNewPetRecord.Click += btnAddNewPetRecord_Click;
            // 
            // btnRight
            // 
            btnRight.Location = new Point(588, 272);
            btnRight.Name = "btnRight";
            btnRight.Size = new Size(139, 39);
            btnRight.TabIndex = 9;
            btnRight.Text = ">>";
            btnRight.UseVisualStyleBackColor = true;
            btnRight.Click += btnRight_Click;
            // 
            // txtPetName
            // 
            txtPetName.Enabled = false;
            txtPetName.Location = new Point(92, 59);
            txtPetName.Name = "txtPetName";
            txtPetName.Size = new Size(136, 23);
            txtPetName.TabIndex = 0;
            // 
            // txtOwnerName
            // 
            txtOwnerName.Enabled = false;
            txtOwnerName.Location = new Point(377, 59);
            txtOwnerName.Name = "txtOwnerName";
            txtOwnerName.Size = new Size(133, 23);
            txtOwnerName.TabIndex = 1;
            // 
            // txtAge
            // 
            txtAge.Enabled = false;
            txtAge.Location = new Point(377, 113);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(133, 23);
            txtAge.TabIndex = 3;
            // 
            // txtLastVisit
            // 
            txtLastVisit.Enabled = false;
            txtLastVisit.Location = new Point(377, 176);
            txtLastVisit.Name = "txtLastVisit";
            txtLastVisit.Size = new Size(133, 23);
            txtLastVisit.TabIndex = 6;
            // 
            // txtSpecies
            // 
            txtSpecies.Enabled = false;
            txtSpecies.Location = new Point(92, 113);
            txtSpecies.Name = "txtSpecies";
            txtSpecies.Size = new Size(136, 23);
            txtSpecies.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(752, 384);
            Controls.Add(txtSpecies);
            Controls.Add(txtLastVisit);
            Controls.Add(txtAge);
            Controls.Add(txtOwnerName);
            Controls.Add(txtPetName);
            Controls.Add(btnRight);
            Controls.Add(btnAddNewPetRecord);
            Controls.Add(btnLeft);
            Controls.Add(chkSpayedNeutered);
            Controls.Add(cboAgeUnits);
            Controls.Add(lblAgeUnits);
            Controls.Add(lblLastVisit);
            Controls.Add(lblAge);
            Controls.Add(lblOwnerName);
            Controls.Add(lblSpecies);
            Controls.Add(lblPetName);
            Name = "Form1";
            Text = "Veterinary Clinic System";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPetName;
        private Label lblSpecies;
        private Label lblOwnerName;
        private Label lblAge;
        private Label lblLastVisit;
        private Label lblAgeUnits;
        private ComboBox cboAgeUnits;
        private CheckBox chkSpayedNeutered;
        private Button btnLeft;
        private Button btnAddNewPetRecord;
        private Button btnRight;
        private TextBox txtPetName;
        private TextBox txtOwnerName;
        private TextBox txtAge;
        private TextBox txtLastVisit;
        private TextBox txtSpecies;
    }
}
