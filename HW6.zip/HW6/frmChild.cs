﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW6
{
    /// <summary>
    /// Filename: frmChild.cs
    /// Part of Project: Child Form
    ///
    /// File Purpose:
    /// The purpose of this file that it contains the main purpose of the program.
    /// This file contains the functionality to calculate the formula of a shape selected by a user.
    /// The user can also convert the result to the metric system.
    ///
    /// Program Purpose:
    /// The purpose of this program is to calculate a certain formula of the provided shapes
    /// while utilizing mdi functionality.
    /// </summary>
    public partial class frmChild : Form
    {

        const int NOSELECTEDITEM = -1;              // index for nothing selected in a listbox
        const float INTOCMCONVERSTION1 = 2.54f;     // the conversion for inches into centimeters
        const float INTOCMCONVERSTION2 = 6.4516f;   // the conversion for inches^2 into centimeters^2
        const float INTOCMCONVERSTION3 = 16.3871f;  // the conversion for inches^3 into centimeters^3
        const string ZERO = "0";                    // the number 0
        const string ONE = "1";                     // the number 1
        const string TWO = "2";                     // the number 2
        const string THREE = "3";                   // the number 3
        const string FOUR = "4";                    // the number 4
        const string FIVE = "5";                    // the number 5
        const string SIX = "6";                     // the number 6
        const string SEVEN = "7";                   // the number 7
        const string EIGHT = "8";                   // the number 8
        const string NINE = "9";                    // the number 9
        const string DECIMAL = ".";                 // a decimal point
        private TextBox? userSelectedTextbox;       // the representation of the last textbox selected by the user
        /// <summary>
        /// Initializes the form
        /// </summary>
        public frmChild()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Populates the shapes listbox with a list of shapes
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void frmChild_Load(object sender, EventArgs e)
        {
            lstShapes.Items.Add("2D - Rectangle");
            lstShapes.Items.Add("2D - Square");
            lstShapes.Items.Add("2D - Right Triangle");
            lstShapes.Items.Add("2D - Circle");
            lstShapes.Items.Add("3D - Cube");
            lstShapes.Items.Add("3D - Sphere");
            lstShapes.Items.Add("3D - Cylinder");
            lstShapes.Items.Add("3D - Cone");

            lstShapes.SelectedIndex = 0;
            lstFormulas.SelectedIndex = 0;
        }
        /// <summary>
        /// When a new shape is selected, calls the function to reset and hide the textboxees and labels,
        /// calls the function to populate the formulas list box with the selected shapes formulas, 
        /// calls the function to change the picture to the selected shape, and result is set back to 0.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void lstShapes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstShapes.SelectedIndex != NOSELECTEDITEM) 
            {
                resetTextboxesAndLables();
                populateFormulasListBox(lstShapes.SelectedItem!.ToString()!);
                displayPicture(lstShapes.SelectedItem!.ToString()!);
                if (txtResult.Text != ZERO)
                {
                    txtResult.Text = ZERO;
                }
            }
        }
        /// <summary>
        /// Populates the formulas listbox with the appropriate formulas for the selected shape.
        /// </summary>
        /// <param name="shape">The name of the shape the user selected</param>
        private void populateFormulasListBox(string shape)
        {
            lstFormulas.Items.Clear();
            switch (shape)
            {
                case "2D - Rectangle":
                case "2D - Square":
                case "2D - Right Triangle":
                    lstFormulas.Items.Add("Perimeter");
                    lstFormulas.Items.Add("Area");
                    break;
                case "2D - Circle":
                    lstFormulas.Items.Add("Circumference");
                    lstFormulas.Items.Add("Area");
                    break;
                case "3D - Cube":
                case "3D - Sphere":
                case "3D - Cylinder":
                case "3D - Cone":
                    lstFormulas.Items.Add("Volume");
                    lstFormulas.Items.Add("Surface Area");
                    break;
            }
        }
        /// <summary>
        /// Displays the picture of the selected shape.
        /// </summary>
        /// <param name="shape">The name of the shape the user selected</param>
        private void displayPicture(string shape)
        {
            if (!picShape.Visible)
            {
                picShape.Visible = true;
            }
            switch (shape)
            {
                case "2D - Rectangle":
                    picShape.Image = Properties.Resources.rectangle;
                    break;
                case "2D - Square":
                    picShape.Image = Properties.Resources.square;
                    break;
                case "2D - Right Triangle":
                    picShape.Image = Properties.Resources.triangle;
                    break;
                case "2D - Circle":
                    picShape.Image = Properties.Resources.circle;
                    break;
                case "3D - Cube":
                    picShape.Image = Properties.Resources.cube;
                    break;
                case "3D - Sphere":
                    picShape.Image = Properties.Resources.sphere;
                    break;
                case "3D - Cylinder":
                    picShape.Image = Properties.Resources.cylinder;
                    break;
                case "3D - Cone":
                    picShape.Image = Properties.Resources.cone;
                    break;
            }
            picShape.SizeMode = PictureBoxSizeMode.AutoSize;
        }
        /// <summary>
        /// Calls the functions to reset the textboxes and their labels and 
        /// the function to change them accordinly.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void lstFormulas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstFormulas.SelectedIndex != NOSELECTEDITEM)
            {
                resetTextboxesAndLables();
                displayTextboxes(lstShapes.SelectedItem!.ToString()!, lstFormulas.SelectedItem!.ToString()!);
            }
        }
        /// <summary>
        /// Makes all textboxes and labels invisible and clears the textboxes.
        /// </summary>
        private void resetTextboxesAndLables()
        {
            lblFirstInput.Visible = false;
            txtFirstInput.Text = string.Empty;
            txtFirstInput.Visible = false;
            lblSecondInput.Visible = false;
            txtSecondInput.Text = string.Empty;
            txtSecondInput.Visible = false;
            lblThirdInput.Visible = false;
            txtThirdInput.Text = string.Empty;
            txtThirdInput.Visible = false;

        }
        /// <summary>
        /// Displays the labels (appropriately named) and textboxes needed for calculating 
        /// the chosen shapes formula.
        /// </summary>
        /// <param name="shape">The selected shape.</param>
        /// <param name="formula">The selected formula.</param>
        private void displayTextboxes(string shape, string formula)
        {
            switch (shape)
            {
                case "2D - Rectangle":
                    switch (formula)
                    {
                        case "Perimeter":
                        case "Area":
                            lblFirstInput.Text = "Length:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            lblSecondInput.Text = "Width:";
                            lblSecondInput.Visible = true;
                            txtSecondInput.Visible = true;
                            break;
                    }
                    break;
                case "2D - Square":
                    switch (formula)
                    {
                        case "Perimeter":
                        case "Area":
                            lblFirstInput.Text = "Length:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            break;
                    }
                    break;
                case "2D - Right Triangle":
                    switch (formula)
                    {
                        case "Perimeter":
                        case "Area":
                            lblFirstInput.Text = "Base:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            lblSecondInput.Text = "Height:";
                            lblSecondInput.Visible = true;
                            txtSecondInput.Visible = true;
                            break;
                    }
                    break;
                case "2D - Circle":
                    switch (formula)
                    {
                        case "Circumference":
                        case "Area":
                            lblFirstInput.Text = "Radius:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            break;
                    }
                    break;
                case "3D - Cube":
                    switch (formula)
                    {
                        case "Volume":
                        case "Surface Area":
                            lblFirstInput.Text = "Height:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            lblSecondInput.Text = "Width:";
                            lblSecondInput.Visible = true;
                            txtSecondInput.Visible = true;
                            lblThirdInput.Text = "Length:";
                            lblThirdInput.Visible = true;
                            txtThirdInput.Visible = true;
                            break;
                    }
                    break;
                case "3D - Sphere":
                    switch (formula)
                    {
                        case "Volume":
                        case "Surface Area":
                            lblFirstInput.Text = "Radius:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            break;
                    }
                    break;
                case "3D - Cylinder":
                case "3D - Cone":
                    switch (formula)
                    {
                        case "Volume":
                        case "Surface Area":
                            lblFirstInput.Text = "Radius:";
                            lblFirstInput.Visible = true;
                            txtFirstInput.Visible = true;
                            lblSecondInput.Text = "Height:";
                            lblSecondInput.Visible = true;
                            txtSecondInput.Visible = true;
                            break;
                    }
                    break;
            }
        }
        /// <summary>
        /// Calls the calculation function 
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            calcResult(lstShapes.SelectedItem!.ToString()!, lstFormulas.SelectedItem!.ToString()!);
        }
        /// <summary>
        /// First checks for any empty visible textboxes and makes them 0 if there are.
        /// Then depending on the shape and formula selected, the result will be displayed with 
        /// the correct solution.
        /// </summary>
        /// <param name="shape">The shape selected.</param>
        /// <param name="formula">The formula selected.</param>
        private void calcResult(string shape, string formula)
        {
            if(txtFirstInput.Visible && txtFirstInput.Text == string.Empty)
            {
                txtFirstInput.Text = ZERO;
            }
            if (txtSecondInput.Visible && txtSecondInput.Text == string.Empty)
            {
                txtSecondInput.Text = ZERO;
            }
            if (txtThirdInput.Visible && txtThirdInput.Text == string.Empty)
            {
                txtThirdInput.Text = ZERO;
            }
            if (lstShapes.SelectedIndex != NOSELECTEDITEM && lstFormulas.SelectedIndex != NOSELECTEDITEM)
            {
                switch (shape)
                {
                    case "2D - Rectangle":
                        switch (formula)
                        {
                            case "Perimeter":
                                txtResult.Text = ((2 * float.Parse(txtFirstInput.Text)) + (2 * float.Parse(txtSecondInput.Text))).ToString();
                                break;
                            case "Area":
                                txtResult.Text = (float.Parse(txtFirstInput.Text) * float.Parse(txtSecondInput.Text)).ToString();
                                break;
                        }
                        break;
                    case "2D - Square":
                        switch (formula)
                        {
                            case "Perimeter":
                                txtResult.Text = (4 * float.Parse(txtFirstInput.Text)).ToString();
                                break;
                            case "Area":
                                txtResult.Text = (float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text)).ToString();
                                break;
                        }
                        break;
                    case "2D - Right Triangle":
                        switch (formula)
                        {
                            case "Perimeter":
                                txtResult.Text = (float.Parse(txtFirstInput.Text) + float.Parse(txtSecondInput.Text) + Math.Sqrt((float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text)) + (float.Parse(txtSecondInput.Text) * float.Parse(txtSecondInput.Text)))).ToString();
                                break;
                            case "Area":
                                txtResult.Text = (0.5 * float.Parse(txtFirstInput.Text) * float.Parse(txtSecondInput.Text)).ToString();
                                break;
                        }
                        break;
                    case "2D - Circle":
                        switch (formula)
                        {
                            case "Circumference":
                                txtResult.Text = (2 * Math.PI * float.Parse(txtFirstInput.Text)).ToString();
                                break;
                            case "Area":
                                txtResult.Text = (Math.PI * (float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text))).ToString();
                                break;
                        }
                        break;
                    case "3D - Cube":
                        switch (formula)
                        {
                            case "Volume":
                                txtResult.Text = (float.Parse(txtFirstInput.Text) * float.Parse(txtSecondInput.Text) * float.Parse(txtThirdInput.Text)).ToString();
                                break;
                            case "Surface Area":
                                txtResult.Text = ((2 * float.Parse(txtFirstInput.Text) * float.Parse(txtSecondInput.Text)) + (2 * float.Parse(txtFirstInput.Text) * float.Parse(txtThirdInput.Text)) + (2 * float.Parse(txtSecondInput.Text) * float.Parse(txtThirdInput.Text))).ToString();
                                break;
                        }
                        break;
                    case "3D - Sphere":
                        switch (formula)
                        {
                            case "Volume":
                                txtResult.Text = ((float)4 / 3 * Math.PI * (float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text))).ToString();
                                break;
                            case "Surface Area":
                                txtResult.Text = (4 * Math.PI * (float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text))).ToString();
                                break;
                        }
                        break;
                    case "3D - Cylinder":
                        switch (formula)
                        {
                            case "Volume":
                                txtResult.Text = (Math.PI * (float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text)) * float.Parse(txtSecondInput.Text)).ToString();
                                break;
                            case "Surface Area":
                                txtResult.Text = ((2 * Math.PI * float.Parse(txtFirstInput.Text) * float.Parse(txtSecondInput.Text)) + (2 * Math.PI * (float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text)))).ToString();
                                break;
                        }
                        break;
                    case "3D - Cone":
                        switch (formula)
                        {
                            case "Volume":
                                txtResult.Text = ((float)1 / 3 * Math.PI * (float.Parse(txtFirstInput.Text) * float.Parse(txtSecondInput.Text)) * float.Parse(txtSecondInput.Text)).ToString();
                                break;
                            case "Surface Area":
                                txtResult.Text = ((Math.PI * float.Parse(txtFirstInput.Text)) * (float.Parse(txtFirstInput.Text) + Math.Sqrt((float.Parse(txtFirstInput.Text) * float.Parse(txtFirstInput.Text)) + (float.Parse(txtSecondInput.Text) * float.Parse(txtSecondInput.Text))))).ToString();
                                break;
                        }
                        break;
                }
            }
        }
        /// <summary>
        /// Sets the representation of the last selected textbox to the first textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void txtFirstInput_Enter(object sender, EventArgs e)
        {
            userSelectedTextbox = (TextBox)sender;
        }
        /// <summary>
        /// Sets the representation of the last selected textbox to the second textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void txtSecondInput_Enter(object sender, EventArgs e)
        {
            userSelectedTextbox = (TextBox)sender;
        }
        /// <summary>
        /// Sets the representation of the last selected textbox to the third textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void txtThirdInput_Enter(object sender, EventArgs e)
        {
            userSelectedTextbox = (TextBox)sender;
        }
        /// <summary>
        /// Checks if user has selected a textbox.
        /// </summary>
        /// <returns>Booleon for if a textbox was selected</returns>
        private bool userSelectedATexbox()
        {
            if (userSelectedTextbox != null)
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 0 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn0_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += ZERO;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then . is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnDecimal_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox() && !userSelectedTextbox!.Text.Contains(DECIMAL))
            {
                userSelectedTextbox!.Text += DECIMAL;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 1 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn1_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += ONE;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 2 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn2_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += TWO;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 3 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn3_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += THREE;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 4 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn4_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += FOUR;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 5 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn5_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += FIVE;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 6 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn6_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += SIX;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 7 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn7_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += SEVEN;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 8 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn8_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += EIGHT;
            }
        }
        /// <summary>
        /// Calls the function to check if a user selected a textbox and if yes then 9 is put into the textbox.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btn9_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text += NINE;
            }
        }
        /// <summary>
        /// Deslects bot the shapes and formulas, calls the function to reset the 
        /// textboxes and labels and hides the picture.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnClear_Click(object sender, EventArgs e)
        {
            lstShapes.SelectedIndex = NOSELECTEDITEM;
            lstFormulas.SelectedIndex = NOSELECTEDITEM;
            txtResult.Text = ZERO;
            resetTextboxesAndLables();
            picShape.Visible = false;
        }
        /// <summary>
        /// Clears the entry of the last selected textbox if one was selected.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void btnClearEntry_Click(object sender, EventArgs e)
        {
            if (userSelectedATexbox())
            {
                userSelectedTextbox!.Text = string.Empty;
            }
        }
        /// <summary>
        /// Converts the result back into inches.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void rdoUS_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoUS.Checked)
            {
                switch (lstFormulas.SelectedItem)
                {
                    case "Perimeter":
                        txtResult.Text = (float.Parse(txtResult.Text) / INTOCMCONVERSTION1).ToString();
                        break;
                    case "Area":
                        txtResult.Text = (float.Parse(txtResult.Text) / INTOCMCONVERSTION2).ToString();
                        break;
                    case "Circumference":
                        txtResult.Text = (float.Parse(txtResult.Text) / INTOCMCONVERSTION1).ToString();
                        break;
                    case "Volume":
                        txtResult.Text = (float.Parse(txtResult.Text) / INTOCMCONVERSTION3).ToString();
                        break;
                    case "Surface Area":
                        txtResult.Text = (float.Parse(txtResult.Text) / INTOCMCONVERSTION2).ToString();
                        break;
                }
            }
        }
        /// <summary>
        /// Converts the result into centimeters.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rdoMetric_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoMetric.Checked)
            {
                switch (lstFormulas.SelectedItem)
                {
                    case "Perimeter":
                        txtResult.Text = (float.Parse(txtResult.Text) * INTOCMCONVERSTION1).ToString();
                        break;
                    case "Area":
                        txtResult.Text = (float.Parse(txtResult.Text) * INTOCMCONVERSTION2).ToString();
                        break;
                    case "Circumference":
                        txtResult.Text = (float.Parse(txtResult.Text) * INTOCMCONVERSTION1).ToString();
                        break;
                    case "Volume":
                        txtResult.Text = (float.Parse(txtResult.Text) * INTOCMCONVERSTION3).ToString();
                        break;
                    case "Surface Area":
                        txtResult.Text = (float.Parse(txtResult.Text) * INTOCMCONVERSTION2).ToString();
                        break;
                }
            }
        }
        /// <summary>
        /// Checks if the user made a calculation and if so asks if the user wants to close the form.
        /// If yes, the form is closed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void frmChild_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (txtResult.Text != ZERO)
            {
                if (MessageBox.Show($"Are you sure you want to close {this.Name}?", "", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }
    }
}
