﻿namespace HW6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            mnuMenuStrip = new MenuStrip();
            mnuFile = new ToolStripMenuItem();
            mnuFileNew = new ToolStripMenuItem();
            mnuFileExit = new ToolStripMenuItem();
            mnuWindow = new ToolStripMenuItem();
            mnuWindowTile = new ToolStripMenuItem();
            mnuWindowTileHorizontal = new ToolStripMenuItem();
            mnuWindowTileVertical = new ToolStripMenuItem();
            mnuWindowCascade = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            mnuHelp = new ToolStripMenuItem();
            mnuHelpAbout = new ToolStripMenuItem();
            mnuMenuStrip.SuspendLayout();
            SuspendLayout();
            // 
            // mnuMenuStrip
            // 
            mnuMenuStrip.Items.AddRange(new ToolStripItem[] { mnuFile, mnuWindow, mnuHelp });
            mnuMenuStrip.Location = new Point(0, 0);
            mnuMenuStrip.MdiWindowListItem = mnuWindow;
            mnuMenuStrip.Name = "mnuMenuStrip";
            mnuMenuStrip.Size = new Size(834, 24);
            mnuMenuStrip.TabIndex = 0;
            mnuMenuStrip.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            mnuFile.DropDownItems.AddRange(new ToolStripItem[] { mnuFileNew, mnuFileExit });
            mnuFile.Name = "mnuFile";
            mnuFile.Size = new Size(37, 20);
            mnuFile.Text = "File";
            // 
            // mnuFileNew
            // 
            mnuFileNew.Name = "mnuFileNew";
            mnuFileNew.Size = new Size(98, 22);
            mnuFileNew.Text = "New";
            mnuFileNew.Click += mnuFileNew_Click;
            // 
            // mnuFileExit
            // 
            mnuFileExit.Name = "mnuFileExit";
            mnuFileExit.Size = new Size(98, 22);
            mnuFileExit.Text = "Exit";
            mnuFileExit.Click += mnuFileExit_Click;
            // 
            // mnuWindow
            // 
            mnuWindow.DropDownItems.AddRange(new ToolStripItem[] { mnuWindowTile, mnuWindowCascade, toolStripMenuItem1 });
            mnuWindow.Name = "mnuWindow";
            mnuWindow.Size = new Size(63, 20);
            mnuWindow.Text = "Window";
            // 
            // mnuWindowTile
            // 
            mnuWindowTile.DropDownItems.AddRange(new ToolStripItem[] { mnuWindowTileHorizontal, mnuWindowTileVertical });
            mnuWindowTile.Name = "mnuWindowTile";
            mnuWindowTile.Size = new Size(118, 22);
            mnuWindowTile.Text = "Tile";
            // 
            // mnuWindowTileHorizontal
            // 
            mnuWindowTileHorizontal.Name = "mnuWindowTileHorizontal";
            mnuWindowTileHorizontal.Size = new Size(129, 22);
            mnuWindowTileHorizontal.Text = "Horizontal";
            mnuWindowTileHorizontal.Click += mnuWindowTileHorizontal_Click;
            // 
            // mnuWindowTileVertical
            // 
            mnuWindowTileVertical.Name = "mnuWindowTileVertical";
            mnuWindowTileVertical.Size = new Size(129, 22);
            mnuWindowTileVertical.Text = "Vertical";
            mnuWindowTileVertical.Click += mnuWindowTileVertical_Click;
            // 
            // mnuWindowCascade
            // 
            mnuWindowCascade.Name = "mnuWindowCascade";
            mnuWindowCascade.Size = new Size(118, 22);
            mnuWindowCascade.Text = "Cascade";
            mnuWindowCascade.Click += mnuWindowCascade_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(115, 6);
            // 
            // mnuHelp
            // 
            mnuHelp.DropDownItems.AddRange(new ToolStripItem[] { mnuHelpAbout });
            mnuHelp.Name = "mnuHelp";
            mnuHelp.Size = new Size(44, 20);
            mnuHelp.Text = "Help";
            // 
            // mnuHelpAbout
            // 
            mnuHelpAbout.Name = "mnuHelpAbout";
            mnuHelpAbout.Size = new Size(107, 22);
            mnuHelpAbout.Text = "About";
            mnuHelpAbout.Click += mnuHelpAbout_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(834, 522);
            Controls.Add(mnuMenuStrip);
            IsMdiContainer = true;
            MainMenuStrip = mnuMenuStrip;
            Name = "Form1";
            Text = "Caluclator";
            FormClosing += Form1_FormClosing;
            mnuMenuStrip.ResumeLayout(false);
            mnuMenuStrip.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip mnuMenuStrip;
        private ToolStripMenuItem mnuFile;
        private ToolStripMenuItem mnuWindow;
        private ToolStripMenuItem mnuWindowTile;
        private ToolStripMenuItem mnuWindowTileHorizontal;
        private ToolStripMenuItem mnuWindowTileVertical;
        private ToolStripMenuItem mnuHelp;
        private ToolStripMenuItem mnuHelpAbout;
        private ToolStripMenuItem mnuWindowCascade;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem mnuFileNew;
        private ToolStripMenuItem mnuFileExit;
    }
}
