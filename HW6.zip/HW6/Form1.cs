namespace HW6
{
    /// <summary>
    /// Filename: Form1.cs
    /// Part of Project: Form 1: Parent MDI Form
    ///
    /// File Purpose:
    /// The purpose of this file is to contain the main mdi functionality.
    ///
    /// Program Purpose:
    /// The purpose of this program is to calculate a certain formula of the provided shapes
    /// while utilizing mdi functionality.
    /// </summary>
    public partial class Form1 : Form
    {
        const int ZERO = 0;             // constant for representing 0
        private int childCount = ZERO;  // counts the number of children created
        /// <summary>
        /// Initializes the form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// A new child form is created and makes its parent this form
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void mnuFileNew_Click(object sender, EventArgs e)
        {
            frmChild aNewChildForm = new frmChild();
            childCount++;
            aNewChildForm.Name = aNewChildForm.Text = "Child - " + childCount.ToString().Trim();
            aNewChildForm.MdiParent = this;
            aNewChildForm.Show();
        }
        /// <summary>
        /// Starts closing the form
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// Changes the mdi layout to horizontal
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void mnuWindowTileHorizontal_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }
        /// <summary>
        /// Changes the mdi layout to vertical
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void mnuWindowTileVertical_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }
        /// <summary>
        /// Changes mdi layout to cascade
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void mnuWindowCascade_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }
        /// <summary>
        /// Displays the about page
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void mnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutBox1 myAbout = new AboutBox1();
            myAbout.ShowDialog();
        }
        /// <summary>
        /// Checks if there are children forms and if so try closing them.
        /// If no children are left then close the parent form.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.MdiChildren.Count() > ZERO)
            {
                foreach (Form aform in this.MdiChildren)
                {
                    aform.Close();
                }
                if (this.MdiChildren.Count() > ZERO)
                {
                    e.Cancel = true;
                }
            }
        }
    }
}
