﻿namespace HW6
{
    partial class frmChild
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            picShape = new PictureBox();
            lblFirstInput = new Label();
            txtFirstInput = new TextBox();
            lblSecondInput = new Label();
            lblThirdInput = new Label();
            txtSecondInput = new TextBox();
            txtThirdInput = new TextBox();
            label4 = new Label();
            lstShapes = new ListBox();
            label5 = new Label();
            lstFormulas = new ListBox();
            txtResult = new TextBox();
            groupBox1 = new GroupBox();
            rdoMetric = new RadioButton();
            rdoUS = new RadioButton();
            btnClearEntry = new Button();
            btnClear = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btn4 = new Button();
            btn1 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btnDecimal = new Button();
            btn0 = new Button();
            btnCalculate = new Button();
            ((System.ComponentModel.ISupportInitialize)picShape).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // picShape
            // 
            picShape.Location = new Point(399, 184);
            picShape.Name = "picShape";
            picShape.Size = new Size(389, 238);
            picShape.TabIndex = 0;
            picShape.TabStop = false;
            // 
            // lblFirstInput
            // 
            lblFirstInput.AutoSize = true;
            lblFirstInput.Location = new Point(399, 23);
            lblFirstInput.Name = "lblFirstInput";
            lblFirstInput.Size = new Size(38, 15);
            lblFirstInput.TabIndex = 1;
            lblFirstInput.Text = "label1";
            lblFirstInput.Visible = false;
            // 
            // txtFirstInput
            // 
            txtFirstInput.Location = new Point(485, 20);
            txtFirstInput.Name = "txtFirstInput";
            txtFirstInput.PlaceholderText = "0";
            txtFirstInput.Size = new Size(253, 23);
            txtFirstInput.TabIndex = 2;
            txtFirstInput.Visible = false;
            txtFirstInput.Enter += txtFirstInput_Enter;
            // 
            // lblSecondInput
            // 
            lblSecondInput.AutoSize = true;
            lblSecondInput.Location = new Point(399, 77);
            lblSecondInput.Name = "lblSecondInput";
            lblSecondInput.Size = new Size(38, 15);
            lblSecondInput.TabIndex = 3;
            lblSecondInput.Text = "label2";
            lblSecondInput.Visible = false;
            // 
            // lblThirdInput
            // 
            lblThirdInput.AutoSize = true;
            lblThirdInput.Location = new Point(399, 136);
            lblThirdInput.Name = "lblThirdInput";
            lblThirdInput.Size = new Size(38, 15);
            lblThirdInput.TabIndex = 4;
            lblThirdInput.Text = "label3";
            lblThirdInput.Visible = false;
            // 
            // txtSecondInput
            // 
            txtSecondInput.Location = new Point(485, 74);
            txtSecondInput.Name = "txtSecondInput";
            txtSecondInput.PlaceholderText = "0";
            txtSecondInput.Size = new Size(253, 23);
            txtSecondInput.TabIndex = 5;
            txtSecondInput.Visible = false;
            txtSecondInput.Enter += txtSecondInput_Enter;
            // 
            // txtThirdInput
            // 
            txtThirdInput.Location = new Point(485, 133);
            txtThirdInput.Name = "txtThirdInput";
            txtThirdInput.PlaceholderText = "0";
            txtThirdInput.Size = new Size(253, 23);
            txtThirdInput.TabIndex = 6;
            txtThirdInput.Visible = false;
            txtThirdInput.Enter += txtThirdInput_Enter;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 184);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 7;
            label4.Text = "Shape:";
            // 
            // lstShapes
            // 
            lstShapes.FormattingEnabled = true;
            lstShapes.ItemHeight = 15;
            lstShapes.Location = new Point(12, 202);
            lstShapes.Name = "lstShapes";
            lstShapes.Size = new Size(111, 79);
            lstShapes.TabIndex = 8;
            lstShapes.SelectedIndexChanged += lstShapes_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 311);
            label5.Name = "label5";
            label5.Size = new Size(54, 15);
            label5.TabIndex = 9;
            label5.Text = "Formula:";
            // 
            // lstFormulas
            // 
            lstFormulas.FormattingEnabled = true;
            lstFormulas.ItemHeight = 15;
            lstFormulas.Location = new Point(12, 329);
            lstFormulas.Name = "lstFormulas";
            lstFormulas.Size = new Size(111, 79);
            lstFormulas.TabIndex = 10;
            lstFormulas.SelectedIndexChanged += lstFormulas_SelectedIndexChanged;
            // 
            // txtResult
            // 
            txtResult.Location = new Point(149, 77);
            txtResult.Name = "txtResult";
            txtResult.ReadOnly = true;
            txtResult.Size = new Size(192, 23);
            txtResult.TabIndex = 11;
            txtResult.Text = "0";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdoMetric);
            groupBox1.Controls.Add(rdoUS);
            groupBox1.Location = new Point(149, 108);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(192, 43);
            groupBox1.TabIndex = 12;
            groupBox1.TabStop = false;
            groupBox1.Text = "Convert Answer";
            // 
            // rdoMetric
            // 
            rdoMetric.AutoSize = true;
            rdoMetric.Location = new Point(127, 18);
            rdoMetric.Name = "rdoMetric";
            rdoMetric.Size = new Size(59, 19);
            rdoMetric.TabIndex = 1;
            rdoMetric.Text = "Metric";
            rdoMetric.UseVisualStyleBackColor = true;
            rdoMetric.CheckedChanged += rdoMetric_CheckedChanged;
            // 
            // rdoUS
            // 
            rdoUS.AutoSize = true;
            rdoUS.Checked = true;
            rdoUS.Location = new Point(6, 18);
            rdoUS.Name = "rdoUS";
            rdoUS.Size = new Size(39, 19);
            rdoUS.TabIndex = 0;
            rdoUS.TabStop = true;
            rdoUS.Text = "US";
            rdoUS.UseVisualStyleBackColor = true;
            rdoUS.CheckedChanged += rdoUS_CheckedChanged;
            // 
            // btnClearEntry
            // 
            btnClearEntry.Location = new Point(254, 157);
            btnClearEntry.Name = "btnClearEntry";
            btnClearEntry.Size = new Size(87, 32);
            btnClearEntry.TabIndex = 14;
            btnClearEntry.Text = "CE";
            btnClearEntry.UseVisualStyleBackColor = true;
            btnClearEntry.Click += btnClearEntry_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(149, 157);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(87, 32);
            btnClear.TabIndex = 15;
            btnClear.Text = "C";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btn7
            // 
            btn7.Location = new Point(149, 202);
            btn7.Name = "btn7";
            btn7.Size = new Size(59, 33);
            btn7.TabIndex = 16;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btn7_Click;
            // 
            // btn8
            // 
            btn8.Location = new Point(214, 202);
            btn8.Name = "btn8";
            btn8.Size = new Size(59, 33);
            btn8.TabIndex = 17;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btn8_Click;
            // 
            // btn9
            // 
            btn9.Location = new Point(279, 202);
            btn9.Name = "btn9";
            btn9.Size = new Size(62, 33);
            btn9.TabIndex = 18;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btn9_Click;
            // 
            // btn4
            // 
            btn4.Location = new Point(149, 248);
            btn4.Name = "btn4";
            btn4.Size = new Size(59, 33);
            btn4.TabIndex = 19;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn1
            // 
            btn1.Location = new Point(149, 293);
            btn1.Name = "btn1";
            btn1.Size = new Size(59, 33);
            btn1.TabIndex = 20;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // btn5
            // 
            btn5.Location = new Point(214, 248);
            btn5.Name = "btn5";
            btn5.Size = new Size(59, 33);
            btn5.TabIndex = 21;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click;
            // 
            // btn6
            // 
            btn6.Location = new Point(279, 248);
            btn6.Name = "btn6";
            btn6.Size = new Size(62, 33);
            btn6.TabIndex = 22;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += btn6_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(214, 293);
            btn2.Name = "btn2";
            btn2.Size = new Size(59, 33);
            btn2.TabIndex = 23;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(279, 293);
            btn3.Name = "btn3";
            btn3.Size = new Size(62, 33);
            btn3.TabIndex = 24;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btnDecimal
            // 
            btnDecimal.Location = new Point(279, 341);
            btnDecimal.Name = "btnDecimal";
            btnDecimal.Size = new Size(62, 33);
            btnDecimal.TabIndex = 25;
            btnDecimal.Text = ".";
            btnDecimal.UseVisualStyleBackColor = true;
            btnDecimal.Click += btnDecimal_Click;
            // 
            // btn0
            // 
            btn0.Location = new Point(149, 341);
            btn0.Name = "btn0";
            btn0.Size = new Size(124, 33);
            btn0.TabIndex = 26;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += btn0_Click;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(149, 389);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(192, 33);
            btnCalculate.TabIndex = 27;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // frmChild
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 435);
            Controls.Add(btnCalculate);
            Controls.Add(btn0);
            Controls.Add(btnDecimal);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn1);
            Controls.Add(btn4);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btnClear);
            Controls.Add(btnClearEntry);
            Controls.Add(groupBox1);
            Controls.Add(txtResult);
            Controls.Add(lstFormulas);
            Controls.Add(label5);
            Controls.Add(lstShapes);
            Controls.Add(label4);
            Controls.Add(txtThirdInput);
            Controls.Add(txtSecondInput);
            Controls.Add(lblThirdInput);
            Controls.Add(lblSecondInput);
            Controls.Add(txtFirstInput);
            Controls.Add(lblFirstInput);
            Controls.Add(picShape);
            Name = "frmChild";
            Text = "frmChild";
            FormClosing += frmChild_FormClosing;
            Load += frmChild_Load;
            ((System.ComponentModel.ISupportInitialize)picShape).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox picShape;
        private Label lblFirstInput;
        private TextBox txtFirstInput;
        private Label lblSecondInput;
        private Label lblThirdInput;
        private TextBox txtSecondInput;
        private TextBox txtThirdInput;
        private Label label4;
        private ListBox lstShapes;
        private Label label5;
        private ListBox lstFormulas;
        private TextBox txtResult;
        private GroupBox groupBox1;
        private RadioButton rdoMetric;
        private RadioButton rdoUS;
        private Button btnClearEntry;
        private Button btnClear;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btn4;
        private Button btn1;
        private Button btn5;
        private Button btn6;
        private Button btn2;
        private Button btn3;
        private Button btnDecimal;
        private Button btn0;
        private Button btnCalculate;
    }
}